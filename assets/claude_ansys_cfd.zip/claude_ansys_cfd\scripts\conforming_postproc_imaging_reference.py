# Reference post-processing / imaging script — headless imaging + quantitative extraction for a conforming external-flow solution (PyFluent 0.17.1)
# ============================================================================
# Corresponds to docs/02_pyfluent_playbook.md §6/§7/§9/§10, docs/07_postprocessing_and_imaging.md;
# fixes F5 (y+ facet extraction), F7 (moment units), F8 (camera does not redraw).
#
# === WHAT IT DEMONSTRATES ===
#   Reads case+data (no re-solve); uses shadow topology to distinguish the aircraft outer surface vs the outer-domain box;
#   aircraft outer-surface Cp / static-pressure contour plots (isometric / left / top multi-view);
#   y=const longitudinal cross-section through the body: velocity-magnitude / static-pressure / Mach contour plots (large domain, small body, recomposed image using box x/z ranges);
#   wall shear stress (skin friction) and y+ surface contour plots; streamlines;
#   force / moment compute + coefficient summary (reference values are estimated -> process-validation only);
#   per-facet y+ array extraction (the rendered image is node-averaged; auditing must use facets).
#
# === KEY GOTCHAS (ALL VERIFIED-WORKING) ===
#   * F8: display() resets the camera back to the default front view; camera/{target,position,up} set_state does not trigger a redraw
#     -> the only reliable sequence: display -> restore-view -> auto-scale -> pan-camera -> zoom-camera -> save.
#   * When a named graphics-object container is empty, get_state() returns None, so you cannot use `name in get_state()` to test existence
#     -> just try create(), and on failure fall back to obj[name] = {}.
#   * Large-domain cross-section recomposed image: use field_info.get_scalar_field_range('x-coordinate'/'z-coordinate', surface_ids=box)
#     to get the domain center, pan = (CX-domcx, CZ-domcz); pan units are viewport fractions (not world coordinates), then zoom in.
#   * The wall skin-friction field name is "wall-shear", not "wall-shear-stress" (bare wall-shear-stress often fails to resolve)
#     -> use a candidate-fallback list with first_field() and try each in turn; do not hard-code a single name.
#   * F7: to get N·m from the moment compute you must explicitly set report_output_type="Drag Force"
#     (the default "Drag Coefficient" = moment coefficient, /q·A·L); the enum only has {Drag Coefficient | Drag Force}.
#   * F5: y+ numeric extraction uses a field_data transaction: new_transaction() +
#     add_scalar_fields_request(field_name="y-plus", surface_ids=[...], node_value=False, boundary_value=True)
#     + get_fields(); calling get_scalar_field_data directly returns empty, and session.fields does not exist.
#   * The rendered y+ is node-averaged (biased low); audit references must use the facet array above (max is higher).
#   * Disable all interactive TUI reports (F3 wall-forces "Empty filename" infinite loop floods 9.8 million lines).
#   * Cross-section vectors in the recomposed (zoom) image have arrows auto-scaled too large to be usable -> use streamlines (pathline) instead.
#   * Reference area / length / moment center are estimated values -> Cd/Cl/Cm are "process-validation" level only, never a design conclusion.
#
# === HOW TO ADAPT ===
#   Only edit the "===== CONFIG (edit per case) =====" block below: paths / case name / flow conditions / reference values / body center /
#   image resolution / ZOOM / pan defaults. Leave the rest of the logic (F5/F7/F8 fixes) untouched.
#   The box/aircraft split is determined automatically by shadow topology for each case; no need to hard-code zone names.
#   Note: centered cropping (compositing the color bar + a centered aircraft crop with System.Drawing) is a separate post-processing step per docs/07,
#         and is not in this script (pan is a viewport fraction, so a single pan still drifts to the right; deterministic centering relies on composite-crop).
#
# Always clear zombies (including mpiexec!) before running, otherwise the next launch reports Connection refused (F9/F11):
#   Get-Process fluent,mpiexec,cortex,python -EA SilentlyContinue | Stop-Process -Force
#   Start-Sleep 10; read back and confirm Get-Process fluent,mpiexec is empty before starting (do not kill+launch in the same command).
# ============================================================================

import json
import math
import os
import sys
import traceback

sys.path.insert(0, r"D:\ansys2024\ANSYS Inc\v241\optiSLang\lib\python3.10\Lib\site-packages")
from ansys.fluent.core import launch_fluent
from ansys.fluent.core.launcher.launcher import FluentMode

# ===================== CONFIG (edit per case) =====================
WORKDIR  = r"C:\Users\oc\Desktop\Codex_Ansys"
CASE     = os.path.join(WORKDIR, "Javelin_V1_conforming_alpha3.cas.h5")   # already-saved case+data
OUT      = os.path.join(WORKDIR, "conforming_postproc_imaging_reference.out")
IMG      = os.path.join(WORKDIR, "Javelin_V1_vtol_cruise_alpha3_images")   # image output directory
SUMMARY  = os.path.join(WORKDIR, "Javelin_V1_conforming_results_summary.md")

# Body geometric center (the longitudinal cross-section passes through this point; the camera aims at it); estimated value = bbox center
CX, CY, CZ = -1.011984, 0.6, 1.12

# Flow conditions
ALPHA = 3.0                 # angle of attack, deg
U     = 300.0 / 3.6         # free-stream 83.333 m/s (300 kph)
RHO   = 1.225               # kg/m^3
REF_AREA = 0.043876         # m^2  [estimated] -> coefficients are process-validation only
REF_LEN  = 0.5              # m    [estimated / known body length]
MOM_CENTER = [-1.011984, 0.6, 1.12]   # [estimated] bbox center, not the true CG

# Imaging
IMG_X, IMG_Y = 2560, 1440   # resolution
ZOOM = 7.0                  # cross-section recomposed-image zoom (pulls the body closer within the large domain)
PAN_DEFAULT = (-3.0, 0.0)   # fallback pan when the box range cannot be obtained (viewport fractions, empirical; flip the sign if wrong)
# ===================== END CONFIG =====================

# Derived quantities
Q = 0.5 * RHO * U * U                                                   # dynamic pressure, Pa
DRAG_DIR = [math.cos(math.radians(ALPHA)), 0.0, math.sin(math.radians(ALPHA))]
LIFT_DIR = [-math.sin(math.radians(ALPHA)), 0.0, math.cos(math.radians(ALPHA))]
SIDE_DIR = [0.0, 1.0, 0.0]


def log(m):
    with open(OUT, "a", encoding="utf-8") as f:
        f.write(str(m) + "\n")


def safe(label, fn):
    """Execute and log, without raising (a post-processing failure should not waste the whole image batch)."""
    try:
        r = fn(); log(f"{label}=OK {repr(r)[:140]}"); return r
    except Exception as e:
        log(f"{label}=ERR {repr(e)[:220]}"); return None


def first_field(gr_contour, name, candidates, surfaces, extra=None):
    """Try each candidate field name in turn, returning (object, matched field name).
    VERIFIED-WORKING: wall skin friction must use this fallback — "wall-shear-stress" often fails, "wall-shear" is the one that matches.
    Only assign to state keys that actually exist (version-safe): node_values/filled/contour_lines/boundary_values."""
    for fld in candidates:
        try:
            try:
                gr_contour.create(name)
            except Exception:
                gr_contour[name] = {}                      # empty container get_state()=None, create may raise -> fallback
            obj = gr_contour[name]; st = obj.get_state()
            p = {"field": fld, "surfaces_list": list(surfaces)}
            if isinstance(st, dict):
                if "node_values" in st: p["node_values"] = True
                if "filled" in st: p["filled"] = True
                if "contour_lines" in st: p["contour_lines"] = False
                if "boundary_values" in st: p["boundary_values"] = True
            if extra and isinstance(st, dict):
                p.update({k: v for k, v in extra.items() if k in st})
            obj.set_state(p)
            log(f"FIELD_OK {name}={fld}")
            return obj, fld
        except Exception as e:
            log(f"FIELD_TRY {name}={fld} FAIL {repr(e)[:100]}")
    log(f"FIELD_ALLFAIL {name} candidates={candidates}")
    return None, None


def main():
    if os.path.exists(OUT):
        os.remove(OUT)
    os.makedirs(IMG, exist_ok=True)
    os.environ["AWP_ROOT241"] = r"D:\ansys2024\ANSYS Inc\v241"
    data = {}
    s = None
    try:
        # --- launch (F8/env: headless rendering OK; start_watchdog=False otherwise it pops Notepad) ---
        s = launch_fluent(product_version="24.1.0", mode=FluentMode.SOLVER, precision="double",
                          processor_count=4, show_gui=False, cleanup_on_exit=False,
                          cwd=WORKDIR, start_timeout=180, start_watchdog=False)
        safe("READ", lambda: s.tui.file.read_case_data(CASE))

        # --- shadow topology distinguishes aircraft vs box (VERIFIED-WORKING) ---
        # In a conforming mesh, interior/wall faces have paired "<name>-shadow" twins; the outer-domain box has no shadow twin.
        fi = s.field_info
        sinfo = fi.get_surfaces_info()
        names = list(sinfo.keys())
        nonshadow = [n for n in names if not n.endswith("-shadow")]
        aircraft = [n for n in nonshadow if (n + "-shadow") in names]        # aircraft outer surface (has a shadow twin)
        box_list = [n for n in nonshadow if (n + "-shadow") not in names]    # outer-domain box (no shadow twin)
        box = box_list[0] if box_list else None
        log(f"AIRCRAFT_N={len(aircraft)} BOX={box}")
        if not aircraft:
            raise RuntimeError("No aircraft outer surface identified (no -shadow twin) — check whether the mesh is conforming")

        tui, gr = s.tui, s.results.graphics

        # --- global imaging settings ---
        safe("AXES_OFF", lambda: tui.display.set.windows.axes.visible("no"))
        safe("LOGO_OFF", lambda: tui.display.set.windows.logo("no"))
        safe("PNG", lambda: tui.display.set.picture.driver.png())
        safe("WINRES", lambda: tui.display.set.picture.use_window_resolution("no"))
        safe("XRES", lambda: tui.display.set.picture.x_resolution(IMG_X))
        safe("YRES", lambda: tui.display.set.picture.y_resolution(IMG_Y))

        # --- domain-range recomposed image: use box x/z ranges to compute the domain center -> pan to bring the aircraft to screen center (F8-cont) ---
        # VERIFIED-WORKING: get_scalar_field_range first with node_value=True then falls back; surface_ids must be a list.
        panx, panz = PAN_DEFAULT
        if box is not None:
            sid = sinfo[box].get("surface_id")
            sid = sid if isinstance(sid, list) else [sid]

            def rng(field):
                for kw in (dict(node_value=True, surface_ids=sid), dict(surface_ids=sid)):
                    try:
                        r = fi.get_scalar_field_range(field, **kw)
                        if r and len(r) == 2:
                            return r
                    except Exception as e:
                        log(f"RNG_{field}_FAIL {repr(e)[:120]}")
                return None
            xr = rng("x-coordinate"); zr = rng("z-coordinate")
            log(f"XR={xr} ZR={zr}")
            if xr:
                panx = CX - (xr[0] + xr[1]) / 2.0
            if zr:
                panz = CZ - (zr[0] + zr[1]) / 2.0
        log(f"PAN=({panx:.3f},{panz:.3f}) ZOOM={ZOOM}")

        # --- longitudinal cross-section (through the body center, normal +Y) ---
        safe("PLANE", lambda: tui.surface.plane_point_n_normal("plane-y", CX, CY, CZ, 0, 1, 0))

        # --- reliable save (F8): delete the old file first to avoid the overwrite prompt, then save ---
        def save(fn):
            p = os.path.join(IMG, fn)
            if os.path.exists(p):
                os.remove(p)
            tui.display.save_picture(p)
            ok = os.path.exists(p)
            log(f"IMG_{fn}={'OK' if ok else 'MISS'} {os.path.getsize(p) if ok else 0}")

        # --- cross-section imaging: display -> restore top (view XZ) -> auto-scale -> pan -> zoom -> save (F8) ---
        def plane_shot(name, fn, kind="contour"):
            try:
                getattr(gr, kind)[name].display()
            except Exception:
                tui.display.objects.display(name)
            safe("RVp", lambda: tui.display.views.restore_view("top"))
            safe("ASp", lambda: tui.display.views.auto_scale())
            safe("PANp", lambda: tui.display.views.camera.pan_camera(panx, panz))
            safe("ZOOMp", lambda: tui.display.views.camera.zoom_camera(ZOOM))
            save(fn)

        # --- surface imaging: display -> restore isometric -> auto-scale (repeat once to settle) -> save (F8) ---
        # The body is framed automatically, no pan needed; repeating display+restore+auto-scale ensures a redraw with the new camera.
        def wall_shot(name, fn, view="isometric"):
            try:
                gr.contour[name].display()
            except Exception:
                tui.display.objects.display(name)
            safe("RVw", lambda: tui.display.views.restore_view(view))
            safe("ASw", lambda: tui.display.views.auto_scale())
            try:
                gr.contour[name].display()
            except Exception:
                pass
            safe("RVw2", lambda: tui.display.views.restore_view(view))
            safe("ASw2", lambda: tui.display.views.auto_scale())
            save(fn)

        # ================= 1) aircraft outer-surface Cp / static pressure (multi-view) =================
        # field: "pressure-coefficient" = Cp (depends on reference values, only shows the pattern when estimated); "pressure" = static pressure.
        for field, tag in [("pressure", "cfd_pressure"), ("pressure-coefficient", "cfd_cp")]:
            o, _ = first_field(gr.contour, tag, [field], aircraft)
            if o is None:
                continue
            for v in ["isometric", "left", "top"]:
                safe(f"SURF_{tag}_{v}", lambda nm=tag, fn=f"{tag}_{v}.png", vw=v: wall_shot(nm, fn, vw))

        # ================= 2) cross-section field plots: velocity magnitude / static pressure / Mach =================
        o, _ = first_field(gr.contour, "f_vel", ["velocity-magnitude"], ["plane-y", *aircraft])
        if o: safe("VELPLANE", lambda: plane_shot("f_vel", "pro_velocity_plane.png"))
        o, _ = first_field(gr.contour, "f_p", ["pressure"], ["plane-y", *aircraft])
        if o: safe("PPLANE", lambda: plane_shot("f_p", "pro_pressure_plane.png"))  # nose stagnation ≈ q is a physical self-check
        o, _ = first_field(gr.contour, "f_mach", ["mach-number"], ["plane-y", *aircraft])
        if o: safe("MACHPLANE", lambda: plane_shot("f_mach", "pro_mach_plane.png"))

        # ================= 3) streamlines (released from plane-y, along velocity) =================
        # VERIFIED-WORKING: the pathline release-surface key name varies by build -> probe the state keys, try three names.
        # Prefer streamlines over vectors: cross-section vectors are unusable under zoom because arrows get too large (pro_vectors_plane.png was already removed from the project).
        def streamlines():
            try:
                gr.pathline.create("pl")
            except Exception:
                gr.pathline["pl"] = {}
            obj = gr.pathline["pl"]; st = obj.get_state()
            log("PATHLINE_KEYS=" + json.dumps(list(st.keys()) if isinstance(st, dict) else str(st), default=str))
            p = {}
            if isinstance(st, dict):
                if "field" in st: p["field"] = "velocity-magnitude"
                for k in ("surfaces_list", "release_from_surfaces", "surfaces"):
                    if k in st:
                        p[k] = ["plane-y"]; break
                if "skip" in st: p["skip"] = 20
                if "step" in st: p["step"] = 500
            obj.set_state(p)
            plane_shot("pl", "pro_streamlines_plane.png", kind="pathline")
        safe("STREAMLINES", streamlines)

        # ================= 4) wall shear stress / y+ surface contour plots =================
        # Skin-friction field-name candidates: "wall-shear" is the one that matches (bare "wall-shear-stress" often fails) — VERIFIED-WORKING.
        o, _ = first_field(gr.contour, "f_tau",
                           ["wall-shear-stress", "wall-shear", "x-wall-shear-stress"], aircraft)
        if o: safe("TAUWALL", lambda: wall_shot("f_tau", "pro_wallshear_iso.png"))
        o, _ = first_field(gr.contour, "f_yp", ["y-plus"], aircraft)   # the rendered image is node-averaged y+
        if o: safe("YPWALL", lambda: wall_shot("f_yp", "pro_yplus_iso.png"))

        # ================= 5) force / moment compute + coefficients =================
        rd = s.solution.report_definitions

        def setup_force(nm, kind, vec=None, axis=None):
            try:
                getattr(rd, kind).create(nm)
                st = {"zones": aircraft}
                if vec is not None:
                    st["force_vector"] = vec
                if axis is not None:
                    # F7: the default report_output_type is "Drag Coefficient" (moment coefficient, /q·A·L);
                    # to get raw N·m you must explicitly set "Drag Force". After creation, read back the full state to check for hidden default keys.
                    st["mom_center"] = MOM_CENTER
                    st["mom_axis"] = axis
                    st["report_output_type"] = "Drag Force"
                getattr(rd, kind)[nm].set_state(st)
                back = getattr(rd, kind)[nm].get_state()
                log(f"RD_{nm}_OUTTYPE={back.get('report_output_type')}")   # F7 read-back check
            except Exception as e:
                log(f"RD_{nm}_ERR {repr(e)[:150]}")
        setup_force("drag_f", "force", vec=DRAG_DIR)
        setup_force("lift_f", "force", vec=LIFT_DIR)
        setup_force("side_f", "force", vec=SIDE_DIR)
        setup_force("roll_m", "moment", axis=[1, 0, 0])
        setup_force("pitch_m", "moment", axis=[0, 1, 0])
        setup_force("yaw_m", "moment", axis=[0, 0, 1])

        # compute uses the same convention as the report_files monitor; returns list[dict], a value may be a list so take [0].
        comp = safe("COMPUTE", lambda: rd.compute(
            report_defs=["drag_f", "lift_f", "side_f", "roll_m", "pitch_m", "yaw_m"]))
        vals = {}
        try:
            for d in (comp or []):
                for k, v in d.items():
                    vals[k] = v[0] if isinstance(v, list) else v
        except Exception as e:
            log(f"COMPUTE_PARSE_ERR {repr(e)[:150]}")
        log(f"FORCES={json.dumps(vals, default=repr)}")
        data["forces"] = vals

        # mass conservation (output is in the transcript; the Net/inlet flux ratio is the imbalance, must eyeball)
        safe("MASS", lambda: s.tui.report.fluxes.mass_flow())

        # ================= 6) per-facet y+ numeric extraction (F5, for auditing) =================
        # VERIFIED-WORKING: field_data transaction; node_value=False, boundary_value=True takes the facet boundary values.
        # Calling get_scalar_field_data directly returns empty; session.fields does not exist. The rendered image is node-averaged (biased low); audit references use this facet array.
        def yplus_facets():
            fd = s.field_data
            yvals = []
            for wname in aircraft:                            # multiple walls: accumulate facets zone by zone
                try:
                    sid_w = sinfo[wname].get("surface_id")
                    sid_w = sid_w if isinstance(sid_w, list) else [sid_w]
                    tx = fd.new_transaction()
                    tx.add_scalar_fields_request(field_name="y-plus", surface_ids=sid_w,
                                                 node_value=False, boundary_value=True)
                    payload = tx.get_fields()

                    def walk(node, depth=0):
                        if depth > 6:
                            return
                        if isinstance(node, dict):
                            for v in node.values():
                                walk(v, depth + 1)
                        else:
                            try:
                                arr = [float(x) for x in node]    # leaves are numpy arrays
                                if arr:
                                    yvals.extend(arr)
                            except Exception:
                                pass
                    walk(payload)
                except Exception as e:
                    log(f"YPLUS_{wname}_FAIL {repr(e)[:120]}")
            if yvals:
                yvals.sort(); n = len(yvals)
                def pct(p): return yvals[min(n - 1, int(p / 100.0 * n))]
                def frac(lo, hi): return sum(1 for v in yvals if lo <= v < hi) / n * 100
                yp = {"count": n, "min": yvals[0], "max": yvals[-1], "mean": sum(yvals) / n,
                      "median": pct(50), "p5": pct(5), "p95": pct(95),
                      "frac_lt11": frac(0, 11), "frac_11_30": frac(11, 30),
                      "frac_30_100": frac(30, 100), "frac_100_300": frac(100, 300),
                      "frac_ge300": frac(300, float("inf"))}
                data["yplus"] = yp
                log(f"YPLUS_FACET={json.dumps(yp)}")
            else:
                log("YPLUS_FACET=EMPTY (check surface_ids / field name)")
        safe("YPLUSFACET", yplus_facets)

        # ================= 7) write the markdown summary (mirrors results_summary) =================
        def g(k): return vals.get(k)
        drag, lift, side = g("drag_f"), g("lift_f"), g("side_f")
        roll, pitch, yaw = g("roll_m"), g("pitch_m"), g("yaw_m")

        def fN(x): return f"{x:.3f}" if isinstance(x, (int, float)) else "N/A"
        def cF(x): return f"{x / (Q * REF_AREA):.4f}" if isinstance(x, (int, float)) else "N/A"          # force coefficient
        def cM(x): return f"{x / (Q * REF_AREA * REF_LEN):.5f}" if isinstance(x, (int, float)) else "N/A"  # moment coefficient
        ld = (lift / drag) if isinstance(lift, (int, float)) and isinstance(drag, (int, float)) and drag else None
        ld_s = f"{ld:.2f}" if ld else "N/A"

        with open(SUMMARY, "w", encoding="utf-8") as f:
            f.write(f"""# {os.path.basename(CASE).split('.')[0]} — conforming CFD results summary

> Flow case: U={U:.3f} m/s, α={ALPHA}°, β=0; far-field; k-ω SST;
> q = ½ρU² = {Q:.1f} Pa; reference area {REF_AREA} m² (estimated); reference length {REF_LEN} m; moment center {MOM_CENTER} (estimated).
> **Coefficients are process-validation level** (estimated reference values + first-order upwind over-estimates drag by ~10-25%): not for design use.

## Aerodynamic forces (integrated over the aircraft outer surface)

| Quantity | Value | Unit |
|---|---:|---|
| Drag | {fN(drag)} | N |
| Lift | {fN(lift)} | N |
| Side force | {fN(side)} | N |
| Rolling moment Mx | {fN(roll)} | N·m |
| Pitching moment My | {fN(pitch)} | N·m |
| Yawing moment Mz | {fN(yaw)} | N·m |
| L/D | {ld_s} | - |

## Aerodynamic coefficients (reference values are estimated → process-validation only, not for design use)

| Coefficient | Value |
|---|---:|
| Cd | {cF(drag)} |
| Cl | {cF(lift)} |
| Cy | {cF(side)} |
| Cm_pitch | {cM(pitch)} |

## Important limitations (must-read for professional use)
- **First-order upwind**: drag is systematically over-estimated by numerical dissipation (~10-25%); second-order diverged in this compressible flow case and could not be used. Drag is process-validation level.
- **Reference area / moment center are estimated values**: coefficients cannot be a design conclusion; recompute with the true wing area and CG.
- **No boundary-layer mesh / wall-function-level y+**: limited accuracy for wall shear stress and separation prediction (see pro_yplus_iso.png; for y+ references, the facet values are authoritative).
- **Geometry is the 8-solid-body aero-core simplified subset**, propeller ignored (no slipstream).
- **Forces are steady but have not reached design-grade residual convergence**: Cp / field-plot patterns are credible, treat absolute values with caution.

## Image files ({os.path.basename(IMG)}\\)
- Surface Cp / pressure: cfd_cp_{{isometric,left,top}}.png, cfd_pressure_{{isometric,left,top}}.png
- Surface skin friction / y+: pro_wallshear_iso.png, pro_yplus_iso.png
- Field plots (longitudinal cross-section y={CY}, recomposed and centered): pro_velocity_plane.png (wake), pro_pressure_plane.png (nose stagnation ≈ q), pro_mach_plane.png, pro_streamlines_plane.png
- Note: cross-section vectors are unusable under zoom because arrows get too large, switched to streamlines; centered cropping (compositing the color bar + a centered aircraft with System.Drawing) is a separate post-processing step per docs/07.
""")
        log(f"SUMMARY_WRITTEN={SUMMARY}")
        log("POSTPRO_IMAGING_DONE: please read out each PNG and visually inspect that the view/range is correct")
    except Exception as e:
        data["fatal"] = repr(e); log(f"FATAL={repr(e)}"); log(traceback.format_exc())
    finally:
        if s is not None:
            try:
                s.exit()      # note: even a normal exit leaves about 2 fluent processes holding a license; clear them (including mpiexec) before the next launch
            except Exception:
                pass


if __name__ == "__main__":
    main()
