# Environment and Operational Hygiene (probed and verified on the authoring machine)

> The following is the measured environment of the machine that hosts the Javelin_V1 project (Windows 11, DESKTOP-7TBD1T1).
> **These are concrete example values from the authoring machine — locate the equivalents on your own computer.**
> **Always re-probe when you switch machines**: the system PATH may not have python; the PyFluent version dictates the API key names (this package is written against 0.17.1).
> If your probe disagrees with what is written here, trust the measurement and update this file.

---

## Python interpreter

The system PATH has **no** python / py. Use the CPython bundled with Ansys:

```
D:\ansys2024\ANSYS Inc\v241\commonfiles\CPython\3_10\winx64\Release\python\python.exe
```

(Example from the authoring machine — locate the equivalent on your computer. How to find it: under your Ansys install root, look at `<AnsysRoot>\v<NNN>\commonfiles\CPython\3_10\winx64\Release\python\python.exe`. If you don't know the install root, see the "Fluent executable and license" section below for how to find it.)

Running a script (you must first ensure the CWD is the working directory; module imports depend on the CWD):

```powershell
& 'D:\ansys2024\ANSYS Inc\v241\commonfiles\CPython\3_10\winx64\Release\python\python.exe' .\your_script.py
```

---

## PyFluent (legacy 0.17.1 — API key names are critical)

It is not in the default site-packages, so it must be injected at the top of the script:

```python
import sys
sys.path.insert(0, r"D:\ansys2024\ANSYS Inc\v241\optiSLang\lib\python3.10\Lib\site-packages")
from ansys.fluent.core import launch_fluent
from ansys.fluent.core.launcher.launcher import FluentMode
```

(The path above is an example from the authoring machine — locate the equivalent on your computer. How to find it: the PyFluent 0.17.1 site-packages ships inside optiSLang, at `<AnsysRoot>\v<NNN>\optiSLang\lib\python3.10\Lib\site-packages`. Confirm your version with `<that python.exe> -c "import ansys.fluent.core as c; print(c.__version__)"` — this package assumes 0.17.1; a different version may change the API key names.)

> In 0.17.1 the key names / object paths differ from the newer PyFluent documentation on the official site; writing against the new API will fail (F2/F5/F7 and the far-field keys all stem from this). Whenever you hit an unknown key name, always `get_state()` to inspect the real structure before you `set_state()` (see playbook §0).
> After every set_state you must read back to verify — 0.17.1 is full of the pitfall where "a wrong key name silently no-ops and stays at the Fluent default value"
> (the far-field `mach_number` gets ignored and silently stays at the default Ma~0.6; see playbook §3 / the 04 failure library).

---

## Fluent executable and license

```
Fluent:   D:\ansys2024\ANSYS Inc\v241\fluent\ntbin\win64\fluent.exe
Version:  product_version="24.1.0"
License:  1055@localhost (4-core parallel)
Env var:  AWP_ROOT241 = D:\ansys2024\ANSYS Inc\v241
```

(Everything in this block is an example from the authoring machine — locate the equivalents on your computer.
- **Ansys install root**: here it is `D:\ansys2024\ANSYS Inc\v241`. How to find it: check the `AWP_ROOT241` environment variable (`$env:AWP_ROOT241` in PowerShell) — the trailing `241` matches your version; for 2024 R2 it would be `AWP_ROOT242`, etc. If that env var is unset, search your drives for a `fluent.exe` under `...\fluent\ntbin\win64\`.
- **Fluent exe**: `<AnsysRoot>\fluent\ntbin\win64\fluent.exe`.
- **Version string**: `product_version="24.1.0"` corresponds to v241 (2024 R1). Match this to your installed release.
- **License server `1055@localhost`**: this means the license daemon is on the local machine at port 1055. How to find yours: check the `ANSYSLMD_LICENSE_FILE` environment variable, or open the Ansys License Management Center; the format is `<port>@<host>`. The 4-core cap reflects this machine's seat — yours may differ.)

### Launch parameters (the same set in every script; see playbook §1 / scripts)

```python
import os
os.environ["AWP_ROOT241"] = r"D:\ansys2024\ANSYS Inc\v241"
s = launch_fluent(
    product_version="24.1.0",
    mode=FluentMode.SOLVER,    # solver mode
    precision="double",        # double precision
    processor_count=4,         # 4 cores (= license cap)
    show_gui=False,            # headless; can still render white-background PNGs (F8)
    cleanup_on_exit=False,     # don't clean up, keep the case/data
    cwd=WORKDIR,               # must be passed explicitly — module imports depend on the CWD
    start_timeout=180,
    start_watchdog=False,      # the watchdog pops up Notepad; must be disabled in this environment
)
```

Item-by-item rationale:
- `mode=SOLVER`: a solver session (`FluentMode` is imported from `ansys.fluent.core.launcher.launcher`).
- `precision="double"` / `processor_count=4`: double precision, 4-core parallel (the license is exactly 4 cores).
- `show_gui=False`: headless run; this does not prevent rendering images (F8 can render white-background PNGs).
- `start_watchdog=False`: **in this environment the watchdog pops up a Notepad window**, so it must be disabled.
- `cwd=WORKDIR`: the working directory must be passed explicitly, otherwise the relative imports / relative paths inside the script won't be found (see "Python interpreter").

---

## The single-license-seat reality (internalize this first, or you will hit F11 over and over)

**There is only one license seat (1055@localhost, 4 cores); only one Fluent can run at a time.** (The `1055@localhost` and 4-core figures are example values from the authoring machine — see the "Fluent executable and license" section for how to find your own.)

- Any orphan process left over from a previous round (**especially mpiexec**), as long as it still holds the seat/port, will cause the next
  `launch_fluent` to report **`Connection refused`** (gRPC cannot connect to the Fluent server) — this is exactly **F11**.
- Fluent's parallel solve is **orchestrated by mpiexec**: a round that gets killed will leave behind **~20 mpiexec** processes + 1 orphan solver;
  the orphan solver's python client is already dead, so it **will never persist anything to disk** — it just wastes the seat.
- **A crash** leaves zombies; **and in practice even a normal `session.exit()` leaves ~2 lingering fluent processes** holding the license.
  So **no matter how the previous round ended, you must run the full-family cleanup below before every new launch.**

---

## Process hygiene (mandatory before every launch — clean the whole process family)

```powershell
# 1) Kill the whole family — MUST include mpiexec! Killing only fluent,python leaves ~20 mpiexec orchestration processes + the orphan solver
Get-Process fluent,mpiexec,cortex,python -ErrorAction SilentlyContinue | Stop-Process -Force -Confirm:$false

# 2) Wait for the seat/port to be released (you cannot launch immediately — the release won't have happened yet)
Start-Sleep 10

# 3) Read back to verify it is empty — this must return nothing before you start the next run
Get-Process fluent,mpiexec -ErrorAction SilentlyContinue
```

Iron laws:
- **Must include `mpiexec`** (as well as `cortex` and `python`). Killing only `fluent,python` was this package's early, incomplete approach —
  it leaves ~20 mpiexec + the orphan solver holding the single seat, causing `Connection refused` on the next launch (F11).
- **After killing, first `Start-Sleep 10`, then read back with `Get-Process fluent,mpiexec` to confirm it is empty**, and only then start.
- **Never kill + launch in the same command** — the seat/port won't be released in time, and you'll still get `Connection refused`.
  Do it in two steps, with a sleep and a read-back verification in between.
- Run only one Fluent at a time (4 cores, single seat); before a new solve, confirm the previous one has exited and the whole process family is cleared.

> Orphan-impersonation trap: after a restart, if you see the report history rows still climbing (iter 72→112→154), **it may be the old orphan solver writing, not the new run**.
> A genuine restart **resets the report file**; if the file was not reset, the old orphan is still alive — you are watching the wrong process (see "Long tasks and log hygiene" below).

---

## Long tasks and log hygiene

- **Run in the background + poll the `.out`**, do not block waiting. Script convention: write `<scriptname>.out` live and write a `<scriptname>.json` summary at the end.
- **Judge liveness by report-FILE row growth, not by process CPU.** On this machine the host/wrapper process CPU **often reads 0%**, even while Fluent is iterating —
  "CPU=0 ≠ stalled." The correct liveness signal is the **row count growing** in the report-monitored `.out` / history file (force_moment_hist).
- **A locked report file can masquerade as a stall**: when it is held / locked by another handle, the history shows **stale (no new rows)**,
  even though the run is healthy and running — this has caused a **healthy run to be killed by mistake** before. So neither signal can be trusted alone.
  **Cross-check the PER_ITER / ITER milestone prints in the script's `.out`**: as long as the `.out` is still advancing iterations, the run is alive,
  regardless of what the (possibly locked/stale) history file shows. Poll roughly every 10 minutes, watching history-row growth rather than process CPU.
- **The transcript (`fluent-*.trn`) can be enormous** (F3 once spammed 9.8 million rows): read it locally with `Select-String` / `Get-Content -Tail`,
  **never read the whole file in.**
  ```powershell
  Select-String -Path .\fluent-*.trn -Pattern 'tetrahedral|wedge|converged' -Context 1,1
  ```
- Save the key intermediate artifacts (case/data) **immediately** after iterate (the F3 lesson).

---

## Working-directory conventions (recommended)

| Type | Naming |
|---|---|
| Flow-case definition | `<case>_input.yaml` |
| Mesh | `<case>_extmesh.msh.h5` + mesh script `.out/.json` |
| Converged-solution archive | `<case>_alphaN.cas.h5` / `.dat.h5` |
| Force/moment history | `<case>_force_moment_history.out` (written to disk by report_files) |
| Solver / post-processing scripts | `pyfluent_<case>_solver.py` etc. + their own `.out/.json` |
| Images | PNGs under `<case>_images/` |
| Execution log | `<case>_agent_session_log.md` (**all failures and fixes are appended here**) |
| Report | `<case>_initial_report.md` |

> The execution log is the pitfall-avoidance map for the next agent — **every new failure/fix must be appended to it.**

---

## Related failure entries (see `04_failure_recovery.md` for details)

- **F1**: SpaceClaim headless STEP→FMD conversion crash (AccessViolation); use the FMD cache, do not let FTM import the .step.
  (Note: F1 only applies to the fault-tolerant import path; the watertight/conforming workflow can import STEP directly without crashing.)
- **F9**: Headless fault-tolerant WRAP meshing won't refine (the size field locks in on the first pass, and 3 refinement attempts had no effect); switch to conforming/watertight or solve multi-region directly (see `06_meshing_strategy.md`).
- **F11**: A crash/exit leaves zombies (including ~20 mpiexec + the orphan solver) holding the single seat → the next `launch_fluent` reports `Connection refused`; the fix is the full-family cleanup (kill `fluent,mpiexec,cortex,python`) + `Start-Sleep 10` + read back empty + never kill+launch in the same command.
