# Reference audit script — read from disk (no re-solve) to audit convergence / quality / y+ / moment units
# ============================================================================
# Corresponds to docs/02_pyfluent_playbook.md §6/§7/§9; fixes F5 (y+ extraction), F7 (moment units).
# Reads an already-saved case/data; does not modify or re-save (moment-definition type changes are not persisted to disk).
# Produces: last-200-step statistics for force/moment, empirical moment-coefficient<->N·m conversion, y+ distribution fractions.
# ============================================================================

import json
import os
import sys
import traceback

sys.path.insert(0, r"D:\ansys2024\ANSYS Inc\v241\optiSLang\lib\python3.10\Lib\site-packages")
from ansys.fluent.core import launch_fluent
from ansys.fluent.core.launcher.launcher import FluentMode

# ===== Modify per case =====
WORKDIR     = r"C:\Users\oc\Desktop\Codex_Ansys"
CASE_DATA   = os.path.join(WORKDIR, "your_case_alpha3.cas.h5")
REPORT_FILE = os.path.join(WORKDIR, "your_case_force_moment_history.out")
OUT         = os.path.join(WORKDIR, "postproc_audit_reference.out")
JSON_OUT    = os.path.join(WORKDIR, "postproc_audit_reference.json")
WALL_NAME   = "javelin_v1_aero_core_fused_validation.1"   # zone name of the wall the force acts on
MOMENTS     = ["roll_moment", "pitch_moment", "yaw_moment"]
WINDOW      = 200
# ===== End of constants block =====


def log(m):
    with open(OUT, "a", encoding="utf-8") as f:
        f.write(str(m) + "\n")


def parse_history(window=WINDOW):
    rows, header = [], None
    with open(REPORT_FILE, "r", errors="ignore") as f:
        for line in f:
            parts = line.replace('"', "").replace("(", "").replace(")", "").split()
            try:
                vals = [float(x) for x in parts]
                if vals:
                    rows.append(vals)
            except ValueError:
                if parts and parts[0].lower() == "iteration":
                    header = parts
    if not rows:
        return {"error": "NO_ROWS"}
    dedup = {r[0]: r for r in rows}            # a restarted/continued run may overlap iteration numbers: dedup, keeping the last
    rows = [dedup[k] for k in sorted(dedup)]
    tail = rows[-window:]
    names = header if header else [f"col{i}" for i in range(len(rows[-1]))]
    out = {"total_rows": len(rows), "last_iter": rows[-1][0], "window": len(tail), "stats": {}}
    for i, nm in enumerate(names):
        if nm.lower() == "iteration":
            continue
        col = [r[i] for r in tail if len(r) > i]
        if not col:
            continue
        mean = sum(col) / len(col)
        out["stats"][nm] = {"last": col[-1], "mean": mean, "min": min(col), "max": max(col),
                            "fluct_pct": (max(col) - min(col)) / abs(mean) * 100 if mean else None}
    return out


def main():
    for p in [OUT, JSON_OUT]:
        if os.path.exists(p):
            os.remove(p)
    os.environ["AWP_ROOT241"] = r"D:\ansys2024\ANSYS Inc\v241"
    data = {}
    session = None
    try:
        session = launch_fluent(
            product_version="24.1.0", mode=FluentMode.SOLVER, precision="double",
            processor_count=4, show_gui=False, cleanup_on_exit=False,
            cwd=WORKDIR, start_timeout=120, start_watchdog=False,
        )
        session.tui.file.read_case_data(CASE_DATA)
        log("READ_CASE_DATA=OK")

        # --- Force/moment history statistics ---
        data["force_history"] = parse_history()
        log(f"FORCE_HISTORY={json.dumps(data['force_history'], default=repr)[:1500]}")

        # --- Mass conservation ---
        session.tui.report.fluxes.mass_flow()   # output goes to the transcript; the Net/flux ratio is the imbalance

        # --- F7: moment-unit verification (coefficient -> N·m) ---
        rd = session.solution.report_definitions
        coeff = rd.compute(report_defs=MOMENTS)
        log(f"MOMENT_COEFF={coeff}")
        for n in MOMENTS:
            rd.moment[n].set_state({"report_output_type": "Drag Force"})  # raw N·m
            assert rd.moment[n].get_state()["report_output_type"] == "Drag Force"
        raw = rd.compute(report_defs=MOMENTS)
        log(f"MOMENT_RAW_Nm={raw}")

        def flat(lst):
            return {k: (v[0] if isinstance(v, list) else v) for d in lst for k, v in d.items()}
        c, r = flat(coeff), flat(raw)
        data["moments"] = {n: {"coeff": c[n], "Nm": r[n],
                               "ratio_qAL": (r[n] / c[n] if c[n] else None)} for n in MOMENTS}
        log(f"MOMENTS={json.dumps(data['moments'])}")  # ratio should all equal q*A*L

        # --- F5: per-facet y+ distribution ---
        fd, fi = session.field_data, session.field_info
        sid = fi.get_surfaces_info()[WALL_NAME]["surface_id"]
        tx = fd.new_transaction()
        tx.add_scalar_fields_request(field_name="y-plus", surface_ids=sid,
                                     node_value=False, boundary_value=True)
        payload = tx.get_fields()
        vals = []

        def walk(node, depth=0):
            if depth > 6:
                return
            if isinstance(node, dict):
                for v in node.values():
                    walk(v, depth + 1)
            else:
                try:
                    arr = [float(x) for x in node]
                    if arr:
                        vals.extend(arr)
                except Exception:
                    pass
        walk(payload)
        if vals:
            vals.sort(); n = len(vals)
            def pct(p): return vals[min(n - 1, int(p / 100.0 * n))]
            def frac(lo, hi): return sum(1 for v in vals if lo <= v < hi) / n * 100
            data["yplus"] = {
                "count": n, "min": vals[0], "max": vals[-1], "mean": sum(vals) / n,
                "median": pct(50), "p5": pct(5), "p95": pct(95),
                "frac_lt11": frac(0, 11), "frac_11_30": frac(11, 30), "frac_30_100": frac(30, 100),
                "frac_100_300": frac(100, 300), "frac_ge300": frac(300, float("inf")),
            }
            log(f"YPLUS={json.dumps(data['yplus'])}")
        else:
            # fallback: range only
            data["yplus_range"] = repr(fi.get_scalar_field_range("y-plus", node_value=False, surface_ids=sid))
            log(f"YPLUS_RANGE={data['yplus_range']}")
    except Exception as e:
        data["fatal"] = repr(e); log(f"FATAL={repr(e)}"); log(traceback.format_exc())
    finally:
        with open(JSON_OUT, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False, default=repr)
        if session is not None:
            try:
                session.exit()
            except Exception:
                pass


if __name__ == "__main__":
    main()
