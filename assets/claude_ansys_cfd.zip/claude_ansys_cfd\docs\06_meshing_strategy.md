# Meshing strategy — wrap vs conforming vs direct multi-region solve (external-flow CFD)

> Purpose: pick the right one of three external-flow meshing routes, and understand the real limits of each under **headless PyFluent 0.17.1**.
> This is a **concept + decision** document; the concrete API key names / TUI strings live in
> [`02_pyfluent_playbook.md`](02_pyfluent_playbook.md), and the detailed explanations of failures F1/F6/F9/F10 are in
> [`04_failure_recovery.md`](04_failure_recovery.md). The final result numbers/figures for this case are in
> [`../examples/Javelin_V1_case_study.md`](../examples/Javelin_V1_case_study.md).

Iron law 1 runs through the whole document: **a CAD solid body is not the fluid domain**; what gets solved is the air volume left over after "bounding box minus aircraft" — never the solid body itself.

---

## 0. The three-route decision table (read this first)

| | **A. fault-tolerant WRAP (envelope)** | **B. watertight CONFORMING (conforming)** | **C. DIRECT-SOLVE multi-region conforming (this case's breakthrough)** |
|---|---|---|---|
| Workflow | `wf.fault_tolerant(...)` | `wf.watertight(...)` | watertight generation → directly solve the multi-region mesh |
| Surface | wraps an **envelope skin**, **discards CAD faces**, grows **spikes** at thin edges / wingtips | **conforms to the real CAD faces**, smooth | same as B, conforming and smooth |
| STEP import | headless SpaceClaim conversion **crashes** (**F1**) → must feed an FMD cache | **reads STEP directly, no crash** (different importer, no F1) | same as B, reads STEP directly |
| Surface size control | the size field **locks** the first time "Default" executes; headless **cannot change it** (**F9**) | `CFDSurfaceMeshControls.{MinSize,MaxSize,SizeFunctions,CurvatureNormalAngle}` **take effect directly** | same as B |
| Single fluid region | enclosure task builds it automatically (dirty geometry → dirty result) | **no enclosure task**; a dirty fluid_domain yields ~10 flow volumes (topology error) | **single region not extracted at all**; directly solve ~10 regions |
| Region control (headless) | — | `Create/Update Regions` **fail entirely** (0.17.1 headless, same stubbornness as F6/F9) | bypassed: don't touch the regions, solve directly |
| Boundary conditions | split the 6 faces into velocity-inlet/pressure-outlet/symmetry | needs a clean single region prepared in advance | one face of the outer box is **pressure-far-field**; 9 sealed internal cavities stagnate, harmless |
| Use case | **dirty multi-body emergency** (multi-body with gaps, get a mesh out temporarily) | **clean closed solid body** (and the single region is already prepared in the GUI) | when the **solid body is clean but headless cannot extract a single region** |

**One-sentence selection**: geometry dirty and you only want "just get a mesh first" → A (accept lost CAD, coarse surface); geometry clean, you need smooth Cp plots, and you can prepare "box minus aircraft = single region" in the SpaceClaim GUI → B; geometry clean but **fully headless and a clean single region cannot be extracted** → C (the route this case took).

---

## 1. When to use which (decision basis)

Three axes: **geometry cleanliness** × **headless/GUI availability** × **whether smooth Cp / surface-field plots are needed**.

1. **Dirty geometry (multi-body, gaps, the 54-body kind) + you only want to get the pipeline running** → **A WRAP**.
   - wrap can "hard-wrap" over the gaps to produce a solvable volume mesh, at the cost of lost CAD faces, surface faceting, and wingtip spikes.
   - coefficients can only be process-validation grade; surface Cp plots will be visibly faceted — don't use them as design conclusions.
   - headless hard constraints: **STEP will crash (F1) → feed an FMD cache**; **size field locks (F9) → surface refinement has no effect**;
     after three attempts (GlobalMin override / update_dict after Default / disabling the size field) all fail, **cap it and stop** (measured upper bound 3 tries).

2. **Clean geometry (single closed solid body) + need smooth surface-field plots + have the SpaceClaim GUI** → **B CONFORMING**.
   - conforming preserves the CAD; `MinSize=1mm` gives a smooth 4.5MB surface (vs wrap's 21,110-face faceted skin).
   - prerequisite: you must **first make "enclosure box minus aircraft" into a single fluid region in the GUI** before entering watertight (see §2 caveat).

3. **Clean geometry + fully headless + headless cannot extract a clean single region** → **C DIRECT-SOLVE multi-region**.
   - this case's final breakthrough: stop fighting "single-region extraction" and directly solve the ~10-region conforming mesh (see §4).
   - cost: 9 sealed internal cavities stagnate (harmless, see §5), first-order throughout (second-order diverges, see §6), and you must have a volume mesh before producing images.

> Key clarification: **"the surface looks coarse" is almost always the fault of the wrap skin, not the CAD.** Measured, the STEP header is
> a single closed solid body (ADVANCED_BREP + 8 internal voids), and the FMD tessellates finely at 0.5mm deviation — the geometry itself is fine.
> When you see faceting/spikes, first ask "is this wrap-generated?" before suspecting the CAD.

---

## 2. Why conforming preserves the CAD while wrap discards it

- **wrap (A)**: fault-tolerant lays a ~5mm **envelope skin** on the **outside** of the part — essentially "regenerating an approximate outer skin" — and
  the real CAD faces are discarded; at thin edges / wingtips the skin fails to close and grows spikes. Its size field **locks** the first time "Default" executes,
  after which headless changes to GlobalMin / disabling the size field cannot move the surface resolution (the root cause of **F9**, the same class of stubbornness as F6's BL subtask being ignored).
  → low surface fidelity, Cp and other surface-field plots are faceted, **process-validation grade only**.

- **conforming (B/C)**: watertight uses a **different importer**, can **read STEP directly without crashing** (**F1 is limited to the fault-tolerant import path**),
  and meshes **conforming to the real CAD faces**. Surface sizes via
  `CFDSurfaceMeshControls.{MinSize, MaxSize, SizeFunctions="Curvature & Proximity", CurvatureNormalAngle}`
  **take effect directly** (not entangled with wrap's locked size field). Curved surfaces refine automatically, flat surfaces coarsen → smooth surface, trustworthy Cp plots.
  (Specific task key names and `update_dict` usage are in playbook §13.)

---

## 3. CAVEAT — watertight has no enclosure task (another pitfall beyond sealed-interior)

The watertight workflow's **task list only goes up to region identification of the geometry itself — there is no "external-flow enclosure / bounding box" task**. Consequences:

- you must **prepare clean geometry of "box minus aircraft = single fluid region" in advance** before feeding it into watertight.
- feeding a **dirty fluid_domain (box + aircraft as separate bodies, no real boolean subtraction)** directly: it gets identified as **~10 flow volumes** (topology error, **unsolvable**).
- in 0.17.1, **headless region control fails entirely** (the same stubborn root cause as F6/F9):
  - `Create Regions` set to `NumberOfFlowVolumes=1` → read back still 10;
  - `Update Regions` setting the 9 airframe sub-regions to `dead` → read back all `fluid`;
  - `Update Boundaries` throws the same `RuntimeError('Unknown exception')` as F1, and **actually corrupts the zone topology instead**.
- conclusion: **a truly clean single fluid region (enclosure box minus aircraft) can only be built in the SpaceClaim GUI**. Once built, mesh+solve+render can run fully headless.
  (The GUI step checklist is in the project-side `Javelin_V1_smooth_cfd_GUI_worklist.md`.)

> This is why this case did not take "clean B" but instead took §4's C: under a pure-headless constraint a clean single region cannot be extracted.

---

## 4. C — directly solve the multi-region conforming mesh (this case's final breakthrough)

Rather than extracting a single region from the dirty fluid_domain, **directly solve the 112MB ~10-region conforming mesh**:

1. the **external air region** uses a **single pressure-far-field** box boundary (the angle of attack is encoded via Mach + flow_direction, see below).
2. the **9 sealed airframe internal cavities** are left as **stagnant dead air cavities** — no through-flow, no effect on the external solution (harmless, see §5).
3. the **aircraft outer surface** bears the external pressure integral that yields force/moment. Use **shadow topology** to discriminate which zones are the aircraft skin:
   in a conforming mesh, internal/wall faces have a `-shadow` twin zone, the outer box does not.
   - `aircraft = [the 9 non-shadow zones for which a same-name + "-shadow" exists]`
   - `box      = [the 1 non-shadow zone with no "-shadow" twin → the outer box]`
   - note: that `(thread-n-faces ...)` approach of discriminating by face count returns None in 0.17.1, **unusable**; you can only rely on the shadow naming.
     (Code is in playbook §13 / `code:shadow-topology-discrimination`.)

**A hard gate to ensure the angle of attack takes effect (the silent failure of pressure-far-field)**:

- in 0.17.1, the pressure-far-field keys are the **short names** `m` (Mach), `t` (temperature), `flow_direction` ({value} list).
- using the seemingly reasonable long names `mach_number` / `temperature` **raises no error and has no effect** — the boundary **silently stays at Fluent's default Mach ~0.6 / T 300**,
  and you'll compute a transonic result at the wrong speed with no warning at all (the same class of silent-default trap as F2's inlet components and F7's report type).
- **FARFIELD_VERIFY gate (mandatory)**: after `set_state`, **read back** and assert; if it doesn't match, `raise` and abort:
  ```
  abs(got_m  - 0.245)   > 1e-4   -> abort   # target Mach
  abs(got_t  - 288.16)  > 0.1    -> abort   # target T (K)
  abs(got_dir[0] - 0.99863) > 1e-3 -> abort # flow_direction = AoA=3 deg unit vector
  ```
  (The outer-box zone only gets a BC object after being converted via TUI `/mesh/modify-zones/zone-type <id> pressure-far-field`;
  when read in, its native `pressure-far-field` type spams the "ideal gas law" warning, **F10**, which the type conversion/reconversion eliminates, harmless.)

**First-order throughout**: second-order upwind diverges instantly at the moment of switching in this compressible case (Ma 0.245, ideal-gas), so the **whole run stays first-order upwind** (see §6).
**Force already stable at 200 iter** (drag 16.95→16.7 N, <2%) → stop, produce images. The nose stagnation pressure reads +4590 Pa ≈ q (=½ρU²=4253.5 Pa), physically self-consistent.

---

## 5. sealed-interior caveat — why the sealed internal cavities are harmless

The C route left 9 **sealed airframe internal cavities** uncleaned. They are **harmless** to the external-flow solution, because:

- the cavities are **closed dead air cavities**: no inlet/outlet, no through-flow, and the air inside is **stagnant** (velocity ≈ 0).
- the external-flow force comes from the pressure/shear integral over the **aircraft outer surface**; the outer surface belongs to the aircraft zones that have a `-shadow` twin, **decoupled from the cavities**.
- the stagnant cavities neither inject momentum into the outer surface nor change the outer-surface pressure distribution → **they do not contaminate the external aerodynamic forces**.
- the only cost: a few extra stagnant cells computed (slows iteration slightly), in exchange for **bypassing the deadlock that headless fundamentally cannot extract a clean single region**, plus obtaining a smooth Cp field.

> So C is the pragmatic solution: rather than grinding against the failed control of "single-region extraction" (§3), it's better to accept that the cavities are harmless and directly solve the multiple regions.

---

## 6. Solver-side constraints (first-order/second-order, convergence criterion) — directly mesh-related

- **second-order diverges, stay on first-order**: the compressible C case diverges/hangs immediately when hard-switched to second-order upwind around iter~30; **first-order upwind throughout** is what stays stable
  (~18–20 s/iter, 112MB mesh).
- **the cost of first-order**: the numerical dissipation of first-order upwind **systematically overestimates drag by ~10–25%**. This case's conforming drag of 16.7 N is about 27% higher than wrap's incompressible 13.14 N,
  mostly from **first-order dissipation + compressibility**, **not a real aerodynamic difference**. → **Cp/field-plot shapes are trustworthy, absolute drag is process-validation grade only**.
- **default convergence criterion must be disabled**: Fluent's default 1e-3 residual will declare "converged" prematurely at ~48 steps (**F4**), with the force far from stable.
  Before solving, set `solution.monitor.residual` for each equation to `check_convergence=False`, and verify with a short probe iteration that it is disabled (playbook §8).

---

## 7. BL / wedge verification (the only criterion for whether the boundary layer is real)

Whether a boundary layer is truly generated **depends solely on the wedge (prism) count in the cell-type breakdown** — nothing else counts:

- **`wedge > 0` is the only real BL**, and it's a **hard gate** — wedge=0 means BL FAIL outright (and almost inevitably drags the y+ gate to FAIL too).
- **the `hex` count is hexcore core cells, not the prism layer**; you must **never** use the hex count as evidence of BL (the classic misreading of **F6**).
- this case's wrap mesh of 157,951 cells = 119,227 tet + 27,220 hex(hexcore) + 11,504 poly + **0 wedge** → the BL was never generated
  → y+ gate FAIL (median 147, only 23.7% in strategy B's 30–100 range). This is one of the root causes pinning the result at process-validation grade.
- **F6 root cause**: passing BL parameters via the compound parent task's `arguments.update_dict()` is **silently ignored** (the generated control is named `aspect-ratio_1`
  instead of the set `first_height_1`); the correct approach is to mimic Identify-Regions' **subtask pattern**, explicitly create the BL control, and read back
  `OffsetMethodType/FirstHeight/NumberOfLayers` (see [`04_failure_recovery.md`](04_failure_recovery.md) F6 for details).
- get the wedge count from the transcript: **never read the whole `.trn` file** (F3 once spammed 9.8 million lines), use `Select-String "wedge"` / `tail`.

---

## 8. The solver refuses to read a pure surface mesh (a prerequisite for producing images)

- the solver rejects a pure surface mesh outright: **`Surface meshes cannot be read under /file/read-case`**.
- consequence: **to render bare geometry / surface fields in the solver, you must have a volume mesh first** (generate the volume mesh first, then `read-case-data`).
- the headless pitfalls of imaging camera/clipping/viewpoint (F8: `display()` resets the camera, `camera/*` doesn't trigger a redraw) are in
  [`07_postprocessing_and_imaging.md`](07_postprocessing_and_imaging.md).

---

## 9. Mesh gate-check checklist (must pass before entering the solve)

| Check item | Pass | Reject |
|---|---|---|
| negative volume | = 0 | > 0 (stop, solving forbidden) |
| max skew | < 0.90 recommended (< 0.95 acceptable for a first run) | ≥ 0.95 |
| min orthogonal quality | > 0.15 recommended (> 0.10 acceptable) | ≤ 0.10 |
| boundary naming | inlet/outlet/wall_body/far-field complete (iron law 3) | missing any → solving forbidden |
| BL | **wedge > 0** (cell-type breakdown) | wedge = 0 → BL FAIL |
| surface fidelity | conforming and smooth | wrap faceting/spikes → coefficients process-validation grade only |
| far-field AoA | FARFIELD_VERIFY read-back of m/t/flow_direction passes | read-back mismatch → abort |

> Reminder: if you used wrap, or left sealed internal cavities, or used estimated reference area/length/moment center, then the resulting **Cd/Cl/Cm must all be labeled "process-validation grade" and never used as design conclusions**.
> Process cleanup must include mpiexec (`Get-Process fluent,mpiexec,cortex,python | Stop-Process -Force` → `Start-Sleep 10` → read back empty → then launch,
> never kill+launch in the same command — single license seat, **F9/F11**, see [`05_environment.md`](05_environment.md) for details).
