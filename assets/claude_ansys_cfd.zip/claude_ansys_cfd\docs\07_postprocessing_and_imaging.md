# 07 — Headless post-processing & imaging

> This chapter covers **how to do headless imaging and quantitative extraction on an already-archived case+data** (without re-solving): a reliable camera/save sequence, the field names that actually work, force/moment compute, per-facet y+ extraction, recomposing a small aircraft body inside a large domain, and deterministic centered cropping.
> Everything has been genuinely verified end-to-end on Ansys Fluent 2024 R1 + **PyFluent 0.17.1 (legacy API)**.
>
> How this splits with the other chapters:
> - The field-name list, the force/moment report definition keys with the F7 coefficient trap, and the y+ transaction — the detailed rationale lives in
>   [`02_pyfluent_playbook.md`](02_pyfluent_playbook.md) §6/§9/§10; this chapter only gives the **imaging-side** usage and traps, without repeating the derivation.
> - A ready-to-use full script: [`../scripts/conforming_postproc_imaging_reference.py`](../scripts/conforming_postproc_imaging_reference.py)
>   (only edit the `CONFIG` block at the top; do not touch the F5/F7/F8 fix logic). This chapter is its "why it's written this way".
> - Historical / legacy-route imaging scripts: [`../scripts/postproc_images_reference.py`](../scripts/postproc_images_reference.py),
>   audit extraction: [`../scripts/postproc_audit_reference.py`](../scripts/postproc_audit_reference.py).

---

## 0. Prerequisites (do these every time)

1. **Clear zombie processes (including mpiexec!) before launch.** Imaging is also a `launch_fluent` call and takes the same license seat.
   Even if the previous `session.exit()` exited normally, in practice about 2 fluent processes still linger holding the lock → if you don't clear them, the next run reports "Connection refused" (F11).
   ```powershell
   Get-Process fluent,mpiexec,cortex,python -ErrorAction SilentlyContinue | Stop-Process -Force
   Start-Sleep 10
   Get-Process fluent,mpiexec -ErrorAction SilentlyContinue   # must be empty before launching
   ```
   **Never kill + launch in the same command** (the seat/port doesn't get released in time).

2. **Fix the launch parameters** (consistent with solving, see [`05_environment.md`](05_environment.md)):
   ```python
   s = launch_fluent(product_version="24.1.0", mode=FluentMode.SOLVER, precision="double",
                     processor_count=4, show_gui=False, cleanup_on_exit=False,
                     cwd=WORKDIR, start_timeout=180, start_watchdog=False)
   ```
   `show_gui=False` **can still render** white-background PNGs (up to 2560×1440); `start_watchdog=False`, otherwise it pops up Notepad.

3. **Read case+data (no re-solve):**
   ```python
   s.tui.file.read_case_data(CASE)   # e.g. Javelin_V1_conforming_alpha3.cas.h5
   ```
   The solver **refuses to read a pure surface mesh** ("Surface meshes cannot be read under /file/read-case") → you must have a volume mesh before rendering bare geometry.

---

## 1. ⭐ F8 — the reliable imaging sequence (the camera-not-redrawing trap)

Headless imaging has two fatal traps, and the **only reliable sequence** that gets around them is exactly this section's title:

> **`display → restore_view → auto_scale → pan_camera → zoom_camera → save_picture`**

**Trap 1: `display()` resets the camera back to the default front view.** If you set up the camera first and then call `display()`, the camera gets wiped out.

**Trap 2: `/display/views/camera/{target,position,up-vector}` does not trigger a redraw after being set.** In headless mode,
`save_picture` grabs the **stale frame buffer** — in practice, setting camera/target/position had absolutely no effect, the image didn't change.

**Why the sequence above works:** `restore_view` / `auto_scale` / `pan_camera` / `zoom_camera` **each redraw immediately**,
so the camera they cumulatively build up actually gets written into the frame buffer, and only then does `save_picture` grab the correct picture. **Do not use `camera/*` set_state to position the camera.**

```python
tui = s.tui
gr  = s.results.graphics

# --- global imaging settings (once is enough) ---
tui.display.set.windows.axes.visible("no")      # turn off axes
tui.display.set.windows.logo("no")              # turn off logo
tui.display.set.picture.driver.png()
tui.display.set.picture.use_window_resolution("no")
tui.display.set.picture.x_resolution(2560)
tui.display.set.picture.y_resolution(1440)

# --- reliable save: delete the old file first, to avoid the overwrite prompt (the prompt hangs a headless session) ---
def save(fn):
    p = os.path.join(IMG, fn)
    if os.path.exists(p):
        os.remove(p)
    tui.display.save_picture(p)
    ok = os.path.exists(p)
    log(f"IMG_{fn}={'OK' if ok else 'MISS'} {os.path.getsize(p) if ok else 0}")
```

**Two variants:**

- **Body surface image** (only show the aircraft wall; the body auto-frames itself, no pan needed) — repeat `display+restore+auto_scale` once so it settles to the new camera:
  ```python
  def wall_shot(name, fn, view="isometric"):
      gr.contour[name].display()
      tui.display.views.restore_view(view)        # surface images use "isometric"/"left"/"top"
      tui.display.views.auto_scale()
      gr.contour[name].display()                  # do it again, settle
      tui.display.views.restore_view(view)
      tui.display.views.auto_scale()
      save(fn)
  ```

- **Cross-section field image** (small body in a large domain, you must pan+zoom to pull the body back to the picture center) — see §4:
  ```python
  def plane_shot(name, fn, kind="contour"):
      getattr(gr, kind)[name].display()
      tui.display.views.restore_view("top")       # "top" view looks at the XZ plane = side view
      tui.display.views.auto_scale()
      tui.display.views.camera.pan_camera(panx, panz)   # pan unit = viewport fraction, see §4
      tui.display.views.camera.zoom_camera(ZOOM)
      save(fn)
  ```

**Verification gate:** a nonzero `os.path.getsize()` is only a **necessary condition**; you must read the PNG out and **eye-/multimodally inspect whether the viewpoint and extent are correct**
(after auto_scale the body might just be a small dot; the pan sign might be wrong; the surface image might be facing away from the camera).

> **The trap of an empty named-graphics-object container:** when the container is empty, `get_state()` returns **None**, so you cannot use `name in get_state()` to test existence.
> Just do `try: gr.contour.create(name) except: gr.contour[name] = {}`, then `get_state()` to see the real keys, and **only assign to keys that exist**
> (`node_values` / `filled` / `contour_lines` / `boundary_values`), otherwise different builds will throw a key error.

---

## 2. ⭐ The field names that work (a typo and you get nothing; a hardcoded single name will fail)

The field name for a contour plot's `field` / `get_scalar_field_range`, **the ones actually verified to work** are only these (other names silently return empty or throw):

| Field | Working field name | Trap |
|---|---|---|
| Velocity magnitude | `velocity-magnitude` | — |
| Static pressure | `pressure` | — |
| Pressure coefficient | `pressure-coefficient` | depends on reference values; when reference values are estimated only look at the shape |
| Mach number | `mach-number` | — |
| Wall shear stress (skin friction) | `wall-shear` | **`wall-shear-stress` often throws `is_not_in`** → see below |
| y+ | `y-plus` | the rendered image is **node-averaged** (biased low); audit references must use the per-facet array from §5 |
| Coordinate (domain center) | `x-coordinate` / `z-coordinate` | used to get the box extent for §4 |

**Wall skin friction must use a candidate fallback**, do not hardcode `wall-shear-stress`:

```python
def first_field(gr_contour, name, candidates, surfaces):
    for fld in candidates:
        try:
            try: gr_contour.create(name)
            except Exception: gr_contour[name] = {}
            obj = gr_contour[name]; st = obj.get_state()
            p = {"field": fld, "surfaces_list": list(surfaces)}
            if isinstance(st, dict):
                for k in ("node_values", "filled", "boundary_values"):
                    if k in st: p[k] = True
                if "contour_lines" in st: p["contour_lines"] = False
            obj.set_state(p)
            return obj, fld
        except Exception:
            continue          # this name failed, try the next one
    return None, None

# skin friction: "wall-shear-stress" usually fails, "wall-shear" is the one that hits
o, _ = first_field(gr.contour, "f_tau", ["wall-shear-stress", "wall-shear", "x-wall-shear-stress"], aircraft)
```

---

## 3. ⭐ F10 — shadow-topology face selection (aircraft wall vs outer-domain box)

In a conforming/watertight mesh, internal/wall faces generate paired `<name>-shadow` twin zones; **the outer boundary of the outer-domain box has no shadow twin**.
Use this fact to robustly separate the "aircraft outer skin" (the object of imaging / force integration) from the "outer-domain box" (domain extent / far-field), **without hardcoding zone names**:

```python
sinfo = s.field_info.get_surfaces_info()
names = list(sinfo.keys())
nonshadow = [n for n in names if not n.endswith("-shadow")]
aircraft = [n for n in nonshadow if (n + "-shadow") in names]        # aircraft: has a shadow twin
box      = [n for n in nonshadow if (n + "-shadow") not in names][0]  # outer-domain box: no shadow twin (unique)
```

- For **surface contour plots** (Cp/static pressure/skin friction/y+), `surfaces_list` = `aircraft`.
- For **cross-section field plots**, `surfaces_list` = `["plane-y", *aircraft]` (cross-section + body outline).
- For the **domain center**, use the `box` surface_id to get the coordinate range (§4).
- Get `surface_id` / `zone_id` from `sinfo[name]` (the value may be a scalar, normalize it into a list).
- A face-count-based scheme like `(thread-n-faces ...)` returns None in 0.17.1, **unusable** → you can only rely on the `-shadow` naming.

---

## 4. ⭐ Recomposing a small body in a large domain (pan is a viewport fraction, not world coordinates)

In a 10 m outer domain the aircraft occupies only about 3% of the frame; after `auto_scale` the body is a small dot. The key to recomposing is **using the box coordinate range to compute the domain center,
then panning to pull the body back to the picture center**:

```python
fi = s.field_info
sid = sinfo[box].get("surface_id")
sid = sid if isinstance(sid, list) else [sid]

def rng(field):
    # first try with node_value=True then fall back; surface_ids must be a list
    for kw in (dict(node_value=True, surface_ids=sid), dict(surface_ids=sid)):
        try:
            r = fi.get_scalar_field_range(field, **kw)
            if r and len(r) == 2: return r
        except Exception:
            pass
    return None

xr = rng("x-coordinate"); zr = rng("z-coordinate")     # box x/z range
panx = CX - (xr[0] + xr[1]) / 2.0 if xr else PAN_DEFAULT[0]   # body center - domain center
panz = CZ - (zr[0] + zr[1]) / 2.0 if zr else PAN_DEFAULT[1]
# then in plane_shot: restore_view("top") → auto_scale() → pan_camera(panx, panz) → zoom_camera(7.0)
```

**Key trap: `pan_camera`'s unit is a viewport fraction, not world coordinates.** So `CX-domcx` (the world-coordinate difference)
is only an **empirical scaling quantity**, and the sign/magnitude may need trial-and-error (when the box range can't be obtained, fall back to the empirical value `PAN_DEFAULT=(-3.0, 0.0)`, and negate it if wrong).
Precisely because a single pan is imprecise in viewport fractions and the body will still drift off center, **deterministic centering relies on the composite-crop in §6**, not on getting the pan tuned to perfection.

---

## 5. ⭐ F5 — per-facet numerical extraction of y+ / scalar fields (for auditing, not imaging)

The rendered y+ contour is **node-averaged** (biased low); the y+ gate's ([`03_quality_gates.md`](03_quality_gates.md)) references must use **facet** data (including extremes).
0.17.1 **does not have** `session.fields`; calling `get_scalar_field_data` directly returns an empty dict. The correct route is a `field_data` transaction:

```python
fd = s.field_data            # not session.fields.field_data (doesn't exist)
yvals = []
for wname in aircraft:       # multiple walls: accumulate facets zone by zone
    sid_w = sinfo[wname].get("surface_id")
    sid_w = sid_w if isinstance(sid_w, list) else [sid_w]
    tx = fd.new_transaction()
    tx.add_scalar_fields_request(field_name="y-plus", surface_ids=sid_w,
                                 node_value=False, boundary_value=True)   # facet boundary values
    payload = tx.get_fields()    # nested dict, leaves are numpy arrays → extract recursively
    # recursively flatten all numpy leaves into yvals (see the reference script's walk())
```

- `node_value=False, boundary_value=True` gets the **per-facet boundary value**; `surface_ids` (not `surfaces`) must be a list.
- Once you have all the facets, the interval-fraction statistics feed the y+ gate directly: how much falls into each of `<11 / 11–30 / 30–100 / 100–300 / ≥300`.
- In the report **note the convention**: the rendered image = node-averaged (biased low), the audit number = facet (includes extremes, higher).

---

## 6. ⭐ System.Drawing centered cropping (deterministic centering, no re-render needed)

`pan_camera` is a viewport fraction (§4), and after a single pan the body still drifts (biased right in practice). Rather than repeatedly trial-and-erroring the pan parameters and re-rendering,
it's better to **render one large image and afterward use PowerShell + System.Drawing to stitch together "the color-bar strip + the centered aircraft block"** into the final image — deterministic, no re-render:

```powershell
Add-Type -AssemblyName System.Drawing
$src = [System.Drawing.Image]::FromFile("$IMG\pro_velocity_plane.png")  # 2560x1440 large image
$W = $src.Width; $H = $src.Height
$out = New-Object System.Drawing.Bitmap($W, $H)
$g = [System.Drawing.Graphics]::FromImage($out)
# keep the left color-bar strip (px 0..~360) as-is; translate the "centered aircraft" crop (e.g. px 1500..2560) over to the middle
$barW = 360
$g.DrawImage($src, (New-Object System.Drawing.Rectangle(0,0,$barW,$H)),
             0,0,$barW,$H, [System.Drawing.GraphicsUnit]::Pixel)            # color bar
$g.DrawImage($src, (New-Object System.Drawing.Rectangle($barW,0,($W-$barW),$H)),
             1500,0,($W-1500),$H, [System.Drawing.GraphicsUnit]::Pixel)     # centered aircraft crop
$out.Save("$IMG\pro_velocity_plane_centered.png", [System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose(); $out.Dispose(); $src.Dispose()
```

- **Why the seam is invisible:** the cross-section background is the **uniform free stream** (velocity/pressure is nearly constant in the far-field), the colors on either side of the seam match, and the seam disappears.
- The pixel column numbers (`360` / `1500`) are set by your resolution and where the body actually lands in the picture; eye-tune them once and then they're fixed.

---

## 7. ⭐ Force / moment / coefficients (report_definitions.compute)

> For the full keys and F7 rationale, see [`02_pyfluent_playbook.md`](02_pyfluent_playbook.md) §6; here is the minimal usage within a post-processing script.

```python
rd = s.solution.report_definitions

def setup_force(nm, kind, vec=None, axis=None):
    getattr(rd, kind).create(nm)
    st = {"zones": aircraft}                       # the aircraft wall selected in §3
    if vec  is not None: st["force_vector"] = vec
    if axis is not None:
        st["mom_center"] = MOM_CENTER
        st["mom_axis"]   = axis
        st["report_output_type"] = "Drag Force"    # ⚠ F7: if not set = outputs moment "coefficient" (/q·A·L), not N·m!
    getattr(rd, kind)[nm].set_state(st)
    back = getattr(rd, kind)[nm].get_state()        # read back the full state to check hidden default keys
    log(f"RD_{nm}_OUTTYPE={back.get('report_output_type')}")   # must be 'Drag Force'

setup_force("drag_f", "force",  vec=DRAG_DIR)
setup_force("lift_f", "force",  vec=LIFT_DIR)
setup_force("side_f", "force",  vec=SIDE_DIR)
setup_force("roll_m", "moment", axis=[1,0,0])
setup_force("pitch_m","moment", axis=[0,1,0])
setup_force("yaw_m",  "moment", axis=[0,0,1])

# compute is the same convention as report_files monitoring; returns list[dict], values may be a list, take [0]
comp = rd.compute(report_defs=["drag_f","lift_f","side_f","roll_m","pitch_m","yaw_m"])
vals = {}
for d in (comp or []):
    for k, v in d.items():
        vals[k] = v[0] if isinstance(v, list) else v
```

**F7 moment-unit trap (must read):** a moment definition's `report_output_type` **defaults to "Drag Coefficient"** (i.e. the moment **coefficient** ÷q·A·L),
and the enum only has `(Drag Coefficient | Drag Force)`. To get raw **N·m you must explicitly set "Drag Force"**, and **read back the full state after creating** to verify
(setting `"Moment"` is rejected). The conversion factor = q·A·L.

**Coefficient conversion (with units, label the convention):** q = ½ρU² (for this case = **4253.5 Pa**); force coefficient = F/(q·A), moment coefficient = M/(q·A·L).
**The reference area/length/moment center are estimates → Cd/Cl/Cm are all "process-validation level", never treat them as a design conclusion.**

**The final delivered conforming numbers for this project (process-validation level):**

| Quantity | Value | | Coefficient (process-validation) | Value |
|---|---:|---|---|---:|
| Drag | 16.736 N | | Cd | 0.0897 |
| Lift | 14.483 N | | Cl | 0.0776 |
| Side | -0.156 N | | L/D | 0.87 |
| Roll Mx | -0.034 N·m | | Pitch My | -0.408 N·m |
| Yaw Mz | -0.034 N·m | | q | 4253.5 Pa |

> Note: first-order upwind, for this compressible (Ma 0.245) case, **systematically overestimates drag by ~10–25%** (the second-order switch diverged, so it ran first-order throughout);
> 16.7 N is ~27% higher than the earlier wrap incompressible 13.14 N, mainly due to numerical/compressibility factors, not a real aerodynamic difference. **Shape is trustworthy, absolute value with caution.**

---

## 8. Typical imaging checklist (what this case produced)

| Category | File | Sequence | surfaces |
|---|---|---|---|
| Surface Cp/static pressure | `cfd_cp_{isometric,left,top}.png`, `cfd_pressure_*` | wall_shot | `aircraft` |
| Surface skin friction | `pro_wallshear_iso.png` | wall_shot | `aircraft` |
| Surface y+ | `pro_yplus_iso.png` (node-averaged; for auditing use the §5 facet) | wall_shot | `aircraft` |
| Cross-section velocity/wake | `pro_velocity_plane.png` | plane_shot+pan+zoom | `plane-y`+`aircraft` |
| Cross-section static pressure | `pro_pressure_plane.png` (nose stagnation ≈ q is a physics self-check) | plane_shot | `plane-y`+`aircraft` |
| Cross-section Mach | `pro_mach_plane.png` | plane_shot | `plane-y`+`aircraft` |
| Cross-section streamlines | `pro_streamlines_plane.png` (pathlines released from `plane-y`) | plane_shot | `plane-y` |

**Physics self-check (do it while you're at it):** in the cross-section static-pressure image the nose stagnation point should be ≈ q (for this case ≈ 4253 Pa, measured at about +4590 Pa, same order of magnitude). If it's off, first suspect the boundary/reference values.

---

## 9. ⛔ Things not to do

- **Never use interactive TUI reports** (`/report/forces/wall-forces yes <vector>` etc.): in 2024R1 the parameter order doesn't match →
  an "Empty filename" infinite loop, the transcript scrolls to 9.8 million lines, the session hangs (**F3**). Force/moment always go through `report_definitions.compute`
  + `report_files` ([`02_pyfluent_playbook.md`](02_pyfluent_playbook.md) §6/§7).
- **Don't use cross-section vector plots** (`gr.vector`): under the recomposing `zoom`, the arrows **auto-scale far too large to be usable**; the project's `pro_vectors_plane.png` has been deleted — **use streamlines (pathlines) instead**.
- **Don't use `camera/{target,position,up-vector}` set_state to position the camera**: it doesn't trigger a redraw headless, and `save_picture` grabs the stale frame (**F8**, §1).
- **Don't use `name in get_state()` to test whether a graphics object exists**: an empty container's `get_state()` returns None (§1).
- **Don't hardcode the single name `wall-shear-stress`**: it often throws `is_not_in`, use a candidate fallback (§2).
- **Don't directly take the rendered image's y+ as the audit value**: that's node-averaged and biased low; references must use the §5 facet array.

---

## 10. Wrap-up

- After `session.exit()`, **go back to §0 and clear zombies** (even on a normal exit about 2 fluent processes linger holding the lock).
- Read each PNG out and eye-inspect it; write the summary into `*_results_summary.md` (the reference script auto-mirrors it),
  **every number with units, every coefficient labeled "process-validation level"**.
- Legacy-route (wrap incompressible) imaging script: [`../scripts/postproc_images_reference.py`](../scripts/postproc_images_reference.py);
  audit extraction: [`../scripts/postproc_audit_reference.py`](../scripts/postproc_audit_reference.py).
  conforming solve + far-field: [`../scripts/conforming_farfield_solver_reference.py`](../scripts/conforming_farfield_solver_reference.py).
