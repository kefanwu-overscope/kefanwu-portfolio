# Failure Recovery — Known Failures F1–F11 + Second-Order Divergence + Fake Stall + General Recovery

> The first half (F1–F11) covers failures this project **actually hit and fixed** — read it through before you start work so you don't repeat them.
> Each entry gives: **symptom → root cause → exact fix (with literal API keys/command strings) → how to detect/avoid**.
> For API details see [`02_pyfluent_playbook.md`](02_pyfluent_playbook.md); for meshing see [`06_meshing_strategy.md`](06_meshing_strategy.md);
> for imaging see [`07_postprocessing_and_imaging.md`](07_postprocessing_and_imaging.md).

---

## 1. Known Failures F1–F11 (battle-tested)

### F1 — SpaceClaim headless STEP→FMD conversion crash (reproducible)
- **Symptom**: FTM (fault-tolerant) "Import CAD and Part Management" throws
  `RuntimeError('Unknown exception')`; the real cause in the .trn is a
  `System.AccessViolationException` while headless SpaceClaim converts the STEP. After the crash, 2 zombie fluent processes are always left behind (holding the license).
- **Root cause**: headless SpaceClaim STEP→FMD conversion is unstable on this machine.
- **Fix**: **do not let FTM import the .step**; switch to the **FMD** file from a previously successful run
  (overwrite `SOURCE`/`attempt.SOURCE` in the script to point at `*.fmd`, skipping the SpaceClaim conversion step).
- **Detect/avoid**: treat an FTM import step pointing at a .step as high-risk.
  Scope note: **F1 is limited to the fault-tolerant import path only**; **the watertight workflow can import STEP directly without this crash**
  (see F10). After a crash, clean up processes per the F11 discipline.

### F2 — PyFluent 0.17.1 inlet velocity-component key names (same family as the short-key/long-key trap)
- **Symptom**: writing `momentum.velocity_components = [vx, vy, vz]` by intuition either has no effect or throws a structure error.
- **Root cause**: in 0.17.1 the components are a **list of dicts**, each item of the form `{option, value}`, not a bare list of floats.
- **Fix**:
  ```python
  bc.momentum.velocity_specification_method = "Components"
  # real structure: 3 {option, value} dicts
  bc.momentum.velocity_components[0].value = vx
  bc.momentum.velocity_components[1].value = vy
  bc.momentum.velocity_components[2].value = vz
  ```
- **Detect/avoid**: **the general technique = first `get_state()` to see the real structure, then `set_state()`, finally read back to verify**.
  This is the talisman throughout 0.17.1 (it also saves F7's hidden default key and the far-field short keys). See playbook §4.

### F3 — Interactive TUI force report dead loop floods the transcript (**the most expensive one**)
- **Symptom**: `/report/forces/wall-forces yes <vector>` has a mismatched argument order in 2024R1 → an "Empty filename"
  prompt **dead loop** → transcript floods to **9.8 million lines**, the script hangs, and **case/data is lost (800 steps wasted)**.
- **Root cause**: the headless prompt does not match the question-by-question order of the interactive TUI report, so it enters an unanswered dead loop.
- **Fix**: **disable all interactive TUI reports** (`/report/forces/*`, `/report/.../wall-moments`, etc.).
  Route forces/moments through:
  ```python
  solver.solution.report_definitions.force[...]      # create force/moment report definition
  solver.solution.monitor.report_files[...]          # persist .out, frequency=1, written every step
  solver.solution.report_definitions.compute(report_defs=[...])  # read back, same convention
  ```
  **Save case/data immediately after iterate (written before any force report)** to rule out wasted runs.
- **Detect/avoid**: any `/report/forces` text in the script is a red line. An abnormal transcript size explosion (million-line scale)
  is this failure; view it with `Select-String`/tail, and **never read the whole .trn file in**. Playbook §7.

### F4 — Fluent's default convergence criterion 1e-3 stops early
- **Symptom**: `iterate(800)` prints `! 48 solution is converged` at step **48** and returns,
  with forces nowhere near steady (window fluctuation ~79%).
- **Root cause**: the default check-convergence was not disabled; residual 1e-3 is far from enough for external-flow forces (the forces are still drifting heavily).
- **Fix**: before solving, turn off convergence checking for **every equation**:
  ```python
  for eq in solver.solution.monitor.residual.equations:
      solver.solution.monitor.residual.equations[eq].check_convergence = False
  ```
  Then use a ~20-step **probe iteration to verify** the criterion is truly disabled: if `iterate(20)` returns in <5s (early converged),
  the disable did not take → **abort immediately**, fix it, and rerun.
- **Detect/avoid**: iterate returning steps << requested steps = you got caught. Hand the convergence criterion to the force/moment fluctuation gate,
  not to the residual (see [`03_quality_gates.md`](03_quality_gates.md)). Playbook §8.

### F5 — y+ (and any scalar field) extraction: `session.fields` does not exist
- **Symptom**: `session.fields.field_data` → `AttributeError`; calling `get_scalar_field_data(...)` directly returns **empty**.
- **Root cause**: in 0.17.1 field data goes through the transaction interface, not direct attribute access.
- **Fix**:
  ```python
  txn = session.field_data.new_transaction()
  txn.add_scalar_fields_request(
      field_name="y-plus", surface_ids=[...],
      node_value=False, boundary_value=True)   # facet values, for auditing
  data = txn.get_fields()                       # leaves are numpy arrays
  ```
  For the scalar range use `field_info.get_scalar_field_range(...)`.
- **Detect/avoid**: **the field name must come from the working set**: `velocity-magnitude`, `pressure`, `mach-number`,
  `wall-shear`, `y-plus`. **Wall shear stress is `"wall-shear"`, not `"wall-shear-stress"`**
  (the latter throws an `is_not_in` error). Playbook §9.

### F6 — FTM boundary-layer subtask has no effect (BL not generated)
- **Symptom**: passing BL parameters to the compound parent task via `arguments.update_dict()` is **ignored**
  (the generated control is named `aspect-ratio_1` instead of the set `first_height_1`; first height/number of layers are not adopted).
- **Root cause**: FTM's stubborn size-field/control mechanism swallows the BL parameters from the parent task's update_dict (same origin as F9/F10-cont.).
- **Consequence**: the cell-type breakdown shows **0 wedges** ("27220 hex" is **hexcore core cells** misread as BL prisms);
  y+ median 147, 16% of the wall ≥300, y+ gate Fail.
- **Fix direction**: mimic the **child-task pattern** of Identify Regions to explicitly create the BL subtask and **read back**
  `OffsetMethodType / FirstHeight / NumberOfLayers`.
- **Detect/avoid (hard gate-check)**: **use a wedge count > 0 as the hard gate for BL existence**.
  **hex count = hexcore core cells ≠ prism layers**; never use hex>0 as evidence of BL.
  No wedges means BL was not generated → remesh. Playbook meshing chapter / [`06_meshing_strategy.md`](06_meshing_strategy.md).

### F7 — moment report definition outputs the **coefficient** by default instead of N·m
- **Symptom**: a moment definition created via the settings API has `report_output_type` defaulting to `"Drag Coefficient"`
  (= moment **coefficient** ÷ q·A·L), not N·m; the enum only has `(Drag Coefficient | Drag Force)`.
- **Root cause**: a report definition has hidden default keys; if you don't set them explicitly at create time you get the defaults.
- **Fix**: to get raw N·m you must explicitly set `report_output_type = "Drag Force"` and then **read back to confirm**.
  Conversion factor = q·A·L (under this project's estimated references the measured ratio is exactly = 93.3126736).
- **Detect/avoid**: **after creating any report definition, read back the full state and check the hidden default keys** (same philosophy as F2).
  If a moment value is an order of magnitude too small and "dimensionless", Drag Force was not set. Playbook §6.
  `report_definitions.compute(report_defs=[...])` is available in 0.17.1, in the same convention as the report_files monitor;
  use it to cross-check the .out persisted value.

### F8 — headless imaging camera does not redraw
- **Symptom**: `show_gui=False` renders white-background PNGs fine, but `display()` **resets the camera back to the default front view**
  (front = camera at +Z, seeing the XY top-down planar shape); after setting `/display/views/camera/{target,position,up-vector,field}`
  it **does not trigger a redraw**, and save-picture grabs the old buffer. Also: when a named graphics-object container is empty, `get_state()` returns **None**
  (don't use `name in get_state()` to test existence; just try `create()`).
- **Root cause**: the camera/* commands do not redraw immediately in headless mode.
- **Fix (reliable sequence)**:
  ```
  display → restore-view <named> → auto-scale → pan-camera → zoom-camera → save-picture
  ```
  These commands **redraw immediately**. For a side view (looking at XZ) use `restore-view top`; when the body is not at the domain center you need to pan after auto-scale.
- **Detect/avoid**: after producing an image, **read the PNG and visually check the viewpoint**.
  **Large-domain cross-section framing (F8-cont.)**: in a 10 m far-field domain the aircraft occupies only ~3% of the frame, so it is tiny after auto_scale →
  read the box surface `get_scalar_field_range("x-coordinate"/"z-coordinate")` to get the domain extents,
  `pan_camera(CX-center_x, CZ-center_z)` + `zoom_camera(7.0)` to pull the aircraft back; the pan unit is **viewport fraction, not world coordinates**,
  and if needed use System.Drawing to compose a crop for deterministic centering (no re-render required). Playbook §10 / chapter 07.

### F9 — headless FTM wrap mesh **cannot be refined** (size field locked)
- **Symptom**: trying to refine the 5 mm wrap surface for imaging failed three times (surface resolution unchanged):
  1. `GLOBAL_MIN=2.0` but "Choose Mesh Control Options" `CreationMethod="Default"` auto-recomputes GlobalMin
     back to 10 mm, ignoring the passed value → mesh **byte-for-byte identical** to the coarse mesh (157,951 cells / 5.98 MB).
  2. After running Default, update_dict changes `GlobalMin=2.0` and re-Execute → the displayed value changed but the wrap still uses the old size field
     → **still 157,951 cells / 5.98 MB** (re-Execute did not rebuild the size field that drives the wrap).
  3. `UseSizeFieldForPrimeWrap="No"` + `FillWithSizeField="No"` to bypass the size field →
     the mesh changed but in the **opposite direction** (hexcore decreased instead), and the surface still was not refined.
- **Root cause**: the **fault-tolerant wrap**'s size field is **locked** at the first "Default" execution;
  every lever you can reliably operate (GlobalMin / UseSizeFieldForPrimeWrap / FillWithSizeField) cannot move the wrap surface resolution.
  This workflow's task list has **no** "Add Local Sizing", and local refinement goes through the same stuck size field (same origin as F6).
- **Fix/discipline**: **refining this wrap mesh via headless script is not feasible** (stopped at a 3-attempt limit). Reliable refinement paths:
  (a) interactive Fluent Meshing GUI with a face-size control and visual verification;
  (b) make a **watertight/conforming** mesh on the real CAD (see F10), rather than a wrap of a simplified subset.
- **Detect/avoid**: after changing a size parameter, **read back the cell count / file byte size**; if it is byte-for-byte identical to the coarse mesh = no effect, stop retrying, switch paths.

### F10 — the surface "looks coarse" because it is a **wrap not the CAD** → conforming mesh + solve the 10 regions directly
- **Symptom**: the Cp surface plot looks too rough, suspected bad CAD.
- **Root-cause diagnosis**: the meshed `*_aero_core_fused_validation.step` is a **single closed solid body**
  (`ADVANCED_BREP` + `BREP_WITH_VOIDS`); the geometry itself is not coarse. **The coarseness comes from the fault-tolerant workflow's wrap**
  (a 5 mm envelope skin that drops the CAD faces and forms a spike at the wingtip), not from the CAD.
- **Fix (geometry rendering) = conforming mesh**:
  ```python
  wf = meshing.watertight(dynamic_interface=True)   # watertight imports STEP directly, no F1 crash
  # Import Geometry: FileName / LengthUnit / FileFormat="CAD"
  # Generate the Surface Mesh:
  #   CFDSurfaceMeshControls.{MinSize, MaxSize,
  #     SizeFunctions="Curvature & Proximity", CurvatureNormalAngle}
  ```
  MinSize=1 mm → 4.5 MB conforming surface (vs 21,110 wrap faces), smooth rendering, **surface size controllable** (not subject to the F9-locked size field).
- **F10-cont. (region-extraction problem, headless cannot do it)**: a conforming **external fluid mesh** needs "box minus aircraft = a single clean fluid region".
  The dirty `*_fluid_domain_validation.step` through watertight yields **10 flow volumes** (topology error, 112 MB, **cannot extract regions normally**).
  `Create Regions` `NumberOfFlowVolumes=1` is ignored (reads back 10); `Update Regions` setting the body region to `dead` is ignored;
  `Update Boundaries` throws `RuntimeError('Unknown exception')` and corrupts the region topology.
  **Conclusion: watertight region controls all fail in 0.17.1 headless (same as F6/F9); a clean single fluid region must be built in the SpaceClaim GUI.**
- **F10-final (CFD success) = solve the 10-region mesh directly, using far-field to bypass region extraction**:
  - Without extracting regions, **solve the 112 MB 10-region mesh directly**: the external air region connects to a **far-field box**, the 9 sealed body internal cavities are stagnant and **harmless**;
    the aircraft outer surface bears the external pressure.
  - **box→far-field via TUI**: `/mesh/modify-zones/zone-type <zone_id> pressure-far-field`.
  - **far-field BC uses short keys** (see the invariants below; the long keys `mach_number/temperature` silently fail and stay at the default Ma~0.6);
    set-then-readback, abort if `abs(got_m - Mach) > 1e-4` (FARFIELD_VERIFY gate).
  - Distinguish aircraft walls vs the outer box using **shadow topology**: an aircraft internal wall is inside the fluid and has a `-shadow` twin zone; the outer-box boundary does not.
    ```python
    aircraft = [z for z in nonshadow if z + "-shadow" in names]
    box      = [z for z in nonshadow if z + "-shadow" not in names]   # the only one without a twin = outer box
    ```
    (The face-count scheme `(thread-n-faces ...)` returns None in 0.17.1 and is unusable.)
- **Result (200 iter, first-order, Ma 0.245, conforming)**: q=4253.5 Pa; Drag 16.736 / Lift 14.483 / Side -0.156 N;
  Roll -0.034 / Pitch -0.408 / Yaw -0.034 N·m; L/D 0.87; Cd 0.0897 / Cl 0.0776 (**process-validation only**,
  estimated reference area/length/moment center, **never to be used as a design conclusion**). Compared with the wrap incompressible result (13.14/14.05 N), drag is ~27% higher,
  driven mainly by first-order numerical dissipation + compressibility, not a real aerodynamic difference.

### F11 — killing only fluent,python leaves **mpiexec orphans** → a new run gets "Connection refused"
- **Symptom**: on restarting the conforming external-flow solve, the new run throws at `read_case`
  `RuntimeError('failed to connect to all addresses; ... Connection refused')` (gRPC cannot reach the Fluent server).
- **Root cause**: `Get-Process fluent,python | Stop-Process` **does not kill mpiexec**. Fluent parallel uses mpiexec to orchestrate, and the
  killed run leaves behind **~20 mpiexec processes + one orphan solver** (measured: history still climbing 176→177→180) —
  the orphan holds the **single license/port**, so the new Fluent connection is refused; and the orphan solver's python client is already dead, so it never persists to disk (pure waste).
- **Fix (must include mpiexec)**:
  ```powershell
  Get-Process fluent,mpiexec,cortex,python -ErrorAction SilentlyContinue | Stop-Process -Force
  Start-Sleep 10
  Get-Process fluent,mpiexec -ErrorAction SilentlyContinue   # must read back and verify empty, then launch
  ```
  **Never kill+launch in the same command** (single license seat; the release doesn't complete in time → the new run gets Connection refused again).
- **Detect/avoid**: after restart, **confirm the history was written by the new run, not the old orphan** (a restart resets the report file;
  if it was not reset = the old orphan is still alive). Misleading signal: the stall-detector sees history rows climbing (iter 72→112→154)
  and assumes the new run is running, when in fact the **orphan** is running. See §2 "Fake stall".

---

## 2. Two cross-cutting pitfalls (unnumbered but equally lethal)

### Second-order upwind **diverges** on this compressible case (Ma 0.245)
- **Symptom**: the conforming far-field solve **hangs the moment it switches to second-order at iter30** (compressible scheme-switch divergence).
- **Fix**: **first-order upwind throughout** is the only stable choice (18–20 s/iter; at 200 steps the force is already steady, drag 16.95→16.7 <2% → produce images at 200 steps).
- **Cost/detection**: first-order **systematically overestimates drag by ~10–25%** (numerical dissipation). The report must write this up as a **process-validation-level** limitation,
  not treat it as the real drag. If you need second-order accuracy → first fix the mesh/BL, switch over in steps using a more stable initial field, or go back to incompressible.

### report file lock → **fake "stall"** (don't kill a healthy run by mistake)
- **Symptom**: the stall-detector sees the report history file's line count not growing and declares a stall — but the run is actually healthy and running
  (process CPU on the Windows host/wrapper reads 0, which is even less of a basis for liveness).
- **Root cause**: when the report `.out` is locked by another handle the line count temporarily does not update, manufacturing a fake stall; process CPU=0 is a host-side reading artifact.
- **Fix/detection**: **real vs fake stall must be cross-checked against the `.out` PER_ITER / ITER milestones**, not only the history file,
  and not only process CPU. Judge liveness when both the **report-FILE row growth + the .out per-step milestones** agree, then decide whether to kill.
  For the inverse trap see F11: climbing history can also be an **orphan** climbing. See memory [[poll-long-tasks-for-stalls]].

---

## 3. Correct invariants to memorize (quick reference)

- **far-field BC short keys**: `m` (Mach), `t` (temperature K), `flow_direction` (**a list** of `{value}`).
  **The long keys `mach_number`/`temperature` are a silent no-op**, leaving the default Ma~0.6 → all results wrong.
  **Always set-then-readback, abort if `abs(got_m - target_Mach) > 1e-4`** (FARFIELD_VERIFY gate).
- **box→far-field**: `/mesh/modify-zones/zone-type <zone_id> pressure-far-field` (TUI).
- **wall shear stress field name = `"wall-shear"`**, not `"wall-shear-stress"` (the latter is an `is_not_in` error).
  Usable fields: `velocity-magnitude`, `pressure`, `mach-number`, `wall-shear`, `y-plus`.
- **y+ extraction**: `session.field_data.new_transaction()` + `add_scalar_fields_request(... node_value=False, boundary_value=True)`
  → `get_fields()`; `get_scalar_field_data` returns empty, `session.fields` does not exist.
- **moment report**: the default `report_output_type` is a **coefficient**; for N·m set `"Drag Force"`, then read back the full state after create.
- **disable convergence check**: per equation `solution.monitor.residual.equations[eq].check_convergence = False`, verify with a short iteration probe.
- **disable interactive TUI reports** (F3): route forces/moments through `report_files` + `report_definitions.compute`.
- **process cleanup includes mpiexec** (F11): `Get-Process fluent,mpiexec,cortex,python | Stop-Process -Force` →
  `Start-Sleep 10` → read back empty → then launch; **never kill+launch in the same statement**.
- **launch_fluent**: `product_version="24.1.0"`, SOLVER mode, `precision="double"`, `processor_count=4`,
  `show_gui=False`, `start_watchdog=False` (the watchdog pops up Notepad), `cwd=WORKDIR`.
- **stall liveness judgment**: look at report-FILE row growth + `.out` per-step milestones, **not process CPU**; climbing history can also be an orphan.
- **second-order diverges at Ma 0.245 → first-order throughout** (first-order overestimates drag by ~10–25%).
- **coefficients obtained from estimated reference quantities = process-validation level, never design-grade; all quantities carry units.**

---

## 4. General recovery order

### Geometry import failure
- FTM import throws `Unknown exception` / AccessViolation → **F1**: switch to the FMD cache, or use **watertight** to import STEP directly.
- Still failing: re-export STEP AP214/AP242 → try Parasolid `.x_t` → unsuppress/unhide/remove bad parts →
  avoid Chinese/special characters in the path → simplify small features.

### Air-domain boolean subtraction failure / cannot extract a single fluid region
- **F10-cont.**: headless watertight region controls (NumberOfFlowVolumes / region=dead) all fail in 0.17.1.
  The dirty fluid_domain cannot extract "box minus aircraft = single region" → two ways out:
  (a) build the enclosure-minus-aircraft in the SpaceClaim GUI to get a clean single region;
  (b) **solve the multi-region mesh directly + one pressure-far-field outer boundary** (sealed cavities are harmless, see F10-final).
- General checks: is the solid closed? non-manifold edges? small gaps? can it be merged/simplified? make the bounding box larger? Still failing, go back to CAD cleanup.

### Mesh generation failure (in order)
Fix small faces/extra edges → enlarge surface size 1.3~1.5× → inflation 12→8 layers → first-layer height ×2 → suppress small features →
local refinement only where needed → do the propeller body-only first. If negative volume / severe defects remain, stop and report.
**After changing size, read back the cell count/bytes to verify it took effect (F9: byte-for-byte identical = no effect, don't retry).**

### Poor mesh quality / missing BL
- **Verify BL with wedge count >0 (F6)**; hex is the hexcore core, not prisms. No wedges → remesh.
- Remove sliver faces → increase the minimum size → reduce excessive curvature/proximity refinement → improve local transitions → if a boundary is too close, enlarge the air domain.

### Fluent mesh check failure
**Do not continue.** negative volume / invalid cells / highly distorted cells → go back to mesh repair.

### Solver divergence (recovery order)
scale/units → inlet component direction (F2 list key) → are the inlet/outlet/far-field directions reversed → density/viscosity units →
bad cells/high skewness → **for a compressible case use first-order throughout first; second-order switching diverges (proven on this project at Ma 0.245)** →
lower the relaxation factors → re-Hybrid Init → for rotor cases check the rotation axis/rotation-speed units/interface. If it still diverges, stop, do not produce results.

### Solver "converges early" (steps << requested)
**F4**: the default check-convergence was not disabled. Per equation `check_convergence=False` + verify with a short iteration probe.

### Solver suspected stall
**Don't kill first**: cross-check report-FILE row growth + `.out` per-step milestones (not process CPU).
Climbing history may be an mpiexec orphan (F11); non-climbing history may be a file-lock fake stall. Confirm both before acting.

### Solver restart "Connection refused"
**F11**: the old run's mpiexec orphans hold the license. Kill all, including mpiexec → Sleep 10 → read back empty → then launch; do not kill+launch in the same statement.

### Severe outlet backflow
Downstream 15L→20L → side/top/bottom 5L→7L → add wake refinement → avoid the outlet cutting through too strong a wake/slipstream → remesh and rerun.

### Force/moment anomalies
Check: force-vector direction → coordinate system → reference area → reference length → moment center → whether the far-field wall is counted into the force-action surface →
unit scale → lift sign convention → **whether the moment is mistakenly output as a coefficient (F7: set Drag Force)**.

### Headless imaging viewpoint/camera wrong
**F8**: `display → restore-view → auto-scale → pan-camera → zoom-camera → save-picture`;
direct camera/* setting has no effect; after producing the image read the PNG and visually check; for large-domain framing use the field-range to find the center, then pan+zoom to recompose.

### Steady-state result oscillation
May be separation/vortex-dominated unsteadiness, propeller wake, stall, or a large crosswind → recommend transient + a smaller time step + monitoring the force period,
and a higher-fidelity turbulence model if necessary.

### Process cleanup (the first action after any failure)
```powershell
Get-Process fluent,mpiexec,cortex,python -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep 10
Get-Process fluent,mpiexec -ErrorAction SilentlyContinue   # verify empty before continuing
```
**Must include mpiexec (F11)**; do not kill+launch in the same command.
