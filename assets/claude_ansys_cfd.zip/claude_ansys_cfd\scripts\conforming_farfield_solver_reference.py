# =============================================================================
# conforming_farfield_solver_reference.py
# VERIFIED-WORKING (genericized from a real 200-iter run)
# Conforming external-aero + single pressure-far-field solver reference script (PyFluent 0.17.1 legacy API, headless)
# Conforming external-aero solver with ONE pressure-far-field box. Reference copy.
# -----------------------------------------------------------------------------
# SOURCE: faithfully genericized from the real working solver
#   C:\Users\oc\Desktop\Codex_Ansys\pyfluent_conforming_solve_full.py
# That real script completed one 200-iter run (first-order upwind, Ma 0.245, ideal-gas, SST) for the Javelin_V1
# conforming external-aero solve, producing drag 16.7 N / lift 14.5 N / pitch -0.41 N·m together with a smooth Cp field.
#
# =============================================================================
# WHAT IT DEMONSTRATES
# =============================================================================
# 1. Directly solve a [multi-region conforming/watertight external-aero mesh] using just [one]
#    pressure-far-field box boundary — no longer slicing the box into
#    velocity-inlet / pressure-outlet / symmetry faces like the wrap route does. The conforming mesh preserves the CAD;
#    headless we cannot extract a single fluid region from a dirty fluid_domain, so the 9 internal body cavities serve as harmless
#    dead/sealed-region stagnant air, while the aircraft outer skin (singled out via shadow topology) carries the external pressure load and is solved directly.
# 2. Encode the angle of attack (AoA) with Mach + flow_direction unit vector, with a read-back verification gate
#    (FARFIELD_VERIFY): after set_state we must read back m/t/flow_direction and compare; abort if they disagree.
# 3. Compressible physics: ideal-gas + Energy equation + k-omega SST.
#    (Compressible is mandatory when U>100 m/s or Ma>0.3; this flow case at Ma 0.245 still uses compressible to keep the far-field consistent.)
# 4. [First-order upwind] throughout (first-order only): in a compressible flow case switching to second-order at iter~30 diverges/hangs,
#    so we don't switch; this is kept as a demonstration-grade Cp shape (absolute drag is only process-validation grade).
# 5. Chunked iterate + save case/data immediately after each chunk, so a renderable result exists even mid-run.
# 6. shadow topology discrimination: interior/wall faces carry a '<name>-shadow' twin; use this to separate box vs aircraft.
#
# =============================================================================
# KEY GOTCHAS IT ENCODES (see docs/02_pyfluent_playbook.md / 04_failure_recovery.md)
# =============================================================================
# - The pressure-far-field keys are the [short names] m / t / flow_direction, [NOT] mach_number /
#   temperature. Using the long names [raises no error], silently no-ops, the boundary stays at Fluent's default Mach≈0.6 / T 300,
#   and so it computes wrong results at the wrong speed (transonic). => FARFIELD_VERIFY read-back gate: if m disagrees (>1e-4),
#   raise and abort. (Same class of silent-default trap: F2 velocity_components list, F7 report_output_type.)
# - Second-order upwind diverges at the switch point (second-order diverges): in a compressible flow case a hard switch hangs immediately,
#   so stay first-order throughout. First-order has a ~10-25% systematic overestimate of drag, which must be noted in the report.
# - The moment report definition outputs a [coefficient] by default (report_output_type defaults to 'Drag Coefficient'
#   = ÷q·A·L); to get raw N·m you must explicitly set report_output_type='Drag Force' (F7).
# - The default residual convergence criterion 1e-3 stops the run early (in this class of flow case it reports "converged" at ~48 steps, with forces far from settled, F4):
#   before solving, set check_convergence=False on every equation of solution.monitor.residual.
# - Monitor the force/moment history by persisting it via report_files; [no] interactive TUI reports (they fall into an 'Empty filename'
#   infinite loop that floods the transcript with 9.8 million lines, F3); write case/data immediately after every ITERATE (F3).
# - Before launch you must kill the entire process family (including mpiexec!), otherwise leftovers hold the single license -> 'Connection refused' (F9/F11):
#     Get-Process fluent,mpiexec,cortex,python -ErrorAction SilentlyContinue | Stop-Process -Force
#     Start-Sleep 10 ; read back that Get-Process fluent,mpiexec is empty ; do not kill+launch in the same command.
# - If the reference area/length/moment center are [estimated values], the coefficients computed from them are only 'process-validation' grade, not design values.
#
# =============================================================================
# HOW TO ADAPT —— only edit the CONFIG block below
# =============================================================================
# Edit only the '===== CONFIG (edit per case) =====' section: paths / case name / flow conditions /
# reference area/length/moment center / iteration chunk sizes. The logic below CONFIG encodes the F2/F3/F4/F7/F9/F11 fixes
# and the various read-back gates — don't break them. The set values are for the Javelin_V1 flow case (estimated reference quantities); for a different flow case change only CONFIG.
# The flow-direction unit vectors DRAG_DIR/LIFT_DIR/SIDE_DIR are derived automatically from ALPHA — just change ALPHA.
#
# run (Ansys-bundled CPython, see docs/05_environment.md):
#   1) First clear the process family (the PowerShell line above) -> Start-Sleep 10 -> read back to confirm it is empty
#   2) "D:\ansys2024\ANSYS Inc\v241\commonfiles\CPython\3_10\winx64\Release\python\python.exe" `
#        conforming_farfield_solver_reference.py
#   3) Poll *.out (PER_ITER/ETA/CHUNK milestones), do not block-wait (background + poll)
# =============================================================================

import json, math, os, sys, time, traceback

# --- PyFluent 0.17.1 legacy API requires an explicit sys.path.insert (env-pyfluent-syspath) ---
sys.path.insert(0, r"D:\ansys2024\ANSYS Inc\v241\optiSLang\lib\python3.10\Lib\site-packages")
from ansys.fluent.core import launch_fluent
from ansys.fluent.core.launcher.launcher import FluentMode

# =============================================================================
# ===== CONFIG (edit per case) ================================================
# For a different flow case change only this block. The values below are all for the Javelin_V1 VTOL cruise flow case (reference quantities are estimated values).
# =============================================================================
WORKDIR     = r"C:\Users\oc\Desktop\Codex_Ansys"                            # working directory (CWD; module imports depend on this, env-cwd-requirement)
MESH        = os.path.join(WORKDIR, "Javelin_V1_conforming_external.msh.h5")# input conforming volume mesh (multi-region .msh.h5)
CASE        = os.path.join(WORKDIR, "Javelin_V1_conforming_alpha3.cas.h5")  # output case (same-named .dat.h5 is paired automatically)
REPORT_FILE = os.path.join(WORKDIR, "conforming_fh3.out")                   # force/moment history persisted to disk (report_files)
OUT         = os.path.join(WORKDIR, "conforming_farfield_solver_reference.out")   # live progress log (.out, poll this)
JSON_OUT    = os.path.join(WORKDIR, "conforming_farfield_solver_reference.json")  # final summary (.json)

# --- flow conditions ---
ALPHA   = 3.0              # angle of attack alpha [deg] (beta=0; the SIDE force is only meaningful when sideslip is non-zero)
U       = 300.0 / 3.6      # freestream velocity [m/s] = 300 kph = 83.3333 m/s
MACH    = 0.245            # Mach number (Ma>0.3 -> compressible mandatory; 0.245 still uses compressible to keep the far-field consistent)
T_INF   = 288.16           # freestream static temperature [K]
RHO     = 1.225            # air density [kg/m^3] (used only for q in reference_values; ideal-gas computes the actual density)
MU      = 1.7894e-5        # dynamic viscosity [kg/(m·s)] (constant viscosity)
P_OP    = 101325.0         # operating pressure [Pa] (operating-pressure; gauge_pressure is referenced to this)

# --- reference values —— [estimated values! coefficients computed from them are only 'process-validation' grade] ---
REF_AREA   = 0.043876               # reference area [m^2]  [estimated: bbox projection, not the true wing area]
REF_LEN    = 0.5                    # reference length [m]    [estimated: fuselage length L]
MOM_CENTER = [-1.011984, 0.6, 1.12] # moment center [m]    [estimated: bbox center, not the true CG]

# --- iteration chunking (chunked iterate; the probe measures speed and records ETA, then chunks resume and archive) ---
ITER_PROBE = 30           # probe chunk: measure per-iter wall-clock time + estimate ETA
ITER_C1    = 170          # first chunk -> ~iter 200, then immediately save case/data
ITER_C2    = 150          # second chunk -> ~iter 350, then immediately save case/data
ETA_TARGET = 350          # target total step count for the ETA estimate

# --- direction unit vectors derived from ALPHA (flow_direction uses DRAG_DIR; the force vectors share the same convention) ---
# Flow direction +X, vertical +Z; alpha tilts the freestream toward +Z.
DRAG_DIR = [math.cos(math.radians(ALPHA)), 0.0, math.sin(math.radians(ALPHA))]   # drag direction = freestream direction (far-field flow_direction)
LIFT_DIR = [-math.sin(math.radians(ALPHA)), 0.0, math.cos(math.radians(ALPHA))]  # lift direction (perpendicular to the freestream, tilted toward +Z)
SIDE_DIR = [0.0, 1.0, 0.0]                                                       # side-force direction +Y
# =============================================================================
# ===== END CONFIG ============================================================
# =============================================================================


# --- helpers (consistent with the source script) -------------------------------------------------
def log(m):
    """Write live to .out (poll this file to judge liveness: watch line/milestone growth, not process CPU)."""
    with open(OUT, "a", encoding="utf-8") as f:
        f.write(str(m) + "\n")

def safe(label, fn, req=False):
    """anti-fabrication gate: for a critical step set req=True, on failure raise and abort (do not pretend it ran).
    For a non-critical step, log ERR then continue. Returns {'ok': bool} for branching (e.g. SST settings->TUI fallback)."""
    try:
        r = fn(); log(f"{label}=OK {repr(r)[:200]}"); return {"ok": True}
    except Exception as e:
        log(f"{label}=ERR {repr(e)[:400]}")
        if req: raise
        return {"ok": False}

def ti(s, cmd):
    """Run an arbitrary TUI command via scheme_eval (used when the settings API has no binding, e.g. zone-type / discretization).
    Convert backslashes to forward slashes, escape double quotes (code:tui-scheme-eval-helper)."""
    esc = cmd.replace("\\", "/").replace('"', '\\"')
    return s.scheme_eval.scheme_eval(f'(ti-menu-load-string "{esc}")')


def main():
    for p in [OUT, JSON_OUT]:
        if os.path.exists(p): os.remove(p)
    os.environ["AWP_ROOT241"] = r"D:\ansys2024\ANSYS Inc\v241"
    data = {}
    s = None
    try:
        # --- Launch Fluent (env-launch-flags; 02 §1) ---
        # Note: before launch you must already have killed the entire process family (including mpiexec!) in PowerShell + Start-Sleep 10 + read back to confirm empty.
        # Do not kill+launch inside the script (single license, port/seat release takes time, F9/F11).
        s = launch_fluent(product_version="24.1.0", mode=FluentMode.SOLVER, precision="double",
                          processor_count=4, show_gui=False, cleanup_on_exit=False,
                          cwd=WORKDIR, start_timeout=180, start_watchdog=False)  # start_watchdog=False: otherwise it pops up Notepad

        # --- Read the multi-region conforming mesh (critical step) (02 §2) ---
        safe("READ", lambda: s.tui.file.read_case(MESH), True)

        # --- shadow topology discrimination of box vs aircraft (code:shadow-topology-discrimination) ---
        # Interior/wall faces have a '<name>-shadow' twin: has a twin = aircraft skin, no twin = outer box.
        sinfo = s.field_info.get_surfaces_info()
        names = list(sinfo.keys())
        nonshadow = [n for n in names if not n.endswith("-shadow")]
        box = [n for n in nonshadow if (n + "-shadow") not in names]       # outer box: no shadow twin
        aircraft = [n for n in nonshadow if (n + "-shadow") in names]      # aircraft: has a shadow twin
        log(f"BOX={box}  AIRCRAFT_N={len(aircraft)}")
        boxzone = box[0]; boxid = sinfo[boxzone].get("zone_id")
        data["aircraft"] = aircraft

        # --- Compressible physics: Energy on + air ideal-gas + constant viscosity + SST (code:material-idealgas-sst) ---
        safe("ENERGY_ON", lambda: s.setup.models.energy.set_state({"enabled": True}), True)
        air = s.setup.materials.fluid["air"]; ast = air.get_state()
        ast["density"] = {"option": "ideal-gas"}                           # ideal gas (compressible)
        if isinstance(ast.get("viscosity"), dict):
            ast["viscosity"]["option"] = "constant"; ast["viscosity"]["value"] = MU
        safe("AIR_IDEALGAS", lambda: air.set_state(ast), True)
        viscous = s.setup.models.viscous
        # SST: first try the settings API, on failure fall back to TUI kw_sst (a dual-path safeguard beyond get_state-before-set_state)
        if not safe("SST", lambda: viscous.set_state({"model": "k-omega", "k_omega_model": "sst"}))["ok"]:
            safe("SST_TUI", lambda: s.tui.define.models.viscous.kw_sst("yes"))

        # --- outer box zone-type -> pressure-far-field (by zone id, via TUI) (code:zonetype-far-field) ---
        # Must convert before accessing pressure_far_field[boxzone], otherwise that BC object does not exist.
        # (On read-in the native far-field type floods an 'ideal gas law' warning; once the zone-type is converted it disappears, harmless, F10.)
        safe("ZONETYPE", lambda: ti(s, f"/mesh/modify-zones/zone-type {boxid} pressure-far-field"), True)

        # --- Set pressure-far-field: m / t / gauge_pressure / flow_direction (list) / turb (code:farfield-set) ---
        # The keys are the short names m/t/flow_direction; the long names mach_number/temperature silently no-op (stay at the default Mach 0.6)!
        bc = s.setup.boundary_conditions
        pf = bc.pressure_far_field[boxzone]
        st = pf.get_state()                                                # read back the real structure before editing (02 §0)
        st["m"]["value"] = MACH                                            # Mach number (NOT mach_number)
        st["t"]["value"] = T_INF                                           # temperature (NOT temperature)
        st["gauge_pressure"]["value"] = 0.0
        for i, v in enumerate(DRAG_DIR):                                   # flow_direction: list-of-dict, component by component
            st["flow_direction"][i]["value"] = v
        st["turbulent_intensity"] = 0.05                                   # TI 5%
        st["turbulent_viscosity_ratio_real"] = 10                         # TVR 10
        safe("SET_FARFIELD", lambda: pf.set_state(st), True)

        # --- FARFIELD_VERIFY read-back gate (code:farfield-verify-gate; pressure-far-field-aoa-silent-failure) ---
        # set_state may be silently ignored -> before spending compute, read back and assert that m/t/flow_direction actually took effect; on mismatch raise.
        chk = pf.get_state()
        gotm = chk["m"]["value"]; gott = chk["t"]["value"]; gotd = [c["value"] for c in chk["flow_direction"]]
        log(f"FARFIELD_VERIFY m={gotm} t={gott} dir={gotd}")
        if abs(gotm - MACH) > 1e-4 or abs(gott - T_INF) > 0.1 or abs(gotd[0] - DRAG_DIR[0]) > 1e-3:
            raise RuntimeError(f"far-field read-back mismatch: m={gotm} t={gott} dir={gotd} — abort")

        # --- Operating pressure + reference values (reference_values includes temperature, required for compressible) ---
        safe("OP_PRESSURE", lambda: ti(s, f"/define/operating-conditions/operating-pressure {P_OP}"))
        safe("REFERENCE", lambda: s.setup.reference_values.set_state(
            {"area": REF_AREA, "length": REF_LEN, "density": RHO, "velocity": U, "temperature": T_INF}))

        # --- Force + moment report definitions (code:report-def-force-moment; F7) ---
        # Force: force_vector. Moment: must explicitly set report_output_type='Drag Force' to get raw N·m
        # (the default 'Drag Coefficient' = moment coefficient ÷q·A·L). zones use the aircraft skin list `aircraft`.
        rd = s.solution.report_definitions
        for nm, vec in [("drag_force", DRAG_DIR), ("lift_force", LIFT_DIR), ("side_force", SIDE_DIR)]:
            safe(f"RD_{nm}", lambda n=nm: rd.force.create(n))
            safe(f"RD_{nm}_set", lambda n=nm, v=vec: rd.force[n].set_state({"zones": aircraft, "force_vector": v}))
        safe("RD_pitch", lambda: rd.moment.create("pitch_moment"))
        safe("RD_pitch_set", lambda: rd.moment["pitch_moment"].set_state(
            {"zones": aircraft, "mom_center": MOM_CENTER, "mom_axis": [0, 1, 0],
             "report_output_type": "Drag Force"}))                         # raw N·m, not a coefficient

        # --- report_files force/moment history persisted to disk for monitoring (code:report-files-monitor; F3) ---
        # [No] interactive TUI force reports (they fall into an 'Empty filename' infinite loop flooding the transcript with 9.8 million lines).
        try:
            if os.path.exists(REPORT_FILE): os.remove(REPORT_FILE)
        except Exception as e:
            log(f"REPORT_FILE_RM_SKIP {repr(e)[:120]}")
        try:
            rf = s.solution.monitor.report_files; rf.create("fh")
            rf["fh"].set_state({"report_defs": ["drag_force", "lift_force", "side_force", "pitch_moment"],
                                "file_name": REPORT_FILE, "frequency": 1})
            log("REPORT_FILE=OK")
        except Exception as e:
            log(f"REPORT_FILE=ERR {repr(e)[:200]}")

        # --- Disable the per-equation residual convergence criterion (code:disable-residual-convergence; F4) ---
        # The default 1e-3 stops the run early (reports "converged" while forces are far from settled). 'equations' is a dict-of-dict, iterate over .values().
        try:
            res = s.solution.monitor.residual; rst = res.get_state()
            for eq in rst.get("equations", {}).values():
                if isinstance(eq, dict) and "check_convergence" in eq: eq["check_convergence"] = False
            res.set_state(rst); log("CONV_DISABLE=OK")
        except Exception as e:
            log(f"CONV_DISABLE=ERR {repr(e)[:200]}")

        # --- Start with first-order upwind (code:chunked-iterate-save; second-order-diverges-stay-first-order) ---
        # mom 0 = first-order upwind for momentum. In a compressible flow case switching to second-order at iter~30 diverges/hangs, so stay first-order throughout.
        # First-order has a ~10-25% systematic overestimate of drag, the absolute value is only process-validation grade, the report must note this.
        safe("FIRST_ORDER", lambda: ti(s, "/solve/set/discretization-scheme/mom 0"))
        safe("HYB_INIT", s.tui.solve.initialize.hyb_initialization, True)   # hybrid initialization (critical step)

        # --- Probe chunk: measure speed + estimate ETA (PER_ITER/ETA milestones for polling liveness) ---
        t0 = time.time()
        safe("ITER_PROBE", lambda: s.tui.solve.iterate(ITER_PROBE), True)
        dt = time.time() - t0
        per = dt / ITER_PROBE
        log(f"PER_ITER_S={per:.2f} ETA_REMAIN_MIN={per*(ETA_TARGET-ITER_PROBE)/60.0:.0f}")
        data["per_iter_s"] = per

        # --- Chunked iterate + write case/data immediately after each chunk (F3: persist right after ITERATE, so a renderable result exists mid-run) ---
        def write_now(tag):
            for p in (CASE, CASE.replace(".cas.h5", ".dat.h5")):
                try:
                    if os.path.exists(p): os.remove(p)                      # delete the old archive first, to avoid an overwrite-confirm prompt hanging
                except Exception: pass
            safe(f"WRITE_{tag}", lambda: s.tui.file.write_case_data(CASE), True)
            safe(f"MASS_FLOW_{tag}", lambda: s.tui.report.fluxes.mass_flow())  # mass imbalance emitted to the transcript

        safe("ITER_C1", lambda: s.tui.solve.iterate(ITER_C1), True)        # ~iter 200
        write_now("C1"); log("CHUNK1_DONE iter~200")
        safe("ITER_C2", lambda: s.tui.solve.iterate(ITER_C2), True)        # ~iter 350
        write_now("C2")
        log("SOLVE_FULL_DONE iter~350")

    except Exception as e:
        data["fatal"] = repr(e); log(f"FATAL={repr(e)}"); log(traceback.format_exc())
        # After a failure: in PowerShell kill the entire process family (including mpiexec!) + Start-Sleep 10 + read back to confirm empty, then restart (F9/F11).
    finally:
        with open(JSON_OUT, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False, default=repr)
        if s is not None:
            try: s.exit()                                                  # even a normal exit still leaves ~2 fluent processes; before the next launch you must still do a full-family cleanup
            except Exception: pass


if __name__ == "__main__":
    main()
