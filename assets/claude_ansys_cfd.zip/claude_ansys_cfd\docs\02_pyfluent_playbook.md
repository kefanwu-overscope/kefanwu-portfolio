# PyFluent 0.17.1 Field Manual (API recipes verified against real runs)

> ⭐ This is the core of this package. Every entry below was actually run and read-back-verified on Ansys Fluent 2024 R1 + **PyFluent 0.17.1 (legacy API)**. The version matters: 0.17.1's key names / object paths are **inconsistent** with the newer PyFluent docs, so writing per the new API on the official site will fail. **For any unknown key name, first `get_state()` to see the real structure, then `set_state()`.**

> This project got **two external-flow routes** working: ① the early **wrap incompressible** route (multiple inlet/outlet/symmetry faces decompose the angle of attack, iter 848); ② the final **conforming compressible** route (a single pressure-far-field boundary carries the angle of attack, ideal-gas + Energy, iter 200). The scripts for the two routes (`pyfluent_conforming_solve_full.py` etc.) are the source of the new recipes in this manual.

---

## 0. The universal technique: get_state first, then set_state (the single most important rule)

0.17.1's settings object structure frequently disagrees with the docs. Never guess key names. The standard move:

```python
state = obj.get_state()          # see the real structure
print(list(state.keys()))        # or json.dumps(state, default=repr)
# only edit once you've found the real path to the target key
state["some"]["nested"]["key"] = value
obj.set_state(state)
verify = obj.get_state()         # read-back check, confirm it actually got written
```

Every recipe in this manual was figured out this way. The known results are given below so you can skip re-discovering them.

> **This is the overarching rule that runs through the whole document.** In 0.17.1, many `set_state` calls **silently fail** (no exception thrown, but nothing is written), and short key names / hidden default keys are the norm: F2 inlet components (a list), F7 moment defaulting to coefficient, this section's §3a far-field short keys `m/t`, F4 convergence criterion. **After every set_state you must read back the key value and assert it**, otherwise you may carry the wrong input all the way through the computation.

---

## 1. Launching Fluent (solver mode)

```python
import sys, os
sys.path.insert(0, r"[PyFluent site-packages path, see env doc]")
from ansys.fluent.core import launch_fluent
from ansys.fluent.core.launcher.launcher import FluentMode
os.environ["AWP_ROOT241"] = r"D:\ansys2024\ANSYS Inc\v241"   # set before launching

session = launch_fluent(
    product_version="24.1.0",
    mode=FluentMode.SOLVER,
    precision="double",
    processor_count=4,            # parallel core count per the license
    show_gui=False,               # headless; imaging still renders (see §9)
    cleanup_on_exit=False,        # let case/data survive after exit
    cwd=WORKDIR,                  # must cd to the working dir, module import depends on CWD
    start_timeout=180,
    start_watchdog=False,         # the watchdog pops Notepad, turn it off
)
```

- **Process hygiene (must include mpiexec!)**: clear zombies before launching (they hold the single license seat / port). **Killing only `fluent,python` is not enough** — parallel solving is orchestrated by `mpiexec`, and a crash leaves behind about 20 mpiexec processes + orphan solvers that hold 1055@localhost, causing the next `launch_fluent` to report **"Connection refused" (F11)**. The correct command:

  ```powershell
  Get-Process fluent,mpiexec,cortex,python -ErrorAction SilentlyContinue | Stop-Process -Force
  Start-Sleep 10
  Get-Process fluent,mpiexec -ErrorAction SilentlyContinue   # must be empty before launching
  ```

  **Do not kill + launch in the same command** (the seat/port won't have time to be released). Even when `session.exit()` exits cleanly, in practice about 2 fluent processes still linger holding the lock, so run this cleanup **before every launch**, no matter how the previous run ended (F9/F11).

---

## 2. Reading the mesh / reading case-data

```python
session.tui.file.read_case(MESH_H5)                 # read mesh only
session.tui.file.read_case_data(CASE_H5)            # read case+data (continuation/post-processing)
session.tui.file.write_case_data(CASE_H5)           # write case+data
```

- If on read the farfield zone has the native type `pressure-far-field`, it will spam the "Pressure far-field … ideal gas law" warning (F10).
  - **Incompressible route**: use `/mesh/modify-zones/zone-type` to convert it to velocity-inlet/pressure-outlet/symmetry and the warning disappears, harmless (see §3).
  - **Compressible route**: keep / convert to `pressure-far-field`, because you are already using ideal-gas + Energy, so the warning is meaningless (see §3a).
- The solver **refuses to read a pure surface mesh**: `"Surface meshes cannot be read under /file/read-case"` → you must have a **volume mesh** before rendering/solving.

---

## 3. Changing boundary zone types — the wrap incompressible route (multi-face decomposition of AoA)

> This is the topology used by the early **fault-tolerant wrap + incompressible** route. For the compressible conforming route see §3a (simpler — a single far-field suffices).

When the angle of attack α≠0, the incoming flow has a vertical component, so the **bottom face must be inflow and the top face must be outflow** — they cannot all be symmetry (otherwise the vertical component is flattened and the AoA is lost):

```python
def ti(session, cmd):  # wrapper for fixed-argument TUI commands (no interactive prompt, safe)
    esc = cmd.replace("\\", "/").replace('"', '\\"')
    return session.scheme_eval.scheme_eval(f'(ti-menu-load-string "{esc}")')

for z in ["farfield-xmin", "farfield-zmin"]:   # bottom / windward face
    ti(session, f"/mesh/modify-zones/zone-type {z} velocity-inlet")
for z in ["farfield-xmax", "farfield-zmax"]:   # top / leeward face
    ti(session, f"/mesh/modify-zones/zone-type {z} pressure-outlet")
for z in ["farfield-ymin", "farfield-ymax"]:   # side faces (symmetry only valid when β=0)
    ti(session, f"/mesh/modify-zones/zone-type {z} symmetry")
```

> The criterion for a safe TUI command: **a fixed number of arguments, no follow-up prompt**. Something like zone-type is safe. The dangerous ones are commands that pop a follow-up prompt such as "write file? / file name?" (see F3, §7).

---

## 3a. ⭐ pressure-far-field — the conforming compressible route (a single boundary carries the AoA)

> This is the external-flow boundary actually adopted by the **final conforming compressible** route, and it is far simpler than §3's multi-face decomposition: **one pressure-far-field boundary** encodes the angle of attack using `Mach + flow_direction` (a unit vector), so you don't have to split the box into multiple pieces.

**Step one: convert the outer-box zone to `pressure-far-field` (go via TUI by zone id; there is no settings binding).**
Get the zone id from `get_surfaces_info()[boxzone]["zone_id"]` (the outer box = the zone in §9a that has no `-shadow` twin).
**You must convert the type before accessing `boundary_conditions.pressure_far_field[boxzone]`**, otherwise that BC object does not yet exist:

```python
sinfo = session.field_info.get_surfaces_info()
boxid = sinfo[boxzone].get("zone_id")
ti(session, f"/mesh/modify-zones/zone-type {boxid} pressure-far-field")
```

**Step two: set_state (note everything uses short key names).** `m`=Mach, `t`=temperature, `gauge_pressure`=static gauge pressure, `flow_direction`=**a list of `{value}` dicts** (written component-by-component in a loop), turbulence uses flat keys:

```python
MACH = 0.245
T_INF = 288.16
DRAG_DIR = [0.99863, 0.0, 0.052336]   # = incoming-flow unit vector for α 3°

pf = session.setup.boundary_conditions.pressure_far_field[boxzone]
st = pf.get_state()                   # look at the real structure first (iron law §0)
st["m"]["value"] = MACH               # ⚠ it's 'm', not 'mach_number'
st["t"]["value"] = T_INF              # ⚠ it's 't', not 'temperature'
st["gauge_pressure"]["value"] = 0.0
for i, v in enumerate(DRAG_DIR):
    st["flow_direction"][i]["value"] = v   # flow_direction is a list of {value}
st["turbulent_intensity"] = 0.05
st["turbulent_viscosity_ratio_real"] = 10
pf.set_state(st)
```

**Step three (mandatory FARFIELD_VERIFY gate): read back m/t/flow_direction and assert; abort immediately on mismatch.**
**This is because the wrong long key names (`mach_number`/`temperature`) silently no-op** — they throw no exception, the boundary stays at Fluent's **default Mach ~0.6 / T 300K**, and so you would compute the entire run at the wrong (transonic) speed without ever knowing. This is the same "silent default value" trap as F2 and F7. Below is the real gate from lines 77–92 of `pyfluent_conforming_solve_full.py`:

```python
chk = pf.get_state()
gotm = chk["m"]["value"]
gott = chk["t"]["value"]
gotd = [c["value"] for c in chk["flow_direction"]]
if abs(gotm - MACH) > 1e-4 or abs(gott - T_INF) > 0.1 or abs(gotd[0] - DRAG_DIR[0]) > 1e-3:
    raise RuntimeError(f"far-field read-back mismatch: m={gotm} t={gott} dir={gotd} — abort")
```

- The thresholds are exactly the three above: `|m−0.245|>1e-4`, `|t−288.16|>0.1`, `|dir[0]−0.99863|>1e-3` → `raise`.
- **Never let it quietly run out a result at the wrong speed on the default values.** The angle of attack relies entirely on `flow_direction`; T/Mach determine q and the compressible effects.
- This route touches **only one** outer-box boundary; the inlet/outlet/symmetry multi-face decomposition in §3 is the wrap-era alternative — pick one of the two.

---

## 4. ⭐ F2 — Inlet velocity components (carrying the AoA, the wrap velocity-inlet route)

> Only §3's wrap velocity-inlet route needs this section; §3a's far-field route uses `flow_direction` and does not go through here.

The real structure in 0.17.1: switch `momentum.velocity_specification_method` to `"Components"`, and the components live in `momentum.velocity_components` = **a list of 3 `{option, value}` dicts**.

```python
vi = session.setup.boundary_conditions.velocity_inlet["farfield-xmin"]

# Step 1: switch to the component method
st = vi.get_state()
st["momentum"]["velocity_specification_method"] = "Components"
vi.set_state(st)

# Step 2: read back, then assign component-by-component (each list item is {option:'value', value:x})
st = vi.get_state()
for i, val in enumerate((VX, VY, VZ)):       # e.g. (83.2191, 0, 4.3613)
    st["momentum"]["velocity_components"][i]["value"] = val
vi.set_state(st)

# Step 3: anti-fabrication read-back check
got = [c["value"] for c in vi.get_state()["momentum"]["velocity_components"]]
assert abs(got[0]-VX) < 0.01 and abs(got[2]-VZ) < 0.01, f"AoA did not take effect: {got}"
```

Turbulence is on the same object: `st["turbulence"]["turbulent_intensity"]=0.05`, `st["turbulence"]["turbulent_viscosity_ratio_real"]=10`.

Outlet: `pressure_outlet[z]`'s `momentum.gauge_pressure.value=0` + the same turbulence keys.

---

## 5. Material, turbulence model, reference values (including the compressible ideal-gas branch)

**Incompressible (low speed, U<100 m/s and Ma<0.3) — constant density:**

```python
# air (note density/viscosity are {option:'constant', value:x})
air = session.setup.materials.fluid["air"]
st = air.get_state(); st["density"]["value"]=1.225; st["viscosity"]["value"]=1.7894e-5
air.set_state(st)
```

**Compressible (U>100 m/s or Ma>0.3) — enable Energy + ideal-gas density + constant viscosity** (measured on the conforming route):

```python
# 1) you must enable the energy equation first
session.setup.models.energy.set_state({"enabled": True})

# 2) air: change density to ideal-gas (ideal gas, density varies with p,T), keep viscosity constant
air = session.setup.materials.fluid["air"]
ast = air.get_state()
ast["density"] = {"option": "ideal-gas"}                 # not {'value':...}
if isinstance(ast.get("viscosity"), dict):
    ast["viscosity"]["option"] = "constant"
    ast["viscosity"]["value"]  = 1.7894e-5
air.set_state(ast)
```

**Shared by both routes — k-omega SST + reference values:**

```python
viscous = session.setup.models.viscous
viscous.set_state({"model": "k-omega", "k_omega_model": "sst"})
# fallback (if settings fails): session.tui.define.models.viscous.kw_sst("yes")

# reference values: compressible must include temperature; when area/length are estimates the coefficients are only process-validation values
session.setup.reference_values.set_state({
    "area": REF_AREA, "length": REF_LENGTH,
    "density": RHO, "velocity": U_INF,
    "temperature": T_INF,                # required on the compressible route (affects q, speed of sound, coefficient basis)
})
```

- Reading back the reference values shows the full structure (including default keys like `temperature`, `yplus`, `zone`); just confirm area/length/velocity/temperature are correct.
- Dynamic pressure q = ½ρU² (for this flow case ½·1.225·83.333² = **4253.5 Pa**) is the basis of the moment-coefficient conversion factor q·A·L (§6).

---

## 6. ⭐ F7 — Force and moment report definitions (the moment-unit trap)

> The acting surfaces (zones) = the set of aircraft wall surfaces. The wrap route uses `boundary_conditions.wall.keys()`; the conforming route uses the `aircraft` list identified by §9a's shadow-topology (more robust, not relying on hard-coded names).

```python
rd = session.solution.report_definitions
aircraft = list(session.setup.boundary_conditions.wall.keys())   # or use the aircraft list from §9a

# force (outputs raw N, no unit trap)
for name, vec in [("drag_force", DRAG_DIR), ("lift_force", LIFT_DIR), ("side_force", SIDE_DIR)]:
    rd.force.create(name)
    rd.force[name].set_state({"zones": aircraft, "force_vector": vec})

# moment — the default report_output_type is "Drag Coefficient" (= moment coefficient, ÷q·A·L), not N·m!
# you can set report_output_type to "Drag Force" right at create time (works in the conforming script), but still read back to verify.
for name, axis in [("roll_moment",[1,0,0]), ("pitch_moment",[0,1,0]), ("yaw_moment",[0,0,1])]:
    rd.moment.create(name)
    rd.moment[name].set_state({
        "zones": aircraft, "mom_center": MOM_CENTER, "mom_axis": axis,
        "report_output_type": "Drag Force",    # ⚠ unset = outputs coefficient; set explicitly for raw N·m
    })
    # read back the entire state to check hidden keys, confirm it really is Drag Force:
    print(rd.moment[name].get_state()["report_output_type"])   # → 'Drag Force'
```

- **The enum only has `(Drag Coefficient | Drag Force)`** (the moment definition reuses the enum names of the force definition):
  - `"Drag Coefficient"` = output the **moment coefficient** (divided by q·A·L)
  - `"Drag Force"` = output the **raw moment in N·m**
- The default is `"Drag Coefficient"`. For raw N·m: `set_state({"report_output_type": "Drag Force"})` either at create time or afterwards, and **always read back to confirm**.
- Setting `"Moment"` is rejected: `Value is not allowed (Moment is_not_in (Drag Coefficient, Drag Force))`.
- The conversion factor = q·A·L (measured in this project, the ratio across all three channels is exactly = 93.3126736 = q·A·L, which confirms "the default is the coefficient").

**compute (same data path as monitoring):** returns a list of dicts; the value may be a list, so take `[0]`:
```python
out = rd.compute(report_defs=["drag_force", "pitch_moment"])
# → [{'drag_force':[13.140, 0]}, {'pitch_moment':[-0.330, 0]}]
vals = {}
for d in out:
    for k, v in d.items():
        vals[k] = v[0] if isinstance(v, list) else v
```

> Lesson: **after creating any report definition you must read back the entire state** — default hidden keys can quietly change what the numbers mean.

---

## 7. ⭐ F3 — Persist force/moment history with report_files (never use interactive TUI reports)

The interactive `/report/forces/wall-forces yes <vector>` has the wrong argument order in 2024R1 → an "Empty filename" infinite loop → the transcript spams up to 9.8 million lines, the script hangs, and the case/data is lost. **Disable all interactive TUI reports.** Use report_files instead:

```python
rf = session.solution.monitor.report_files
rf.create("force_moment_hist")
rf["force_moment_hist"].set_state({
    "report_defs": ["drag_force","lift_force","side_force","roll_moment","pitch_moment","yaw_moment"],
    "file_name": REPORT_FILE,      # persisted to this .out every step
    "frequency": 1,
})
# read back to confirm (the verified real state keys; on 0.17.1 these three keys are enough to create it successfully):
# {name, file_name, frequency, itr_index, run_index, frequency_of, report_defs, print, active, write_instantaneous_values}
```

- **The case/data must be saved immediately after `iterate`** (F3 lost 800 steps of results because the write was queued after the force report).
- History file parsing: the header row contains `(Iteration drag_force ... yaw_moment)` and the data rows are floats; a restart/continuation may repeat headers / overlap iteration numbers, so **de-duplicate by iteration number keeping the last occurrence**, then take the most recent 200 rows for the fluctuation-rate statistics.
- **Judge liveness by the growth of rows in the history file, not by process CPU** (on this machine the wrapper process CPU reads 0 even while iterating normally); but **a report file locked by another holder will show stale rows** (false stall, which once led to killing a healthy task) → cross-check against the per-iteration milestones in the script's `.out`.

---

## 8. ⭐ F4 — Disable Fluent's default convergence criterion (otherwise it stops early)

Fluent's default residual criterion of 1e-3 is **nowhere near enough** for external-flow force convergence (in this project it reported "converged" at 48 steps while the forces were still climbing). You must explicitly disable it before solving:

```python
res = session.solution.monitor.residual
st = res.get_state()
# real structure: st["equations"] = {'continuity':{...}, 'x-velocity':{...}, ..., 'omega':{...}}
for eq in st["equations"].values():
    if isinstance(eq, dict) and "check_convergence" in eq:
        eq["check_convergence"] = False
res.set_state(st)
# read back to confirm all are False
assert all(not v.get("check_convergence", True) for v in res.get_state()["equations"].values())
# fallback (when settings fails): session.tui.solve.monitors.residual.check_convergence("no","no","no","no","no","no")
```

**Anti-fabrication verification**: after disabling, run a short probe iteration (e.g. 20–30 steps); if it returns in `<5s` and the history rows don't grow = the disable did not succeed → abort.
Once you've confirmed the criterion is truly disabled, run the main iteration (external-flow forces usually need on the order of 800 steps to stabilize; the compressible conforming case stabilizes its forces at ~200 steps).

### 8a. ⭐ Discretization scheme: start first-order, and for the compressible case **stay first-order** (second-order diverges at the switch point)

```python
# momentum starts with first-order upwind (TUI); the compressible case **stays first-order throughout**
ti(session, "/solve/set/discretization-scheme/mom 0")   # 0 = first-order upwind
```

- **This compressible case (Ma 0.245, ideal-gas) diverges/hangs immediately when switched to second-order upwind at ~iter30** → only first-order all the way is stable (~18–20 s/iter on the 112MB mesh).
- **The price (must be stated in the report)**: the numerical dissipation of first-order upwind **systematically over-predicts drag by ~10–25%**. Measured, the conforming first-order compressible drag of 16.7 N is ~27% higher than the wrap incompressible 13.14 N — this is mostly a **numerical/compressible artifact, not a real aerodynamic difference**.
- Therefore: **the shape of the Cp/field is trustworthy** (the imaging goal is achieved), but the **absolute drag from a first-order run is only process-validation grade**, not a design value. Trustworthy drag requires converging second-order — for compressible this usually needs a ramp (converge first-order first, then carefully switch after softening relaxation/CFL, or use pressure-based coupled); you cannot hard-switch at iter30.

### 8b. ⭐ Chunked iteration + intermediate checkpoints (probe the ETA first)

Cut the iteration into small chunks, writing case/data after each chunk so that at any intermediate moment you have a renderable result (F3-safe):

```python
session.tui.solve.initialize.hyb_initialization()
session.tui.solve.iterate(30)                       # probe: measure per-step wall clock, estimate ETA, verify the criterion is disabled
session.tui.solve.iterate(170)
session.tui.file.write_case_data(CASE_H5)           # ~iter 200, checkpoint immediately (F3)
session.tui.solve.iterate(150)
session.tui.file.write_case_data(CASE_H5)           # ~iter 350
session.tui.report.fluxes.mass_flow()               # mass conservation (safe TUI, no prompt)
```

- Before writing, `os.remove` the old `.cas.h5/.dat.h5` to avoid the overwrite prompt.
- mass_flow outputs the kg/s and Net for each boundary; the Net/flux ratio is the mass imbalance (≈9e-9 in this project, excellent).
- Run long tasks in the background, polling the history-file row growth (not process CPU) ~every 10 minutes; see §7 for liveness judgment.

---

## 9. ⭐ F5 — y+ / scalar fields extracted per facet

0.17.1 **does not have** `session.fields`; calling `get_scalar_field_data` directly returns an empty dict. The correct route is the transaction API:

```python
fd = session.field_data          # not session.fields.field_data (doesn't exist)
fi = session.field_info

# get the wall surface_id (note the key is surface_id, the value is a list)
sinfo = fi.get_surfaces_info()
sid = sinfo["[wall_zone_name]"]["surface_id"]        # e.g. [0]

# per-facet scalar (the leaf is a numpy array)
tx = fd.new_transaction()
tx.add_scalar_fields_request(field_name="y-plus", surface_ids=sid,
                             node_value=False, boundary_value=True)   # note it's surface_ids, not surfaces
payload = tx.get_fields()
# payload is a nested dict: {(('type','scalar-field'),('dataLocation',1),('boundaryValues',True)): {0: {'y-plus': ndarray}}}
# just recurse out the numpy array (21110 facets in this project, matching the wall triangle count)

# the shortcut route when you only need the range (min/max):
rng = fi.get_scalar_field_range("y-plus", node_value=False, surface_ids=sid)  # signature: (field, node_value=False, surface_ids=None)
```

- The y+ interval-share statistics directly feed the y+ gate: how much falls in <11 / 11–30 / 30–100 / 100–300 / ≥300.
- The y+ shown on a rendered figure is the **node average** (smaller; node max ~477 in this project); for auditing use the facet data (which includes the extreme 602) as authoritative, and note the basis in the report.

---

## 9a. ⭐ shadow-topology distinguishes aircraft walls vs the outer box (essential for conforming)

In a conforming/watertight mesh, internal/wall surfaces generate paired `<name>-shadow` twin zones.
**The outer-box outer boundary has no `-shadow` twin, but the aircraft walls do** — use this to robustly separate the two without hard-coding zone names (used for §6's force-integration zones, §3a's boxzone, and the imaging surfaces_list):

```python
names = list(session.field_info.get_surfaces_info().keys())
nonshadow = [n for n in names if not n.endswith("-shadow")]
aircraft  = [n for n in nonshadow if (n + "-shadow") in names]        # aircraft: has a shadow twin
box       = [n for n in nonshadow if (n + "-shadow") not in names][0] # outer box: no shadow twin (unique)
```

- `surface_id` / `zone_id` are taken from `sinfo[name]` (`sinfo = get_surfaces_info()`):
  `boxid = sinfo[box]["zone_id"]` (→ §3a zone-type conversion), `sid = sinfo[name]["surface_id"]` (→ §9 y+ extraction).
- **The `(thread-n-faces ...)` scheme that discriminates by face count returns None in 0.17.1 and is unusable** → you can only rely on the `-shadow` naming.
- This project ultimately **solved the 10-region conforming mesh as a whole, directly**: the outer air region was given the pressure-far-field box boundary, the 9 closed fuselage cavities are harmless dead air pockets (stagnation, no through-flow), and the aircraft outer skin (selected by `aircraft` above) carries the external pressure load.
  The closed inner cavities do not pollute the external-flow solution. (A truly clean "box minus aircraft = single fluid region" must be built in the SpaceClaim GUI; see §13.)

---

## 10. ⭐ F8 — Headless imaging (the camera-won't-redraw trap)

`show_gui=False` can render (white-background PNG, up to 2560×1440). Two fatal traps:
1. When a named graphics-object container is empty, `get_state()` returns **None** → don't use `name in get_state()` to test existence; just try `create()`.
2. **`display()` resets the camera back to the default front view**; settings made via `/display/views/camera/{target,position,up-vector}` **do not trigger a redraw**, so `save-picture` grabs the old buffer → measured to have no effect in headless mode.

**The reliable route** (every step redraws immediately):

```python
tui = session.tui
gr = session.results.graphics

# global imaging settings
tui.display.set.picture.driver.png()
tui.display.set.picture.use_window_resolution("no")
tui.display.set.picture.x_resolution(1920); tui.display.set.picture.y_resolution(1080)

# cross-section
cx, cy, cz = BODY_CENTER
tui.surface.plane_point_n_normal("plane-y", cx, cy, cz, 0, 1, 0)   # fixed 7 args, safe

# contour object (create may throw when the container is empty; fall back to assigning an empty dict; only set keys that actually exist)
try: gr.contour.create("c_vel")
except Exception: gr.contour["c_vel"] = {}
obj = gr.contour["c_vel"]; st = obj.get_state()
p = {"field": "velocity-magnitude", "surfaces_list": ["plane-y", WALL]}
if "node_values" in st: p["node_values"] = True
if "filled" in st: p["filled"] = True
obj.set_state(p)

# reliable imaging sequence: display → restore-view → auto-scale → (when the body isn't at the domain center) pan → zoom → save
obj.display()
tui.display.views.restore_view("top")        # viewing the XZ plane = side view; use "isometric" for the body surface figure
tui.display.views.auto_scale()
tui.display.views.camera.pan_camera(-DX_OFFSET, 0)   # pan unit = viewport ratio (not world coordinates); sign determined empirically from two candidates
tui.display.views.camera.zoom_camera(6.0)
path = os.path.join(IMG_DIR, "img.png")
if os.path.exists(path): os.remove(path)     # delete first to avoid the overwrite prompt
tui.display.save_picture(path)
```

- `restore-view` / `auto-scale` / `pan-camera` / `zoom-camera` all **redraw immediately**, which is why this route works.
- Aircraft surface figure (showing only the wall): `restore_view("isometric")` + `auto_scale()` is enough to frame the body, no pan needed.
- **Re-framing a large-domain cross-section**: in a 10m outer domain the aircraft occupies only ~3% of the frame, and after auto_scale it's a small dot. Use `field_info.get_scalar_field_range("x-coordinate"/"z-coordinate", surface_ids=boxsid)` to get the domain center, `pan_camera(CX-cx, CZ-cz)` to pull the aircraft back to the center of the frame, then `zoom_camera(7.0)`; pan is a viewport ratio, not world coordinates, so a single pan still drifts — you can use `System.Drawing` to stitch the color bar strip (px 0–360) + the centered-aircraft crop (px 1500–2560) into the final figure.
- Verifying the output: a nonzero `os.path.getsize()` is only a necessary condition; **you must read the PNG back and inspect it by eye / multimodally** to confirm the viewpoint is correct.

---

## 11. Common available / unavailable list (0.17.1 quick reference)

| What you want to do | Available | Unavailable / trap |
|---|---|---|
| See an object's real structure | `obj.get_state()` | guessing key names |
| Inlet components (wrap) | `momentum.velocity_components[i]["value"]` | a top-level `u/v/w` key does not exist F2 |
| far-field AoA (conforming) | `pf` short keys `m`/`t`/`flow_direction`(list of {value}) + read-back gate | `mach_number`/`temperature` (silent no-op, stuck at default Ma~0.6)|
| outer box → far-field | `/mesh/modify-zones/zone-type <boxid> pressure-far-field` | accessing `pressure_far_field[box]` before conversion (object doesn't exist)|
| raw moment in N·m | set `report_output_type="Drag Force"` (works at create time) + read back | default "Drag Coefficient"=coefficient F7 |
| computing reports | `report_definitions.compute(report_defs=[...])` (take `[0]`)| — |
| force/moment history | `solution.monitor.report_files` persisted to disk | interactive `/report/forces/wall-forces` (infinite loop F3)|
| disable convergence criterion | `solution.monitor.residual` each eq `check_convergence=False` | not setting = early stop at 48 steps F4 |
| compressible properties | `models.energy={'enabled':True}` + density `{'option':'ideal-gas'}` + viscosity constant | forgetting to enable Energy for compressible; reference values missing `temperature` |
| discretization scheme | first-order `/solve/set/discretization-scheme/mom 0`, stay first-order for compressible | switching to second-order at ~iter30 diverges for compressible; first-order over-predicts drag 10–25% |
| y+ per facet | `field_data.new_transaction()` + `add_scalar_fields_request(surface_ids=...)` | `session.fields` (doesn't exist), `get_scalar_field_data` called directly (empty) F5 |
| y+ range | `field_info.get_scalar_field_range(field, node_value, surface_ids)` | — |
| scalar field names (contour/range) | `velocity-magnitude` `pressure` `pressure-coefficient` `mach-number` `y-plus` | a typo and you get nothing |
| wall shear stress field name | `wall-shear` (measured working) | **`wall-shear-stress` often fails** → use the candidate fallback `['wall-shear-stress','wall-shear','x-wall-shear-stress']` and take the first that succeeds |
| aircraft walls vs outer box | `-shadow` twin naming (has=aircraft, none=outer box) F10 | `(thread-n-faces ...)` scheme returns None |
| headless imaging | `display→restore-view→auto-scale→pan→zoom→save` | `camera/*` settings don't redraw F8 |
| BL verification | the **wedge count** from the cell-type breakdown | the hex count (that's the hexcore core, not prisms) F6 |
| process cleanup | `Get-Process fluent,mpiexec,cortex,python | Stop-Process` + sleep + verify empty | killing only `fluent,python` (leaves mpiexec orphans → Connection refused F11)|

---

## 12. Anti-fabrication gate template (runs through every script)

```python
def safe(label, fn, required=False):
    try:
        r = fn(); log(f"{label}=OK {repr(r)[:300]}"); return {"ok": True, "result": r}
    except Exception as e:
        log(f"{label}=ERROR {repr(e)}"); log(traceback.format_exc())
        if required: raise
        return {"ok": False, "error": repr(e)}
```

- Critical steps with `required=True`: on failure, throw immediately and abort — never continue.
- AoA components, **far-field m/t/flow_direction (§3a)**, the convergence-criterion disable, the report-definition type — all are **read back and verified** after set, and `raise` on any mismatch.
- Write the `.out` log throughout + a `.json` summary at the end; run long tasks in the background, polling the `.out` (history row growth, not process CPU).
- **Coefficient discipline**: when the reference area/length/moment center are **estimates**, label Cd/Cl/Cm uniformly as "process-validation grade", never treat them as design values (no final conclusion is possible without the real wing area + CG).

For reference implementations see [`../scripts/conforming_farfield_solver_reference.py`](../scripts/conforming_farfield_solver_reference.py), [`../scripts/conforming_postproc_imaging_reference.py`](../scripts/conforming_postproc_imaging_reference.py).

---

## 13. ⭐ A "rough-looking" surface = wrap, not CAD (conforming vs enclosure mesh)

External-flow meshing has two routes, and their surface smoothness differs enormously:

| | fault-tolerant **wrap** | watertight **conforming** |
|---|---|---|
| workflow | `wf.fault_tolerant(dynamic_interface=True)` | `wf.watertight(dynamic_interface=True)` |
| surface | wraps a layer of **enclosure skin** over the geometry, discards the CAD faces, spikes at thin edges | **conforms to the real CAD faces**, smooth |
| size control | the size field is locked to "Default" (**F9**, GlobalMin override has no effect, headless refinement is infeasible, capped at 3 tries) | `CFDSurfaceMeshControls.MinSize` takes effect directly (MinSize=1mm → 4.5MB smooth surface) |
| STEP import | headless SpaceClaim conversion crashes (**F1**) | **reads STEP directly, no crash** (different importer) |
| applies to | dirty geometry (multi-body with gaps) | clean closed solids |

**Judgment: if a surface figure is badly faceted/spiked, first ask "is this a wrap?" rather than blaming the CAD.** Clean closed solids should go through the watertight conforming route:

```python
wf.watertight(dynamic_interface=True)
imp = wf.task("Import Geometry")
imp.arguments.update_dict({"FileName": STEP, "LengthUnit": "mm", "FileFormat": "CAD"})  # STEP read directly, no F1
imp.Execute()
sm = wf.task("Generate the Surface Mesh")
c = dict(sm.arguments.get_state()["CFDSurfaceMeshControls"])
c["MinSize"], c["MaxSize"], c["SizeFunctions"] = 1.0, 300.0, "Curvature & Proximity"  # fine on curved surfaces / coarse on flat ones
sm.arguments.update_dict({"CFDSurfaceMeshControls": c}); sm.Execute()
```

**Traps (measured):**
- watertight **has no external-flow enclosure task** (the task list only goes up to the geometry's own regions). External-flow conforming requires a clean "box minus aircraft = single fluid region" geometry prepared in advance; using the dirty fluid_domain (box + aircraft as separate bodies) yields **a pile of flow volumes** (topology error).
  And under 0.17.1 headless, **watertight's region controls all fail**: `NumberOfFlowVolumes=1` is ignored (read back still 10), setting the 9 sub-regions to `dead` is ignored (still all fluid), and `Update Boundaries` throws the same `RuntimeError('Unknown exception')` as F1 and also corrupts the topology.
  Building a clean enclosure belongs to interactive meshing / the SpaceClaim GUI.
- **The workaround (this project's final solution)**: stop trying to carve out the single fluid region, and **solve the 10-region mesh as a whole, directly** (the outer region gets pressure-far-field, the 9 closed inner cavities are harmless dead air pockets) — see §9a and §3a. This produced a smooth Cp field and avoided the region extraction that is unsolvable headless.
- The solver **refuses to read a pure surface mesh** ("Surface meshes cannot be read under /file/read-case") → rendering bare geometry requires a volume mesh first.
- When rendering, distinguish **aircraft walls vs the outer box**: see §9a's shadow-topology recipe (internal walls have a `-shadow` twin, the outer box does not).
