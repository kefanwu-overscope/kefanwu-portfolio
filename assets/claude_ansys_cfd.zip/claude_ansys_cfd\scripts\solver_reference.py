# Reference solver script — drone external-flow CFD, Ansys Fluent 2024 R1 + PyFluent 0.17.1
# ============================================================================
# This is a single reference implementation merged from the two verified Javelin_V1
# code segments: "first solve" and "restart/continuation".
# Each API recipe maps to docs/02_pyfluent_playbook.md, with built-in anti-fabrication gates:
#   - F2: read back and verify inlet velocity components after set (AoA took effect) -- abort on mismatch
#   - F3: no interactive TUI reports; report_files persist to disk; write case/data immediately after iterate
#   - F4: disable the default residual convergence criterion before solving + verify with a probe iteration -- abort if not disabled
#   - F7: explicitly set the moment report definition to "Drag Force" to get raw N.m + read back the full state
# To switch cases, edit only the "edit per case" constant block; the logic below encodes the F-series fixes -- do not break it.
# ============================================================================

import json
import math
import os
import sys
import time
import traceback

# ===== Environment (see docs/05_environment.md) =====
sys.path.insert(0, r"D:\ansys2024\ANSYS Inc\v241\optiSLang\lib\python3.10\Lib\site-packages")
from ansys.fluent.core import launch_fluent
from ansys.fluent.core.launcher.launcher import FluentMode

# ===== Edit per case =====
WORKDIR    = r"C:\Users\oc\Desktop\Codex_Ansys"
MESH       = os.path.join(WORKDIR, "your_case_extmesh.msh.h5")
CASE_DATA  = os.path.join(WORKDIR, "your_case_alpha3.cas.h5")
DATA_FILE  = os.path.join(WORKDIR, "your_case_alpha3.dat.h5")
REPORT_FILE= os.path.join(WORKDIR, "your_case_force_moment_history.out")
OUT        = os.path.join(WORKDIR, "solver_reference.out")
JSON_OUT   = os.path.join(WORKDIR, "solver_reference.json")

ALPHA_DEG  = 3.0
U_INF      = 300.0 / 3.6                              # 83.3333 m/s
VX, VY, VZ = (U_INF*math.cos(math.radians(ALPHA_DEG)), 0.0, U_INF*math.sin(math.radians(ALPHA_DEG)))
DRAG_DIR   = [math.cos(math.radians(ALPHA_DEG)), 0.0, math.sin(math.radians(ALPHA_DEG))]
LIFT_DIR   = [-math.sin(math.radians(ALPHA_DEG)), 0.0, math.cos(math.radians(ALPHA_DEG))]
SIDE_DIR   = [0.0, 1.0, 0.0]
RHO, MU    = 1.225, 1.7894e-5
REF_AREA   = 0.043876                                 # m^2  [estimated -> coefficients are process-validation only]
REF_LENGTH = 0.500                                    # m
MOM_CENTER = [-1.011984, 0.600000, 1.120000]          # m    [estimated]
ITERATIONS = 800
PROBE_ITERS = 20                                      # verify the convergence criterion has been disabled

INLET_ZONES   = ["farfield-xmin", "farfield-zmin"]    # AoA freestream: inflow on bottom/windward face
OUTLET_ZONES  = ["farfield-xmax", "farfield-zmax"]    # outflow on top/leeward face
SYMMETRY_ZONES= ["farfield-ymin", "farfield-ymax"]    # side faces (beta=0)
# ===== End of constant block =====


def log(m):
    with open(OUT, "a", encoding="utf-8") as f:
        f.write(str(m) + "\n")


def safe(label, fn, required=False):
    try:
        r = fn(); log(f"{label}=OK {repr(r)[:300]}"); return {"ok": True}
    except Exception as e:
        log(f"{label}=ERROR {repr(e)}"); log(traceback.format_exc())
        if required:
            raise
        return {"ok": False, "error": repr(e)}


def ti(session, cmd):  # safe TUI (fixed args, no follow-up prompts)
    esc = cmd.replace("\\", "/").replace('"', '\\"')
    return session.scheme_eval.scheme_eval(f'(ti-menu-load-string "{esc}")')


def count_history_rows():
    if not os.path.exists(REPORT_FILE):
        return 0
    n = 0
    with open(REPORT_FILE, "r", errors="ignore") as f:
        for line in f:
            parts = line.replace('"', "").replace("(", "").replace(")", "").split()
            try:
                [float(x) for x in parts]
                if parts:
                    n += 1
            except ValueError:
                pass
    return n


def main():
    for p in [OUT, JSON_OUT]:
        if os.path.exists(p):
            os.remove(p)
    os.environ["AWP_ROOT241"] = r"D:\ansys2024\ANSYS Inc\v241"
    data = {"alpha_applied": False, "conv_disabled": False, "steps": {}}
    session = None
    try:
        session = launch_fluent(
            product_version="24.1.0", mode=FluentMode.SOLVER, precision="double",
            processor_count=4, show_gui=False, cleanup_on_exit=False,
            cwd=WORKDIR, start_timeout=120, start_watchdog=False,
        )
        safe("READ_CASE", lambda: session.tui.file.read_case(MESH), True)

        # --- Boundary types (AoA topology) ---
        for z in INLET_ZONES:
            safe(f"TYPE_{z}", lambda z=z: ti(session, f"/mesh/modify-zones/zone-type {z} velocity-inlet"), True)
        for z in OUTLET_ZONES:
            safe(f"TYPE_{z}", lambda z=z: ti(session, f"/mesh/modify-zones/zone-type {z} pressure-outlet"), True)
        for z in SYMMETRY_ZONES:
            safe(f"TYPE_{z}", lambda z=z: ti(session, f"/mesh/modify-zones/zone-type {z} symmetry"), True)
        safe("MESH_CHECK", session.tui.mesh.check, True)

        bc = session.setup.boundary_conditions

        # --- F2: inlet velocity components + read-back verification (both inlets must pass) ---
        alpha_ok = True
        for z in INLET_ZONES:
            vi = bc.velocity_inlet[z]
            st = vi.get_state()
            st["momentum"]["velocity_specification_method"] = "Components"
            vi.set_state(st)
            st = vi.get_state()
            for i, val in enumerate((VX, VY, VZ)):
                st["momentum"]["velocity_components"][i]["value"] = val
            st["turbulence"]["turbulent_intensity"] = 0.05
            st["turbulence"]["turbulent_viscosity_ratio_real"] = 10
            vi.set_state(st)
            got = [c["value"] for c in vi.get_state()["momentum"]["velocity_components"]]
            log(f"INLET_VERIFY_{z}={got}")
            alpha_ok = alpha_ok and abs(got[0]-VX) < 0.01 and abs(got[2]-VZ) < 0.01
        data["alpha_applied"] = alpha_ok
        if not alpha_ok:
            raise RuntimeError("inlet velocity components read back do not match: AoA did not take effect, aborting (do not solve in a bad state)")

        # --- Outlets ---
        for z in OUTLET_ZONES:
            po = bc.pressure_outlet[z]
            st = po.get_state()
            st["momentum"]["gauge_pressure"]["value"] = 0
            st["turbulence"]["turbulent_intensity"] = 0.05
            st["turbulence"]["turbulent_viscosity_ratio_real"] = 10
            safe(f"PO_{z}", lambda po=po, st=st: po.set_state(st))

        # --- Material / SST / reference values ---
        air = session.setup.materials.fluid["air"]
        st = air.get_state(); st["density"]["value"] = RHO; st["viscosity"]["value"] = MU
        safe("SET_AIR", lambda st=st: air.set_state(st))
        viscous = session.setup.models.viscous
        if not safe("SET_SST", lambda: viscous.set_state({"model": "k-omega", "k_omega_model": "sst"}))["ok"]:
            safe("SET_SST_TUI", lambda: session.tui.define.models.viscous.kw_sst("yes"))
        safe("REFERENCE", lambda: session.setup.reference_values.set_state(
            {"area": REF_AREA, "length": REF_LENGTH, "density": RHO, "velocity": U_INF}))

        wall_zones = list(bc.wall.keys())
        log(f"WALL_ZONES={wall_zones}")

        # --- F7: force (raw N) and moment (explicitly set Drag Force = raw N.m) report definitions ---
        rd = session.solution.report_definitions
        for name, vec in [("drag_force", DRAG_DIR), ("lift_force", LIFT_DIR), ("side_force", SIDE_DIR)]:
            safe(f"RD_{name}", lambda n=name: rd.force.create(n))
            safe(f"RD_{name}_set", lambda n=name, v=vec: rd.force[n].set_state({"zones": wall_zones, "force_vector": v}))
        for name, axis in [("roll_moment", [1, 0, 0]), ("pitch_moment", [0, 1, 0]), ("yaw_moment", [0, 0, 1])]:
            safe(f"RD_{name}", lambda n=name: rd.moment.create(n))
            safe(f"RD_{name}_set", lambda n=name, a=axis: rd.moment[n].set_state(
                {"zones": wall_zones, "mom_center": MOM_CENTER, "mom_axis": a, "report_output_type": "Drag Force"}))
            # read back the full state to check hidden default keys (F7: default is Drag Coefficient = coefficient)
            log(f"RD_{name}_state={json.dumps(rd.moment[name].get_state(), default=repr)}")

        # --- F3: report_files persist every step to disk (never use interactive TUI force reports) ---
        if os.path.exists(REPORT_FILE):
            os.remove(REPORT_FILE)
        rf = session.solution.monitor.report_files
        rf.create("force_moment_hist")
        rf["force_moment_hist"].set_state({
            "report_defs": ["drag_force", "lift_force", "side_force", "roll_moment", "pitch_moment", "yaw_moment"],
            "file_name": REPORT_FILE, "frequency": 1,
        })
        log(f"REPORT_FILE_MONITOR={json.dumps(rf['force_moment_hist'].get_state(), default=repr)}")

        # --- F4: disable the default convergence criterion + read back ---
        res = session.solution.monitor.residual
        st = res.get_state()
        for eq in st.get("equations", {}).values():
            if isinstance(eq, dict) and "check_convergence" in eq:
                eq["check_convergence"] = False
        res.set_state(st)
        disabled = all(not v.get("check_convergence", True)
                       for v in res.get_state().get("equations", {}).values() if isinstance(v, dict))
        if not disabled:  # fall back to TUI
            safe("CONV_DISABLE_TUI", lambda: session.tui.solve.monitors.residual.check_convergence(
                "no", "no", "no", "no", "no", "no"))
        log(f"CONV_DISABLE_SETTINGS={disabled}")

        # --- Initialize + probe iteration to verify the criterion is truly disabled ---
        safe("HYB_INIT", session.tui.solve.initialize.hyb_initialization, True)
        rows0 = count_history_rows(); t0 = time.time()
        safe("ITERATE_PROBE", lambda: session.tui.solve.iterate(PROBE_ITERS), True)
        elapsed = time.time() - t0; rows1 = count_history_rows()
        log(f"PROBE elapsed={elapsed:.1f}s rows {rows0}->{rows1}")
        if elapsed < 5 and rows1 - rows0 < PROBE_ITERS - 5:
            raise RuntimeError("failed to disable the convergence criterion: probe returned in seconds and history did not grow, aborting (do not fabricate a continuation)")
        data["conv_disabled"] = True

        # --- Main iteration ---
        safe("ITERATE_MAIN", lambda: session.tui.solve.iterate(ITERATIONS - PROBE_ITERS), True)

        # --- F3: save immediately after iterate (delete old files first to avoid the overwrite prompt) ---
        for p in [CASE_DATA, DATA_FILE]:
            if os.path.exists(p):
                os.remove(p)
        safe("WRITE_CASE_DATA", lambda: session.tui.file.write_case_data(CASE_DATA), True)

        # --- Mass conservation (safe TUI) ---
        safe("MASS_FLOW", lambda: session.tui.report.fluxes.mass_flow())
        log("DONE: run the convergence/y+ audit by reading the saved files with postproc_audit_reference.py")
    except Exception as e:
        data["fatal"] = repr(e); log(f"FATAL={repr(e)}"); log(traceback.format_exc())
    finally:
        with open(JSON_OUT, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False, default=repr)
        if session is not None:
            try:
                session.exit()
            except Exception:
                pass


if __name__ == "__main__":
    main()
