# Standard Operating Procedure (SOP) — Drone External-Flow CFD

> End-to-end workflow. Each phase ends with a **GATE**; if the gate-check fails, stop and fix it — do not force-push to the next step.
> For how to write the API see [`02_pyfluent_playbook.md`](02_pyfluent_playbook.md); for the hard gate-check metrics see [`03_quality_gates.md`](03_quality_gates.md);
> for how to choose among the three meshing routes see [`06_meshing_strategy.md`](06_meshing_strategy.md); for rendering images see [`07_postprocessing_and_imaging.md`](07_postprocessing_and_imaging.md);
> for detailed explanations of failure numbers F1–F11 see [`04_failure_recovery.md`](04_failure_recovery.md).

---

## Phase 0 — Confirm the Flow Case

Classify the airframe type (fixed-wing / multirotor / VTOL), the objective (fuselage drag / whole-aircraft lift-to-drag / angle-of-attack study / crosswind / rotor slipstream / hover / transition),
and the rotor treatment (ignore / actuator disk / MRF / sliding mesh).

Confirm the coordinate convention (default: +X nose→tail and aligned with the freestream, +Z up, +Y to the right, α positive = nose pitch-up, β positive = freestream skewed to the right).
**If the coordinates are uncertain you must ask the user to confirm**, otherwise the signs of forces/moments may be inverted.

Decide **compressible vs incompressible** (this drives the boundary setup of the Phase 1a meshing route and the material properties in Phase 3): for U<100 m/s and Ma<0.3 go incompressible constant-density;
for U>100 m/s or Ma>0.3 go compressible ideal-gas + Energy. This case is U=83.33 m/s (Ma 0.245), which is borderline —
the wrap route is run as incompressible; **the conforming route is run as compressible ideal-gas** (nose stagnation pressure +4590 Pa ≈ q, self-consistent).

Use [`../templates/case_input_template.yaml`](../templates/case_input_template.yaml) to fill in a flow case,
tagging each item `[user]` or `[estimated]`. For missing items, use a default first-cut value but explicitly annotate "not valid for design conclusions".

Special VTOL note: **hover / transition / cruise must be computed separately** — do not lump them into a single steady external flow.
This package's scripts target **cruise (forward-flight cruise)**; when the propeller is ignored the result excludes slipstream and is not applicable to hover/transition.

---

## Phase 1 — Geometry and Air Domain

1. CAD cleanup: keep the outer aerodynamic surfaces, remove internal parts, small screws, text, decorative grooves, and small holes. Export STEP AP214/AP242 or Parasolid.
   **Avoid Chinese / special characters in file names.**
2. Build a bounding-box air domain: upstream 5L, downstream 15L, side/top/bottom 5L (when the wake is long or recirculation is severe, downstream→20L, side/top/bottom→7L).
3. **Subtract the aircraft solid body from the air domain, keeping only the fluid volume** (iron law 1).
4. Geometry repair: stitch, patch faces, remove redundant edges, remove small faces.

> This machine's reality (see F1): SpaceClaim headless conversion STEP→FMD AccessViolation-crashes and is reproducible — **use only the fault-tolerant import path**.
> Countermeasure: for the wrap route feed FTM a **successfully cached FMD**, do not let FTM import the .step; **watertight uses a different importer, can read STEP directly without crashing** (see Phase 1a).

**GEOM GATE**: units verified; fluid domain exists; the solid body has been subtracted (rather than filling the solid with mesh as if it were fluid); no obvious missing faces/openings; domain dimensions recorded.

---

## Phase 1a — Meshing-Strategy Decision (choose the route first, then act) ⭐ New

**Before touching the mesh you must first settle on the meshing route**, because the route determines how the Phase 1 geometry is prepared and how the Phase 3 boundaries are set.
The full decision table / trade-offs / headless limitations of the three routes are in [`06_meshing_strategy.md`](06_meshing_strategy.md); here we give only the selection logic:

| Geometry / constraint | Route to choose | Consequence |
|---|---|---|
| Dirty geometry (multiple bodies, gaps) + only need to "get it running first" | **A. fault-tolerant WRAP** | Loses CAD faces, faceted surfaces, wingtip spikes; STEP must crash (F1) → feed FMD; size field locked (F9) → surface refinement ineffective (capped at 3 tries); **coefficients are process-validation grade only** |
| Clean geometry + need smooth Cp plots + a "box minus aircraft = single region" prepared in the SpaceClaim GUI | **B. watertight CONFORMING** | Conforming preserves CAD, smooth; STEP read directly without crash; surface sizing `CFDSurfaceMeshControls` takes effect directly |
| Clean geometry + **fully headless + cannot extract a clean single region** | **C. DIRECT-SOLVE multi-region conforming (this case's breakthrough)** | Don't carve out a single region; **solve the ~10-region conforming mesh directly**: one outer-box face is pressure-far-field, the 9 sealed internal cavities stagnate harmlessly |

**Key decision principle (for external flow when CAD fidelity matters): prefer conforming/watertight over fault-tolerant wrap.**
Wrap drapes a layer of envelope skin over the outside of the part, discards the real CAD faces, spawns spikes at thin edges, and its size field can't be changed headless (F9) —
so surface fields (Cp) are faceted and untrustworthy. Conforming preserves the real CAD faces, the surface sizing is controllable, and the Cp plots are smooth and trustworthy.
**"The surface looks coarse" is almost always the fault of the wrap skin, not the CAD** (see the key clarification in 06 §1).

**If forced into multi-region conforming (route C): don't fight to the death over "single-region extraction" — solve the multi-region mesh directly.**
Under 0.17.1 headless, watertight has no enclosure task and all region controls fail (`NumberOfFlowVolumes=1` is ignored, setting `dead` is ignored,
`Update Boundaries` throws `RuntimeError('Unknown exception')` and corrupts the topology — the same stubborn root cause as F6/F9, see 06 §3).
**The workaround**: feed the whole ~10-region conforming mesh straight to the solver, give the outer air region a **single pressure-far-field** box boundary,
and treat the 9 sealed fuselage internal cavities as harmless dead air pockets (stagnant, no through-flow, do not pollute the external solution; rationale in 06 §5). This case took route C.

**MESH-STRATEGY GATE**: route chosen and rationale recorded; compressible/incompressible decided;
if A is chosen, confirmed acceptance of "coefficients are process-validation grade only"; if B is chosen, confirmed the GUI has a clean single region ready; if C is chosen, confirmed acceptance of sealed internal cavities and first-order throughout.

---

## Phase 2 — Mesh

- Global: CFD preference, Fluent solver, linear elements, high smoothing, slow transition, capture curvature + proximity, growth rate 1.2.
- Sizing: wall L/100, far-field L/20~L/40, wake L/80~L/120; local refinement at wing leading/trailing edges, wingtips, tail, and junctions.
  - Conforming (B/C) surface sizing uses `CFDSurfaceMeshControls.{MinSize,MaxSize,SizeFunctions="Curvature & Proximity",CurvatureNormalAngle}`
    (MinSize=1mm → smooth surface; curved surfaces auto-refined, flat surfaces coarsened) — **takes effect directly**, unaffected by the size field that wrap locks (playbook §13).
- Boundary layer (inflation): boundary=wall_body, 8~12 layers, growth 1.2.
  - Wall-resolved (strategy A, target y+≈1): with L≈0.5 m, U≈83 m/s the first layer ≈0.0046 mm.
  - Wall function (strategy B, target y+ 30~100): first layer ≈0.14 mm. Accuracy is degraded; must be noted in the report.

> This machine's reality (see F6): passing boundary-layer parameters via the FTM compound parent task's `arguments.update_dict()` is ignored
> (the generated control is named `aspect-ratio_1` rather than the set `first_height_1`). **You must mimic the Identify Regions
> child-task pattern, explicitly create a BL child task, and read it back**, and use the **wedge count in the cell-type breakdown** to verify the BL was really generated
> (the hex count is hexcore core cells, not prisms — don't use it as BL evidence). Take the wedge count from the transcript,
> **do not read the whole `.trn` file** (F3 once spewed 9.8 million lines); use `Select-String "wedge"` / `tail`.

**MESH GATE (see [03 §Mesh gate](03_quality_gates.md) and 06 §9)**: negative volume=0; max skewness<0.95 (recommended <0.90);
min orthogonal quality>0.10 (recommended >0.15); boundary naming complete (inlet/outlet/wall_body/far-field, iron law 3);
**boundary layer genuinely generated (wedge>0, cell-type breakdown) and first-layer height adopted**; surface fidelity (conforming smooth / wrap faceting then coefficients downgraded).
If the gate fails → go back to Phase 1/1a/2 to fix, **no solving allowed**.

---

## Phase 3 — Solver Setup

- Launcher: 3D, double precision, parallel (`launch_fluent(product_version="24.1.0", mode=SOLVER, precision="double", processor_count=4, show_gui=False, start_watchdog=False, cwd=WORKDIR)`, playbook §1). General: pressure-based, steady.
- Models:
  - Incompressible (U<100, Ma<0.3): Energy Off, constant density ρ=1.225.
  - **Compressible (U>100 or Ma>0.3): Energy On + density ideal-gas + viscosity constant** (playbook §5); the reference value `temperature` is mandatory.
  - Shared by both routes: k-ω SST.
- Material: air, μ=1.7894e-5 (for incompressible also add ρ=1.225).

### 3a — Boundary Conditions (per the route chosen in Phase 1a, one of the two)

- **wrap incompressible route (multi-face angle-of-attack decomposition, playbook §3, §4)**: when α≠0 the freestream has a vertical component,
  **bottom/upstream face velocity-inlet, top/downstream face pressure-outlet, side faces symmetry (only when β=0)**; you cannot make all faces symmetry (otherwise the vertical component is flattened and the angle of attack fails).
  - inlet components per U·(cosα, 0, sinα), using `momentum.velocity_components[i]["value"]` (a list, F2), TI 5%, TVR 10;
  - outlet `gauge_pressure=0` + the same TI/TVR; wall_body = no-slip stationary wall.

- **⭐ conforming compressible route (a single pressure-far-field carries the angle of attack, playbook §3a)**: touch only **one** outer-box boundary; the angle of attack is encoded via Mach + the flow_direction unit vector.
  1. **First convert the outer-box zone type** (TUI, by zone id): `/mesh/modify-zones/zone-type <boxid> pressure-far-field`
     (`boxid` taken from `get_surfaces_info()[box]["zone_id"]`; box = the zone in the §9a shadow topology that has no `-shadow` twin).
     **You must convert the type before accessing** `boundary_conditions.pressure_far_field[box]`, otherwise the BC object does not exist.
     (On read-in, a native pressure-far-field spews "ideal gas law" warnings, F10; they vanish after the conversion, harmless.)
  2. **set_state uses only the short key names** (playbook §3a): `m`=Mach (**not** `mach_number`), `t`=temperature (**not** `temperature`),
     `gauge_pressure`=0, `flow_direction`=**a list of `{value}` dicts** (component-by-component = the α unit vector), `turbulent_intensity`/`turbulent_viscosity_ratio_real`.
  3. **⭐ FARFIELD_VERIFY gate (mandatory)**: after setting, **read back and assert; if mismatched, immediately `raise` to abort**.
     The long key names (`mach_number`/`temperature`) **silently no-op** — no error is raised, and the boundary quietly sits at **Fluent's default Mach ~0.6 / T 300**,
     so you would compute an entire run at the wrong (transonic) speed without ever knowing (the same kind of silent-default trap as F2, F7). Thresholds:
     ```python
     abs(got_m   - 0.245)    > 1e-4   -> abort   # target Mach
     abs(got_t   - 288.16)   > 0.1    -> abort   # target T (K)
     abs(got_dir[0] - 0.99863) > 1e-3 -> abort   # flow_direction[0] = α=3° unit vector
     ```

- Reference values: density, velocity, area, length, moment center (for compressible also add temperature); for missing area/center see iron law 6. q=½ρU² (this case 4253.5 Pa).
- Monitoring: force/moment report definitions + **report_files written to disk every step** (playbook §6, §7). **Disable all interactive TUI reports** (F3).
- **Disable the default convergence criterion** (playbook §8, otherwise F4 cuts off prematurely at ~48 steps with forces far from settled).

**SETUP GATE**: solver matches the physics (for compressible, Energy + ideal-gas are on);
**angle of attack verified to be in effect** (wrap route: velocity components read back; conforming route: **FARFIELD_VERIFY read-back passes**);
reference values set (for compressible includes temperature); force/moment monitoring built and persisted (moment `report_output_type="Drag Force"` read back and confirmed = N·m, F7); convergence criterion disabled and verified by a probe.
Any one fails → stop and fix, do not enter iteration.

---

## Phase 4 — Solve

1. mesh check (safe TUI). 2. scale if needed. 3. Hybrid Initialization.
4. **Discretization scheme: start first-order** (`/solve/set/discretization-scheme/mom 0`).
   **For this compressible case (Ma 0.245, ideal-gas) keep first-order throughout** — hard-switching to second-order upwind at ~iter30 immediately diverges / stalls (playbook §8a).
   - The cost (**must be written into the report**): first-order upwind numerical dissipation **systematically overestimates drag by ~10–25%** (this case's conforming first-order 16.7 N is ~27% higher than the wrap incompressible 13.14 N, mainly numerical/compressible, not a real aerodynamic difference).
   - Therefore: **Cp/field shapes are trustworthy** (the imaging objective is met), but the **absolute drag from a first-order run is process-validation grade only**. Trustworthy drag requires letting a second-order ramp converge, not a hard switch at iter30.
5. Chunked iteration + `write_case_data` after each chunk (external-flow forces typically need ~800 steps to settle; compressible conforming forces settle at ~200 steps; don't trust "48 steps converged").
6. **Write case/data immediately after iterate** (F3 lesson — once lost 800 steps of results because the write was queued after the force report). 7. `report.fluxes.mass_flow` (safe TUI).

Run long tasks in the background + poll the history file's **row growth** ~every 10 minutes (not process CPU — on this machine the wrapper CPU reads a constant 0 while iterating normally;
a locked report file shows stale rows = false stall, then cross-check against the script's `.out` per-iteration milestones). For the transcript use Select-String/tail; do not read the whole file.

---

## Phase 5 — Convergence and y+ Audit

Checks (playbook §7~§9, gate-checks in 03):
- residual trend (≥3 orders of magnitude or a stable plateau);
- force/moment fluctuation over the last 200 steps (<1~3%);
- mass imbalance (<1%, >2% vetoes; this case ≈9e-9);
- outlet backflow (no large-area reverse flow);
- **y+ distribution** matches the wall strategy (resolved≈1, wall function 30~100). Extract y+ per facet via the transaction API (F5, playbook §9):
  `field_data.new_transaction()` + `add_scalar_fields_request(field_name="y-plus", surface_ids=[...], node_value=False, boundary_value=True)` → `get_fields()`
  (`get_scalar_field_data` called directly returns empty, `session.fields` does not exist). The audit uses facet extrema; the rendered plot is node-averaged and biased low — note the convention in the report.

**CONVERGENCE GATE / y+ gate (see [03](03_quality_gates.md))**: any one fails → do not claim the result is trustworthy, grade it "process-validation grade".
If the steady result keeps oscillating periodically → recommend transient. **wrap mesh wedge=0 → BL/y+ gate FAIL** (this case median 147, only 23.7% within the strategy-B 30–100 band), nailing it to process-validation grade.

---

## Phase 6 — Force / Moment / Coefficient Extraction

- Forces: raw N (report_files / `report_definitions.compute` same convention, take the value at `[0]`).
- Moments: note the default output is a coefficient; for N·m you must set `report_output_type="Drag Force"` and read back to confirm (F7; the enum has only `Drag Coefficient | Drag Force`).
- Coefficients: q=½ρU²; Cd=D/(q·A), Cl=L/(q·A), Cm=M/(q·A·L).
  **When the reference area / moment center are estimated values, all coefficients are tagged "process-validation value" only and are never used as a design conclusion.**

**REPORT GATE**: force/moment units confirmed (N / N·m, not coefficients); compute and report_files agree on convention;
if coefficients come from estimated reference quantities they are tagged process-validation grade. This case's final conforming delivered values (process-validation grade):
q=4253.5 Pa; Drag 16.736 N, Lift 14.483 N, Side −0.156 N; Roll −0.034 / Pitch −0.408 / Yaw −0.034 N·m; L/D 0.87; Cd 0.0897 / Cl 0.0776.

---

## Phase 7 — Post-Processing and Imaging

Headless rendering (playbook §10, [`07_postprocessing_and_imaging.md`](07_postprocessing_and_imaging.md)): velocity/pressure cross-section contour plots, body-surface pressure/Cp/y+, cross-section velocity vectors, planform pressure.
- For field names use `velocity-magnitude` / `pressure` / `pressure-coefficient` / `mach-number` / `y-plus`; for wall shear stress use **`wall-shear`** (**`wall-shear-stress` often reports `is_not_in` failure**; use a candidate fallback).
- Distinguish the aircraft wall vs the outer box using the §9a shadow topology. **The solver refuses to read a pure surface mesh** → rendering bare geometry requires a volume mesh first.
- Headless camera trap (F8): `display()` resets the camera, and `camera/*` settings do not trigger a redraw; the reliable sequence is `display→restore-view→auto-scale→pan→zoom→save-picture`.
- After producing images, **read out the PNG and visually inspect the viewing angle** — don't just check the file size.

---

## Phase 8 — Report

Follow [`../templates/report_template.md`](../templates/report_template.md). Must include: inputs and assumptions, geometry, **meshing-route choice (A/B/C) and rationale**, mesh, solver setup,
boundary conditions (including far-field m/t/flow_direction or inlet components), **discretization scheme (first-order/second-order and its cost)**, reference values, forces and moments, convergence checks, mass imbalance, y+, plots, **confidence rating, limitations, next steps**.
**Tag the confidence of every number; coefficients produced from estimated reference values are tagged process-validation value only; write down limitations such as the wrap surface / sealed internal cavities / first-order overestimation; never write in anything that was not really run.**

---

## Gate Overview (gate-before-next-phase quick reference)

| Phase boundary | Gate | Key criterion | See |
|---|---|---|---|
| 0→1 | Flow-case confirmation | coordinate convention, compressible/incompressible, units | this doc, Phase 0 |
| 1→1a | GEOM GATE | fluid domain exists, solid subtracted, no openings | Phase 1 |
| 1a→2 | MESH-STRATEGY GATE | route A/B/C chosen and rationale recorded | [06](06_meshing_strategy.md) |
| 2→3 | MESH GATE | neg-vol=0, skew/ortho, naming complete, **wedge>0** | [03](03_quality_gates.md) / [06 §9](06_meshing_strategy.md) |
| 3→4 | SETUP GATE + **FARFIELD_VERIFY** | angle-of-attack read-back, reference values, monitoring persisted, criterion disabled | Phase 3 / playbook §3a §8 |
| 4→5 | (iteration survival) | history row growth, mid-run archiving | playbook §7 §8b |
| 5→6 | CONVERGENCE / y+ GATE | residuals, force fluctuation<1–3%, mass imb<1%, y+ matched | [03](03_quality_gates.md) |
| 6→8 | REPORT GATE | force/moment units, coefficients tagged process-validation grade | Phase 6 |

> Process cleanup must include mpiexec (`Get-Process fluent,mpiexec,cortex,python | Stop-Process -Force` → `Start-Sleep 10` → read back as empty → then launch;
> **never kill+launch in the same command**, single license seat, orphan mpiexec → "Connection refused", F9/F11; see [`05_environment.md`](05_environment.md) and [`04_failure_recovery.md`](04_failure_recovery.md)).
