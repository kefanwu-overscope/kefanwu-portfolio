# Reference scripts guide (scripts index)

> These scripts are **reference implementations** distilled from the Javelin_V1 case
> (Ansys Fluent 2024 R1 + PyFluent 0.17.1, real run in 2026-06). Each API recipe maps to one recipe in
> [`../docs/02_pyfluent_playbook.md`](../docs/02_pyfluent_playbook.md),
> and is annotated with the failure number it fixes (F2/F3/F4/F5/F7/F8/F9/F11).
> For full background, see [`../examples/Javelin_V1_case_study.md`](../examples/Javelin_V1_case_study.md).

## Two classes of scripts (must read)

| Class | Scripts | Meaning |
|---|---|---|
| **VERIFIED-WORKING** (currently recommended starting point) | `conforming_farfield_solver_reference.py`, `conforming_postproc_imaging_reference.py` | Genericized line-by-line from a **real conforming external-flow run**: the solver script completed one full 200-iter solve (first-order upwind, Ma 0.245, ideal-gas, SST), and the imaging script reads its case/data to produce Cp/y+/cross-section plots. The entire script ran through end-to-end as a whole on a real case. |
| **ILLUSTRATIVE / old** (still correct, but not run through as a whole) | `solver_reference.py`, `postproc_audit_reference.py`, `postproc_images_reference.py` | Templates for the earlier **extmesh (multi-face box: velocity-inlet/pressure-outlet/symmetry)** route. Here **each API recipe was individually verified in the Javelin_V1 case** (inlet-component read back, convergence-criterion-disable probe, report_files persisted to disk, moment unit conversion, y+ transaction extraction, imaging camera sequence), but the script **was never run through as a single whole in one pass**. |

**Where to start a new case?** Use **`conforming_farfield_solver_reference.py`** to solve +
**`conforming_postproc_imaging_reference.py`** for imaging/audit. They encode the most reliable route currently available:
**solve the multi-region conforming mesh directly, with the outer domain using just [one] pressure-far-field box boundary** — this is the fix route settled on after headless
refinement of the fault-tolerant WRAP mesh proved impossible (the size field locked up, 3 failures, F9);
the 9 internal airframe cavities exist as harmless dead/sealed regions holding stagnation air, and the aircraft outer skin (picked out from shadow topology) directly carries the external pressure load in the solve.

The old extmesh scripts (`solver_reference.py` etc.) demonstrate how to write **multi-face box boundaries**, and remain
correct and useful as a recipe dictionary; but if what you have is a conforming/watertight volume mesh, **prefer the conforming_\* route**.

## Honesty statement (in line with this package's no-fabrication discipline)

- The `===== CONFIG (edit per case) =====` / `===== edit per case =====` constant block at the top of every script
  holds Javelin_V1's specific values (paths, reference values, angle of attack, zone names/logic). **To switch cases, edit only the constant block**;
  the logic below the constant block encodes the F-series fixes and the various read-back gates — do not break it.
- Even the VERIFIED-WORKING scripts **retain all read-back gate-checks** (FARFIELD_VERIFY, convergence-criterion-disable probe,
  full-state read back of report definitions, moment unit check). On the first run on a new case, let these gate-checks confirm for you that each step really takes effect,
  and **do not skip the validation just because "it's a reference script"**.
- The reference area/length/moment center are **estimated values**, so the Cd/Cl/Cm computed from them are only **"process-validation"** grade,
  and **must never be used as design conclusions**; all quantities carry units.

## File list

| Script | Status | Purpose (one line) | Demonstrates | Fixes involved | Corresponding docs |
|---|---|---|---|---|---|
| [`conforming_farfield_solver_reference.py`](conforming_farfield_solver_reference.py) | **VERIFIED-WORKING ★recommended** | Read multi-region **conforming** mesh → set **single pressure-far-field** box (Mach+flow_direction encode AoA) → ideal-gas+Energy+SST → **disable convergence criterion** → chunked first-order iteration → save case/data per chunk → force/moment report | shadow topology splits box/aircraft; FARFIELD_VERIFY read-back gate; first-order (second-order diverges) | F2, F3, F4, F7, F9, F11 | [`02_pyfluent_playbook.md`](../docs/02_pyfluent_playbook.md), [`01_workflow_sop.md`](../docs/01_workflow_sop.md), [`04_failure_recovery.md`](../docs/04_failure_recovery.md) |
| [`conforming_postproc_imaging_reference.py`](conforming_postproc_imaging_reference.py) | **VERIFIED-WORKING ★recommended** | Read conforming-solution case+data (no re-solve) → aircraft surface Cp/pressure contour plots (multi-view) + large-domain longitudinal cross-section (velocity/pressure/Mach) + wall-shear/y+ contour plots + streamlines → force/moment compute + coefficients → per-facet y+ array | F8 camera sequence; shadow zone split; wall-shear field name; large-domain cross-section pan/zoom reconstruction | F5, F7, F8 | [`07_postprocessing_and_imaging.md`](../docs/07_postprocessing_and_imaging.md), [`02_pyfluent_playbook.md`](../docs/02_pyfluent_playbook.md) |
| [`solver_reference.py`](solver_reference.py) | ILLUSTRATIVE / old | **extmesh multi-face box** solve template: read mesh → set inlet/outlet/symmetry + material + SST + reference values → build monitors → **disable convergence criterion** → iterate → archive → mass conservation | how to write multi-face box boundaries; inlet-component list read back; convergence-criterion-disable probe | F2, F3, F4, F7 | [`02_pyfluent_playbook.md`](../docs/02_pyfluent_playbook.md), [`01_workflow_sop.md`](../docs/01_workflow_sop.md) |
| [`postproc_audit_reference.py`](postproc_audit_reference.py) | ILLUSTRATIVE / old | Read from disk for **quantitative audit**: force/moment statistics over the last 200 steps, empirical moment-unit conversion (coefficient ↔ N·m), y+ distribution proportions | report-history deduplication statistics; moment unit conversion; y+ facet array extraction | F5, F7 | [`03_quality_gates.md`](../docs/03_quality_gates.md), [`02_pyfluent_playbook.md`](../docs/02_pyfluent_playbook.md) |
| [`postproc_images_reference.py`](postproc_images_reference.py) | ILLUSTRATIVE / old | Headless rendering of cross-section/surface contour plots (velocity/pressure/Cp/y+/vectors) for the extmesh solution | F8 camera sequence (display→restore-view→auto-scale→pan→zoom→save) | F8 | [`07_postprocessing_and_imaging.md`](../docs/07_postprocessing_and_imaging.md) |

## Key invariants encoded by the two conforming_* scripts (be sure to preserve)

- **The far-field keys are [short names]** `m` (Mach), `t` (temperature), `flow_direction` (a `[{value}]` **list**),
  **not** `mach_number`/`temperature`. The long names **do not error** but silently no-op, leaving the boundary at the Fluent default Mach≈0.6
  → producing wrong results at the wrong velocity. **You must read back** `m` after setting, and raise/abort if `abs(got_m - MACH) > 1e-4` (the FARFIELD_VERIFY gate).
- **box → far-field** via TUI: `/mesh/modify-zones/zone-type <zone_id> pressure-far-field`.
- **The wall shear field name is `"wall-shear"`**, not `"wall-shear-stress"` (the latter often fails parsing as `is_not_in`).
  Available field names: `velocity-magnitude` / `pressure` / `mach-number` / `wall-shear` / `y-plus`.
- **y+ numeric extraction**: `session.field_data.new_transaction()` +
  `add_scalar_fields_request(field_name="y-plus", surface_ids=[...], node_value=False, boundary_value=True)`
  → `get_fields()`; `get_scalar_field_data` returns empty, and `session.fields` does not exist.
- **A moment report definition outputs coefficients by default** → to get raw N·m you must explicitly set
  `report_output_type="Drag Force"`; after creating any report definition, **read back the full state** to catch hidden default keys (F7).
- **Disable the convergence criterion**: for every equation, `solution.monitor.residual ... check_convergence=False`
  (the default 1e-3 stops this class of flow case early at ~48 steps), and verify it is disabled with a short iteration probe (F4).
- **Disable interactive TUI reports** (`/report/forces/wall-forces ...` falls into an 'Empty filename' infinite loop that floods 9.8 million lines, F3);
  use `report_files` + `report_definitions.compute`.
- **Second-order upwind diverges in this compressible (Ma 0.245) flow case** → first-order throughout; first-order systematically overestimates drag by ~10-25%, which the report must note.

## How to run

```powershell
# 1) Clear the zombie process family before every launch -- must include mpiexec! (killing only fluent,python
#    leaves orphan mpiexec/solver processes that hold the single license -> next launch reports Connection refused, F11)
Get-Process fluent,mpiexec,cortex,python -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep 10
Get-Process fluent,mpiexec   # read back to confirm empty; do not kill+launch in the same command (no time to release the license)

# 2) Run with Ansys's bundled CPython (system PATH has no python/py), run in background and poll .out (PER_ITER/CHUNK/ETA milestones)
& 'D:\ansys2024\ANSYS Inc\v241\commonfiles\CPython\3_10\winx64\Release\python\python.exe' `
    .\conforming_farfield_solver_reference.py
```

Key `launch_fluent` parameters: `product_version="24.1.0"`, SOLVER mode, `precision="double"`,
`processor_count=4`, `show_gui=False`, `start_watchdog=False` (the watchdog pops up Notepad), `cwd=WORKDIR`.
For environment paths and stall detection (watch report-FILE row growth, not process CPU), see [`../docs/05_environment.md`](../docs/05_environment.md).

## Final delivered figures for the Javelin_V1 conforming route (process-validation grade, reference quantities are estimated)

> q=4253.5 Pa; Drag 16.736 N, Lift 14.483 N, Side -0.156 N;
> Roll -0.034 / Pitch -0.408 / Yaw -0.034 N·m; L/D 0.87;
> Cd 0.0897 / Cl 0.0776 (**process-validation only, not design values**, derived from estimated reference quantities).
