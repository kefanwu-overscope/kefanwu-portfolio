# Case Study — Javelin_V1 VTOL Cruise (how the rules actually played out in one real run)

> This is the source case for this package's scripts and discipline (Ansys Fluent 2024 R1 + PyFluent 0.17.1, 2026-06, fully scripted and unattended throughout).
> Read it to see clearly: **how the gate-checks, the no-fabrication gating, and the F1–F11 fixes do their work across one end-to-end run** —
> and especially how several "looks-like-success-but-isn't" traps got caught.
>
> The case is told in two acts: **Act One (wrap mesh)** gets the workflow running and catches 4 "fake success" traps (F1–F8); **Act Two (the conforming breakthrough, continuation)** fixes the rough surface, produces design-grade images, and delivers the final forces/moments/coefficients (F9–F11).

---

## Flow case

- VTOL cruise forward flight, U=300 kph=83.3333 m/s (Ma 0.245, Act One treated as incompressible, Act Two as compressible ideal-gas), α=3°, β=0.
- Geometry: aero-core 8-solid-body simplified subset (the full 54-body model is too dirty, pending repair). Fuselage length L=0.5 m, Re≈2.85e6. Propeller ignored.
- The reference values are **all estimates**: reference area 0.043876 m² (bounding-box projection), reference length 0.5 m, moment center (-1.011984, 0.6, 1.12) m
  (bounding-box center, not the true CG). → Per iron law 6, all coefficients are treated as **process-validation values** from start to finish.

---

## Act One timeline: how each gate-check/trap was handled (wrap mesh)

### 1. Geometry (F1)
SpaceClaim headless conversion STEP→FMD crashed twice in a row with `AccessViolationException`.
**Did not force the issue** — switched to feeding FTM the FMD cache that succeeded yesterday. The crash left 2 zombie fluent processes, which were cleaned up.

### 2. Mesh gate — a "fake pass"
Mesh generation succeeded: 157,951 cells, max skew 0.699, min ortho 0.084 (marginally acceptable).
The cell breakdown read "119,227 tet + 27,220 hex + 11,504 poly".
**Early misread**: the 27,220 hex were taken to be "boundary-layer prisms", so the BL was assumed to have been generated.
**Caught at the audit stage (F6)**: in the transcript's cell breakdown, **wedge = 0** — true BL prisms are the wedge type; the 27,220 hex are hexcore volume-fill core cells. So the boundary layer was **never generated at all** (the FTM compound task ignored the 0.14 mm×10 layers setting, and the control it generated was named `aspect-ratio_1` rather than the configured `first_height_1`).
→ The BL item of the mesh gate **FAILs**, recorded as a limitation; this is the root cause of the later y+ gate FAIL.
**Lesson locked in**: BL verification must use the wedge count — you cannot take the hex count as evidence.

### 3. Solver setup (F2)
The first attempts at the inlet velocity components, using guessed key names, all failed — but the **no-fabrication gating correctly aborted** (exited in 22 s, rather than silently running with a broken angle of attack).
After the log exposed the real structure, switching to `momentum.velocity_components[i]["value"]`, read back and verified both inlets at (83.2191, 0, 4.3613) → angle of attack in effect.

### 4. Two fatal traps during the solve (F3 + F4)
- **F3**: the first version of the script used the interactive TUI `wall-forces` report; in 2024R1 the argument order didn't match → "Empty filename" infinite loop,
  the transcript ballooned to **9.8 million lines**, the script hung, and **800 steps of results were lost** (case/data had not yet been saved).
  Fix: disable interactive TUI reports, switch to report_files written to disk; move case/data save to the first thing after iterate.
- **F4**: after applying the F3 patch and rerunning, `iterate(800)` instead printed `! 48 solution is converged` at **step 48** and returned early —
  triggered by Fluent's default residual criterion of 1e-3. At that point drag was fluctuating 78.8% across the whole window (still climbing), and the **convergence gate FAILs**.
  **Did not treat this "converged" as real convergence.** Fix: the continuation script disables `check_convergence` per equation in `solution.monitor.residual`,
  verifies via a 20-step probe iteration that the criterion is truly disabled, then continues to step 848.

### 5. Convergence gate — this time it really passed
- Residuals dropped about 3.9 orders of magnitude + stable plateau.
- Forces over the last 200 steps: drag 13.14 N (fluctuation **0.15%**), lift 14.05 N (**1.12%**) → PASS.
  side 1.19 N (7.9%, but the absolute bandwidth is only ±0.047 N, small in magnitude, noted separately).
- mass imbalance: Net -6.1e-5 / flux 662 kg/s ≈ **9e-9** → PASS.
- No outlet backflow.

### 6. Moment unit trap (F7)
The audit read back the moment definition and found `report_output_type` = `"Drag Coefficient"` — our script never set this; it's the default value.
**This means the "moments" in the historical files are actually coefficients, not N·m.**
Physical corroboration supports the coefficient interpretation (if pitch=-0.00353 were in N·m, the pressure center would coincide with the estimated center to within 0.25 mm — a coincidence too implausible to believe).
Empirically: after explicitly setting `"Drag Force"` and computing, the three-channel ratio is exactly = **93.3126736 = q·A·L** → conclusively proving they were coefficients.
Obtained the authoritative N·m: Pitch -0.330, Roll -0.010, Yaw +0.089 N·m.
**Lesson locked in**: after creating any report definition, read back the full state to check for hidden default keys.

### 7. y+ gate (F5 extraction + quantitative FAIL)
`session.fields` does not exist, `get_scalar_field_data` returns empty → got it working with `field_data.new_transaction()`,
obtaining y+ for 21,110 wall facets. Distribution: min 1.6 / median 147 / mean 164 / p95 382 / max 602;
the target strategy B (30–100) covers only **23.7%**, and ≥300 accounts for **16.1%**. → **y+ gate FAILs**, quantitatively consistent with the F6 BL-not-generated finding.

### 8. Rendering (F8)
Headless rendering. Two rounds of iteration hit pitfalls: the empty container of a named object returns None from `get_state()`, `display()` resets the camera, and camera settings don't trigger a redraw.
The third version succeeded with `display → restore-view → auto-scale → pan-camera → zoom-camera → save`,
producing 7 images and reading each one out for visual inspection (velocity/pressure cross-sections, surface pressure/Cp/y+, vectors, planform).

---

## Continuation — the conforming breakthrough (2026-06-13/14)

Act One delivered a "process-validation level" result, but the Cp surface plot was clearly rough (faceted, with a spike even sticking out at the wingtip). The user disliked the rough images and asked to fix the CAD.
Act Two follows that lead downward — and the finding was that the CAD was not wrong; what was wrong was the **topology of the wrap mesh itself**, which prompted a route change, new pitfalls, and ultimately a design-grade conforming result. This act adds three new fault classes, F9/F10/F11, and is the key arc that takes this case from "got it running" to "got the goods out".

### (a) Trigger and diagnosis: the roughness comes not from the CAD but from the wrap's 5 mm envelope skin (F10)
The user asked to "fix the CAD to make the surface smooth". **Verify before acting**: reading the STEP header of `Javelin_V1_aero_core_fused_validation.step`,
it turns out to be a **single closed solid body** (`ADVANCED_BREP` + `BREP_WITH_VOIDS`, containing 8 internal voids), and the FMD cache subdivides it at 0.5 mm deviation —
**the geometry itself is entirely fine**. The roughness **all comes from the Fault-Tolerant Meshing WRAP**: it covers the part with a ~5 mm envelope skin, discards the real CAD faces, and even grows a spike at the wingtip. In one sentence: **"wrap skin" ≠ "CAD"**. Fixing the CAD was the wrong direction.

### (b) Trial and error: headless wrap refinement failed three times; watertight reading the STEP directly produced a smooth surface but no clean fluid region could be extracted (F9 + F10 continued)
**The three attempts at headless wrap refinement all came to nothing (F9)** — the FTM wrap size field is locked in at the first `Default` execution, and every lever for changing surface resolution is rendered ineffective:
1. v1 set `GLOBAL_MIN=2.0`, but "Choose Mesh Control Options" with `CreationMethod='Default'` recomputed GlobalMin back to 10 mm
   → the output was **byte-for-byte identical** to the coarse mesh (157,951 cells / 5.98 MB).
2. v2 ran Default first, then did `update_dict` GlobalMin=2.0 and re-Executed; the displayed value changed but the wrap reused the old size field → still 157,951 cells.
3. v3 set `UseSizeFieldForPrimeWrap='No'` + `FillWithSizeField='No'` to bypass the size field; the mesh changed but **in the opposite direction**
   (148,802 cells, hexcore 27,220→14,442 actually dropped, tet barely moved), and the surface was still not finer.
   → the same root disease as F6/F9: "FTM control silently ignored". **Capped at 3 attempts, stopped.**

**watertight reading the STEP directly succeeded in producing a smooth conforming surface** — the watertight workflow can **import STEP directly with no F1 crash**
(F1 only occurs on the fault-tolerant import path), and the surface size is **genuinely controllable** (not held hostage by a locked-in size field): `MinSize=1 mm`
yielded a 4.5 MB smooth conforming surface (versus the wrap's 21,110-facet rough skin).
**But the dirty `fluid_domain` geometry yields no single clean fluid region (F10 continued)**: Create Regions `NumberOfFlowVolumes=1` was ignored (read back as 10), Update Regions setting the 9 airframe subregions to `dead` was ignored (all 19 stayed `fluid`), and Update Boundaries threw the same opaque
`RuntimeError('Unknown exception')` as F1 and corrupted the zone topology. **Under 0.17.1 headless, every watertight region control (NumberOfFlowVolumes,
zone type dead) is ineffective** — the same FTM stubbornness as F6/F9.

### (c) Breakthrough: don't extract the region, just solve the 10-region conforming mesh + a single pressure-far-field box (F10 endgame)
Rather than wrestling with headless region extraction, **take the whole mesh as-is**: treat the 112 MB 10-region conforming mesh as the given state. The outer air region gets a single
pressure-far-field box boundary; the 9 sealed airframe internal cavities are **harmless pockets of dead air** (stagnant, no through-flow) that do not contaminate the external-flow solution.
The aircraft outer skin (picked out via **shadow topology** — internal/wall faces are generated in pairs with a `<name>-shadow` twin) carries the external pressure load,
and integrating over the 9 aircraft faces gives the forces. This **bypasses the unsolvable headless region extraction** and directly yields a smooth Cp field.
(The truly clean single fluid region = do a "box-minus-aircraft" in the SpaceClaim GUI, documented in `Javelin_V1_smooth_cfd_GUI_worklist.md`;
after that, mesh+solve+render can be fully headless.)

**shadow topology discrimination (robust, no hard-coded names)**:
```python
names = list(s.field_info.get_surfaces_info().keys())
nonshadow = [n for n in names if not n.endswith("-shadow")]
box      = [n for n in nonshadow if (n + "-shadow") not in names]   # outer box: no shadow twin
aircraft = [n for n in nonshadow if (n + "-shadow") in names]       # aircraft: has a shadow twin
# Note: in 0.17.1 the thread-n-faces face-count approach returns None and is unusable; rely solely on shadow naming.
```

### (d) far-field angle-of-attack trap: keys are m/t/flow_direction; the wrong name silently parks at Mach~0.6 (pressure-far-field-aoa-silent-failure)
A single pressure-far-field boundary **cleanly encodes the angle of attack**: set Mach + a flow_direction unit vector (the vector itself carries the angle of attack),
without having to split the box into multiple faces (xmin/zmin velocity-inlet, xmax/zmax pressure-outlet, ymin/ymax symmetry) to preserve the +Z component as in Act One.
**But in 0.17.1 the keys are the short names `m` (Mach), `t` (temperature), `flow_direction` (list of {value}).**
Using the plausible-looking long names `mach_number`/`temperature` **does not raise an error — it silently no-ops**, and the boundary stays at Fluent's default **Mach≈0.6 / T 300**,
so you end up computing a result, with no error of any kind, at the wrong speed (near transonic). This is the same class of "silent default" trap as F2 (velocity_components list)
and F7 (hidden report_output_type default).
**Fix = a hard verification gate (FARFIELD_VERIFY)**: after set_state, read back and, before iterating, assert Mach==0.245, T==288.16,
flow_direction==(0.99863, 0, 0.052336); abort immediately on any mismatch.
```python
# 0.17.1 pressure-far-field short keys (long names silently no-op → stuck at the default Mach 0.6)
st["m"]["value"] = MACH; st["t"]["value"] = T_INF; st["gauge_pressure"]["value"] = 0.0
for i, v in enumerate(DRAG_DIR): st["flow_direction"][i]["value"] = v
# read-back gate:
chk = pf.get_state(); gotm = chk["m"]["value"]; gotd = [c["value"] for c in chk["flow_direction"]]
if abs(gotm - MACH) > 1e-4 or abs(chk["t"]["value"] - T_INF) > 0.1 or abs(gotd[0] - DRAG_DIR[0]) > 1e-3:
    raise RuntimeError("far-field read-back mismatch — aborting")
```
The final free stream: Ma 0.245, flow_direction (0.99863, 0, 0.052336) (= α 3°), T 288.16 K, ideal-gas + Energy on + k-ω SST.

### (e) First-order decision: second-order diverges, stay first-order throughout (second-order-diverges-stay-first-order)
The compressible case (Ma 0.245, ideal-gas) **diverges/hangs immediately** when switched from first-order to second-order upwind at iter≈30 (a hard switch of the compressible scheme blew up).
So it **stays first-order upwind throughout** for stability. 112 MB, multi-million cells, ~18–20 s/iter; the forces had stabilized by ~200 iter (drag 16.95→16.7 N, <2%),
with no substantive difference by 350 iter → stopped at 200 iter for rendering.
**Known cost**: the systematic numerical dissipation of first-order upwind **overestimates drag by about 10–25%**. This (compounded with compressible vs. Act One's incompressible) is precisely why the conforming drag
(16.7 N) is ~27% higher than the wrap incompressible drag (13.14 N) — it is a **numerical/physical setup difference, not a real aerodynamic difference**.
So the Cp/flow-field **morphology** is smooth and physically correct (the rendering goal is met), but the **absolute drag number** from first-order is only process-validation level, not a design value.
(For a trustworthy drag, second-order must converge — for the compressible case this usually means first stabilizing with first-order, then gently switching relaxation/CFL, or using pressure-based coupled; you cannot hard-switch at iter 30.)

### (f) Process traps and erroneous kills (F11 + stall-detection)
- **F11 — killing only fluent,python leaves mpiexec orphans that hold the single license → Connection refused**:
  on restarting the conforming solve, the new run threw `RuntimeError('failed to connect to all addresses; ... Connection refused')` in read_case.
  Root cause: `Get-Process fluent,python | Stop-Process` **does not kill mpiexec**. Fluent parallel is orchestrated by mpiexec; killing one run
  leaves **~20 mpiexec + 1 orphan solver**, and the orphan holds the single license/port so the next connection is refused. The orphan's python client is already dead,
  so it **will never save** — pure waste. Fix (already written into the operating discipline):
  ```powershell
  Get-Process fluent,mpiexec,cortex,python -ErrorAction SilentlyContinue | Stop-Process -Force  # must include mpiexec!
  Start-Sleep 10
  Get-Process fluent,mpiexec -ErrorAction SilentlyContinue   # read-back must be empty before launching
  ```
  **Never kill+launch in the same command** (the seat/port has no time to be released). Even a normal `session.exit()` leaves ~2 fluent holding the license,
  so **clean up before every new launch**, regardless of how the previous one ended.
- **stall misjudgment: judging liveness by report-file line growth rather than process CPU; a locked report file masquerading as a stall got a healthy run killed by mistake**:
  on this Windows host, the wrapper/host process reads CPU 0 even while Fluent iterates normally, so **"CPU=0" ≠ stuck**. The correct liveness signal is
  report monitoring of the **line growth** of the `.out`/history files. But the file signal has its own fake-stall trap: a **locked report file**
  (held by another handle) shows **stale history** (no new lines), the run in healthy iteration is misread as a stall, and the **healthy run gets killed by mistake**.
  So **neither signal can be trusted alone** — cross-check against the PER_ITER/ITER milestone prints in the script's `.out`: as long as `.out` is still advancing iterations,
  the run is alive, no matter what the (possibly locked/stale) history shows.
  **After a restart you also have to guard against the orphan illusion** (continuing F11): a genuine restart **resets the report file**; if the file is not reset, an old orphan is still writing and you are watching the wrong process.

---

## Final grading and delivery

> **Grade: still process-validation level.** Both acts ran to completion, the numerical magnitudes are credible, and Act Two obtained a smooth, credible Cp/flow-field **morphology**,
> but the accuracy is still insufficient to support design decisions. The reasons for the downgrade are unchanged: the reference values are all estimates, there is no BL/wall-function-level y+, the geometry is an 8-body subset,
> and the propeller is ignored; Act Two adds one more: **first-order upwind throughout** (second-order diverges).

### Act Two (conforming) final delivered numbers (authoritative results)

- Solver setup: conforming mesh, 200 iter, **first-order upwind**, Ma 0.245 compressible ideal-gas, k-ω SST, single pressure-far-field box,
  aircraft faces ~2 mm conforming to CAD.
- Dynamic pressure q = 0.5·ρ·U² = **4253.5 Pa** (ρ 1.225, U 83.333 m/s). Reference area 0.043876 m² [estimate], reference length 0.5 m,
  moment center (-1.011984, 0.6, 1.12) [estimate, bounding-box center, not the true CG].
- **Forces (integrated over aircraft skin)**: Drag **16.736 N**, Lift **14.483 N**, Side **-0.156 N**; **L/D 0.87**.
- **Moments (about the estimated center)**: Roll Mx **-0.034**, Pitch My **-0.408**, Yaw Mz **-0.034** N·m.
- **Coefficients (process-validation only, the reference values are estimates → not for design use)**: Cd **0.0897**, Cl **0.0776**, Cy **-0.0008**,
  Cm_pitch **-0.00438**.

**Comparison with the Act One wrap result** (incompressible, iter 848): drag 13.14 N / lift 14.05 N. The conforming drag is **~27%** higher,
**mainly from first-order numerical dissipation (systematic overestimate of 10–25%) + compressibility, not a real aerodynamic difference**.

### Mandatory accompanying limitations (delivered together with the numbers)
1. First-order upwind overestimates drag by ~10–25% (second-order diverges) → the drag is process-validation level;
2. The reference area/moment center are estimates → the coefficients are not design-valid, and must be recomputed with the real wing area + CG;
3. No boundary-layer mesh / wall-function-level y+ → limited accuracy for wall shear and separation;
4. The geometry is the 8-body aero-core subset, propeller ignored (no slipstream);
5. At 200 iter the forces are stable (<2%) but not at design-grade residual convergence → the Cp/flow-field **morphology is credible**, but use the **absolute numbers** with caution.

### Final professional image set (`Javelin_V1_vtol_cruise_alpha3_images\`)

- **Surface Cp / pressure**: `cfd_cp_{isometric,left,top}.png`, `cfd_pressure_{isometric,left,top}.png`.
- **Surface wall shear / y+**: `pro_wallshear_iso.png` (field name `wall-shear`, note it is **not** `wall-shear-stress`),
  `pro_yplus_iso.png` (rendered as NODE-averaged, max ~477; the audit uses facet data with max 602, cite the facet value as authoritative).
- **Plane field (y=0.6 longitudinal section, reframed + centered)**: `pro_velocity_plane.png` (wake),
  `pro_pressure_plane.png` (**nose stagnation point +4590 Pa ≈ q, physical self-consistency check passed**), `pro_mach_plane.png`,
  `pro_streamlines_plane.png`.
- **Clean geometry six views**: `conforming_clean_{isometric,left,top,front,back,right}.png`.
- **Deleted**: `pro_vectors_plane.png` (the vector arrows auto-scale too large and the view is too zoomed out — unusable).

> **Large-domain plane reframe technique**: in a 10 m outer domain the aircraft occupies only ~3% of the frame, and after `auto_scale` the aircraft is a tiny dot.
> Use `field_info.get_scalar_field_range('x-coordinate'/'z-coordinate')` to get the box extent and center,
> `pan_camera(CX-center, CZ-center)` + `zoom_camera(7.0)` to pull the aircraft back into frame. The pan unit is a **viewport fraction**, not world coordinates,
> and a single pan is still off to the right → use `System.Drawing` for a **composite crop**: take the colorbar strip px[0:360] + the centered aircraft crop px[1500:2560] and concatenate them horizontally.

### Delivery checklist
- Act One: archived converged solution (.cas/.dat at iter 848), report (with credibility rating and limitations), 7 presentation images.
- Act Two: conforming converged solution (.cas/.dat at 200 iter), final forces/moments/coefficients table (above), professional image set (above).
- Throughout: the complete fault log **F1–F11** (`Javelin_V1_agent_session_log.md`), the conforming results summary
  (`Javelin_V1_conforming_results_summary.md`).

---

## The core lesson this case teaches you

> **"Success" has many disguises**: mesh generation succeeds but the BL wasn't generated; the script exits with code 0 but only ran 48 steps;
> iterate returns "converged" but the forces are still climbing; the moment has a number but its unit is a coefficient, not N·m;
> the surface "roughness" looks like dirty CAD but is actually the wrap skin; far-field raises no error yet parks at the default Mach 0.6; process CPU=0 yet it is iterating normally,
> the report file is stagnant yet it is locked, not stuck.
> Every one of them was caught — **not by luck, but because every step requires independent read-back/statistical evidence, rather than trusting that the previous step "looked successful"**.
> This is why all scripts have no-fabrication gating built in, why a failed gate-check means you do not advance to the next stage, and why what was never truly run is never claimed to have run.

Act Two layers on a sister lesson: **when a headless lever fails repeatedly (FTM wrap size field, watertight region control),
do not retry endlessly — cap it (3 attempts) and change route.** Can't fix wrap → switch to watertight; can't extract a clean fluid region → just solve the 10-region mesh +
single far-field box. Bypassing an unsolvable sub-problem often gets you closer to delivery than forcing it.

Next round of improvements (in order):
1. Do a "box-minus-aircraft" in the SpaceClaim GUI to get a truly single clean fluid region (`Javelin_V1_smooth_cfd_GUI_worklist.md`), then rerun fully headless.
2. Fix the FTM boundary-layer subtask (wedge count as a hard gate-check) → strategy A (y+≈1) + mesh independence.
3. Get second-order to converge (first stabilize with first-order, then gently switch / pressure-based coupled) → obtain design-grade drag.
4. α sweep (-4/0/4/8/12°), β sweep.
5. Full 54-body model CAD repair → recompute coefficients after the user provides the real wing reference area and CG.
