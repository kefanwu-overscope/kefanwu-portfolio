# Quality Gates (every item must pass before accepting an Ansys Fluent drone CFD result)

> If a gate-check fails, stop and fix it — do not push ahead into the next phase. Each gate yields one of three grades: Pass / Acceptable / Serious risk.
> Principle (discipline-gate-before-next-phase): geometry → boundary → mesh → solve → convergence → y+ → report,
> **pass each phase's gate before advancing to the next**; if a gate-check fails, stop and fix it, never advance carrying a known Fail.

---

## Geometry gate

**Pass only when**: model units are verified; the fluid domain exists; the aircraft solid bodies have been **subtracted** from the air domain; there are no obvious missing faces / openings; air-domain dimensions are recorded.

**Fail if**: CAD solid bodies were meshed as fluid; the air domain is missing; units are unknown; geometry-repair errors remain unresolved.

---

## Boundary gate

**Pass only when** the named selections are complete: `inlet`, `outlet`, `wall_body`, plus the top/side/bottom far-field or symmetry.
A rotor case additionally needs a rotor region or actuator-disk region.

**Fail if**: the meaning of inlet/outlet is unclear; `wall_body` mistakenly includes far-field walls; the surface on which forces are reported is ambiguous.

> Two topology routes (pick either, and keep it self-consistent with the velocity direction):
> - **Multi-face decomposition** (wrap/incompressible): windward/bottom face = velocity-inlet, leeward/top face = pressure-outlet, side faces = symmetry (only when β=0).
> - **Single far-field** (conforming/compressible): the one outer-box zone with no `-shadow` twin is converted to `pressure-far-field`, and the angle of attack is encoded via `flow_direction` (see the "Far-field read-back gate" below).

---

## Far-field read-back gate (mandatory after setting pressure-far-field, silent-failure protection)

> The angle of attack is encoded on **one** far-field boundary via the **Mach + flow_direction unit vector**, which is cleaner than splitting velocity components across multiple inlets/outlets.
> **Fatal silent failure**: in PyFluent 0.17.1 the keys are the short names `m` (Mach) / `t` (temperature) / `flow_direction` (a list of `{value}`).
> Using the plausible-looking long names `mach_number` / `temperature` **raises no error and has no effect** — the boundary silently stays at Fluent's defaults **Mach≈0.6, T≈300 K**,
> so you compute the whole flow case at the wrong velocity (near-transonic) with no error reported at all. For the same class of trap see F2 (velocity_components) and F7 (report_output_type).

**Pass only when**: after `set_state`, you **read back** `pf.get_state()` and compare each item against the target one by one:

| Quantity | Key | Tolerance | Mismatch |
|---|---|---|---|
| Mach | `m['value']` | \|got_m − target_Mach\| < 1e-4 | **Fail → abort immediately** |
| Temperature | `t['value']` | \|got_t − T_inf\| < 0.1 K | **Fail → abort immediately** |
| Flow direction | `flow_direction[i]['value']` | \|got_dir[i] − target_dir[i]\| < 1e-3 | **Fail → abort immediately** |

```python
chk = pf.get_state()
gotm = chk["m"]["value"]; gott = chk["t"]["value"]
gotd = [c["value"] for c in chk["flow_direction"]]
if abs(gotm - MACH) > 1e-4 or abs(gott - T_INF) > 0.1 or abs(gotd[0] - DRAG_DIR[0]) > 1e-3:
    raise RuntimeError(f"far-field read-back mismatch: m={gotm} t={gott} dir={gotd} — aborting")
# Javelin_V1 target: Ma 0.245, T 288.16 K, flow_direction (0.99863, 0, 0.052336) [=AoA 3 deg]
```

**Fail if**: the read-back returns None (key written wrong, object does not exist — the zone must first be converted to type `pressure-far-field` via TUI before the BC can be accessed);
or any quantity exceeds tolerance. **Never allow iteration to proceed carrying the default Mach≈0.6.**

---

## Mesh gate

| Grade | negative volume | max skewness | min orthogonal quality | Boundary layer |
|---|---|---|---|---|
| Recommended | 0 | < 0.90 | > 0.15 | truly generated and the first layer was accepted |
| Acceptable (first cut) | 0 | < 0.95 | > 0.10 | — |
| Serious risk | >0 | ≥ 0.98 | ≤ 0.05 | wedge count = 0 (BL not generated) |

- **If a serious risk is present → the result must not be called trustworthy.**
- **The boundary layer is a hard gate: verify it with the wedge count from the cell-type breakdown (wedge>0 is the only evidence).**
  **Distinguish the trap (F6)**: `hex` cells are the **hexcore core cells, not the prism layer**; do not use the hex count as BL evidence.
  wedge=0 = BL not generated = the y+ gate will very likely Fail along with it (Javelin_V1 measured: wedge=0 → y+ median 147, only 23.7% inside strategy-B band).
- The FTM compound parent task silently ignores BL parameters passed via `arguments.update_dict()` (the generated control is named `aspect-ratio_1` instead of `first_height_1`);
  you must use the child-task pattern to explicitly create the BL control and read back `OffsetMethodType/FirstHeight/NumberOfLayers`.
- **wrap vs conforming**: under headless operation an FTM wrap mesh **cannot be refined** (the size field is locked at the first "Default");
  conforming/watertight preserves the CAD faces and gives controllable surface sizes (`CFDSurfaceMeshControls.MinSize`), and importing STEP directly does not trigger F1.
  This project ultimately **solved the 10-region conforming mesh directly** (one pressure-far-field outer region, with the 9 sealed body cavities as harmless dead air).

---

## Solve gate

**Pass only when**: the solver matches the physics; the velocity direction is correct (the AoA component read-back check passes, or the far-field read-back gate passes); reference values have been checked;
force/moment monitors are created and written to disk every step (`report_files`, **disable all interactive TUI reports** — F3 falls into an "Empty filename" infinite loop flooding 9.8 million lines);
**the default convergence criterion has been disabled and verified by a probe iteration** (see the sub-gate below).

Low-speed defaults: Pressure-Based, Steady first, k-ω SST, constant-density air.
Compressibility warning: U>100 m/s or Ma>0.3 → switch to Energy On + ideal-gas.

> **Discretization-scheme caution (second-order-diverges)**: a compressible case (Ma 0.245, ideal-gas) that hard-switches to second-order upwind at iter~30 will immediately diverge/hang.
> If second-order does not converge, **stay on first-order upwind throughout** for stability, but the report must note that first-order numerical dissipation **systematically over-predicts drag by ~10–25%** (see the report gate).

### Convergence-criterion-disabled sub-gate (F4, mandatory)

> Fluent's default residual criterion 1e-3 **stops the run early** — in this flow case the run was judged "converged" at iter 48, but drag was still fluctuating by 78.8%, far from stable.

1. **Disable**: iterate over the `equations` in `solution.monitor.residual`, set each equation's `check_convergence` to `False`, then `set_state`; read back to confirm.
   ```python
   res = s.solution.monitor.residual; rst = res.get_state()
   for eq in rst.get("equations", {}).values():
       if isinstance(eq, dict) and "check_convergence" in eq: eq["check_convergence"] = False
   res.set_state(rst)
   ```
2. **Probe sub-gate (PROBE, must run)**: after disabling, first run a **20–30 step** probe iteration to verify the criterion is indeed inactive.
   - **Fail signal**: if iterate returns within **<5 s** **and the history row count does not grow** → the criterion was not truly disabled (still stopping early at 1e-3) → **Fail / abort**, go back and fix the disable logic.
   - Pass: the probe runs the full set number of steps, writes to disk every step, and shows a reasonable ETA → only then scale up to the main iteration (~800 steps, certainly not 48).

---

## Convergence gate

> A residual drop is only a necessary condition, not a sufficient one. The three quantities below are **hard gates** (measured numbers).

| Grade | Residual | Force/moment (last 200 steps) | mass imbalance = \|net\| / \|inlet\| |
|---|---|---|---|
| Recommended | dropped 3 orders or a stable plateau | fluctuation < 1% | < 0.5% |
| Acceptable | entered a plateau | fluctuation 1%~3% | < 1% |
| Fail | blow-up / no drop | fluctuation > 3% (**not trustworthy**) or persistent periodic oscillation | > 2% (**outright veto**) |

- **Force/moment fluctuation over the last 200 steps** (=(max−min)/\|mean\|×100%) must be < 1–3%; **>3% is not trustworthy** and forces/moments must not be reported from it.
  Deduplicate the history by iteration number **keeping the last entry** (restarts produce overlaps), then take statistics over the last 200 steps.
- **mass imbalance = \|net mass flow\| / \|inlet mass flow\|**: **<1%** passes, **<0.5% recommended**, **>2% vetoes** the entire solution outright.
  (Javelin_V1 measured ≈9e-9, far better than the gate limit.)
- Persistent periodic oscillation of force/moment → the flow may be unsteady → consider transient.
- Large-area backflow at the outlet affecting the main wake → lengthen the downstream domain and re-mesh.
- **Convergence counts only when multiple criteria are met simultaneously**: measured drag fluctuation 0.15% / lift 1.12% / mass imbalance≈0 **all passed**, but the y+ gate Failed → the result is still downgraded overall to process-validation grade.

---

## y+ gate

- Wall-resolved (SST low-Re, strategy A): target **y+≈1**, with most of the wall area falling roughly in 0.5~5.
- Wall functions (strategy B): target **y+ 30~100**.
- **Pass condition = the wall strategy matches**: the actual y+ distribution must fall within the target band of the chosen strategy (resolved ≈1 / wall functions 30–100);
  a mismatch between strategy and y+ is a Fail (e.g. a mesh built for wall-resolved but with y+ median 147, which is neither resolved nor inside the wall-function band).
- **Judge by the distribution share, not just the mean**: e.g. if the target band covers <1/4 of the wall and large patches are ≥300 → Fail.
  (Javelin_V1 measured facets: min 1.6 / median 147 / p95 382 / max 602, with only 23.7% inside the strategy-B band 30–100 and 16.1% at ≥300 → **Fail**.)
- y+ far from target → note that drag and separation predictions may be untrustworthy.
- Numerical extraction uses facet data (F5): `session.field_data.new_transaction()` +
  `add_scalar_fields_request(field_name="y-plus", surface_ids=[...], node_value=False, boundary_value=True)` → `get_fields()` (the leaves are numpy).
  The rendered display shows the node-averaged y+ (which is smaller); the audit relies on facet data (which includes the extremes), and the report notes which basis was used.

---

## Report gate

The report must contain: inputs and assumptions, geometry setup, mesh metrics, solver settings, boundary conditions, reference values,
forces and moments, convergence checks, mass imbalance, y+, the generated/requested figures, **confidence rating, limitations, next steps**.

**Additional iron laws**:
- Missing a **real** reference area → do not report trustworthy Cd/Cl, only forces (N).
- Missing the moment center / reference length → do not report trustworthy moment coefficients, only the raw moments (N·m).
- **Coefficients computed with an estimated reference area/length/moment center → may only be labeled "process-validation value", never used as a design basis.**
  (Javelin_V1's ref area 0.043876 m², ref length 0.5 m, and moment center (-1.011984,0.6,1.12) are all estimated values →
  Cd/Cl/Cm are process-validation grade only, and must be recomputed after the user provides the real wing reference area and CG.)
- **The absolute drag of a first-order solution must be noted as systematically over-predicted by ~10–25%** (first-order upwind numerical dissipation); the **shape** of Cp / the flow field is trustworthy, but the absolute drag is process-validation grade.
- A moment report definition outputs a **coefficient** by default (F7: `report_output_type` defaults to "Drag Coefficient", =÷q·A·L);
  to get the raw N·m you must explicitly set `"Drag Force"`, and after creating any report definition read back the full state to check for hidden default keys.
- Results (numbers / contour plots / conclusions) that were not actually run → **must never be written into the report.**
