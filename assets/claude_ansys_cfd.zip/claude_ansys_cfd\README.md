# claude_ansys_cfd — Teaching an AI Agent to do drone external-flow CFD with Ansys Fluent

> This package distills one **actually-completed** drone external-flow CFD job (Javelin_V1 VTOL cruise, 2026-06,
> Ansys Fluent 2024 R1 + PyFluent 0.17.1, fully scripted and unattended) into reusable teaching material.
> Target reader: an AI agent that needs to **drive Fluent with code** on Windows to produce results that are reviewable, reproducible, and have clearly-stated credibility.
>
> What sets it apart from material that "talks about CFD workflow in the abstract" is that this is written from **pitfalls actually hit and fixes actually verified**
> (the real PyFluent 0.17.1 keys, the 11 failures F1–F11, anti-fabrication gates, runnable reference scripts) —
> pick it up and follow it directly, without repeating the same mistakes.

---

## What you'll learn / the most expensive lessons

The following are the lessons with the **highest cost per unit** in this whole body of material. Memorize them first; every later document is an expansion of them:

- **Conforming (watertight) mesh beats FTM wrap.** A wrap only plasters a ~5mm envelope skin over the outside of the CAD, loses the real CAD faces, and even grows spikes at the wingtips, and **in a headless environment the size field locks up — 3 attempts and it could not be refined** (F9/F10); watertight reads STEP directly without crashing (F1 only applies to the FTM import path), `CFDSurfaceMeshControls.MinSize` is controllable, and the surface is smooth. A dirty `fluid_domain` produces 10 regions and even then a single region cannot be extracted headlessly → **just solve those 10 regions as a multi-region mesh + a single pressure-far-field box**.
- **The far-field angle of attack must be read back and verified.** The real 0.17.1 keys are the short names `m` (Mach) / `t` (temperature) / `flow_direction` (a unit-vector list — the AoA is hidden inside it); writing `mach_number` / `temperature` instead **raises no error and silently no-ops**, leaving the boundary at Fluent's default Mach≈0.6, T 300 → you'll compute a transonic result at the wrong speed. **After set_state you must read back and assert** `abs(got_m - 0.245) > 1e-4 → abort`.
- **After a crash/exit you must kill the entire process family + sleep + read back to verify**, before launching the next run: `Get-Process fluent,mpiexec,cortex,python | Stop-Process -Force` → `Start-Sleep 10` → read back that `fluent,mpiexec` is empty. Killing only `fluent,python` leaves ~20 mpiexec orphans holding the single license → the next launch gives `Connection refused` (F11). **Never write kill+launch in the same command** (the license seat does not get released in time).
- **Convergence is multi-criterion, not just residuals.** Force/moment fluctuation over the last 200 steps <1–3%, mass imbalance <1% (>2% is a veto), and y+ consistent with the wall strategy — if any one fails, downgrade; never declare convergence on residuals alone (F4).
- **Estimated reference values ⇒ coefficients are only "process-validation values."** Reference area 0.043876 m², reference length 0.5 m, moment center (-1.011984, 0.6, 1.12) m are all estimated; the Cd/Cl/Cm computed from them **can never serve as a design conclusion**, and must wait for the real wing area and CG to be recomputed.
- **Never fabricate.** Never claim to have run something that was not actually run; on failure, report the stage / cause / what was completed / fix recommendation, with every number carrying its unit and credibility annotation.
- **Disable all interactive TUI reports.** `/report/forces/wall-forces` with a mismatched prompt order will loop forever and blow up the transcript (measured at 9.8 million lines) → always use `report_files` written to disk for monitoring (F3).
- **Second-order diverges in this compressible case; stay first-order throughout.** This case is compressible at Ma 0.245; a hard switch to second-order upwind around iteration ~30 diverges immediately → first-order upwind is stable throughout; the price is that first-order numerical dissipation **systematically over-predicts drag by ~10–25%**, so absolute drag is only at process-validation grade, while Cp and the flow-field morphology are trustworthy.

---

## 0. Your role (in one sentence)

You are an **Ansys Fluent external-flow CFD simulation engineer + quality inspector**, not "an assistant who clicks a few buttons and produces colorful contour plots."
Your output must be **reviewable, reproducible, and have clearly-stated credibility**. The full persona is in [`SYSTEM_PROMPT.md`](SYSTEM_PROMPT.md).

---

## 1. The seven iron laws (never violate, at any time)

1. **CAD solid bodies are not the fluid domain.** External flow meshes and solves only the air volume of "bounding box air minus the solid bodies."
   If you mesh the solid bodies as if they were fluid = fake success, and the whole result is void.
2. **Every quantity must carry a unit.** Length / velocity / area / density / viscosity / angle of attack / rotation rate… if the unit is uncertain → no trustworthy conclusion may be given.
3. **Without inlet / outlet / wall_body / far-field (symmetry or far-field) naming, you may not enter a formal solve.**
4. **Low-speed incompressible defaults:** pressure-based, steady, k-ω SST, ρ=1.225 kg/m³, μ=1.7894e-5 kg/(m·s).
   U>100 m/s or Ma>0.3 → suggest switching to compressible (Energy On + ideal-gas).
5. **Convergence is not residuals alone.** Also: force/moment fluctuation over the last 200 steps <1–3%; mass imbalance <1% (>2% is an outright veto);
   y+ consistent with the wall strategy. If any one fails → do not claim trustworthiness.
6. **No reference area → report force (N) only, not a trustworthy Cd/Cl; no moment center/reference length → report raw moment (N·m) only, not coefficients.**
   Coefficients computed from estimated reference values **may only be labeled "process-validation values," and may not serve as design conclusions**.
7. **Never claim to have run something that was not actually run.** On failure, report: current stage, cause of failure, what was completed, fix recommendation. **Never fabricate any number.**

> Law 7 is the soul of this material. Every script in this project has a built-in "anti-fabrication gate": critical settings (such as the AoA inlet components,
> and whether the convergence criterion is really disabled) are **set first, then read back and validated**; if validation fails it **aborts proactively**, never silently running to completion in a wrong state.

---

## 2. End-to-end workflow (pass the gate at each stage before advancing)

```
confirm case → geometry/air domain → mesh → [mesh gate] → solver setup → solve → [convergence gate + y+ gate]
        → force/moment/coefficient extraction → post-processing images → report (with credibility rating and limitations)
```

If a gate-check fails, **stop and fix**; do not force ahead to the next stage. Gate-check criteria are in [`docs/03_quality_gates.md`](docs/03_quality_gates.md).

---

## 3. How to use this package (suggested learning order)

| Order | File | Purpose |
|---|---|---|
| 0 | [`SYSTEM_PROMPT.md`](SYSTEM_PROMPT.md) | **Read first.** Load into the system prompt to establish role and discipline |
| 1 | [`docs/05_environment.md`](docs/05_environment.md) | Environment: Python path, PyFluent injection, Fluent path, license, process hygiene |
| 2 | [`docs/01_workflow_sop.md`](docs/01_workflow_sop.md) | Standard operating procedure (geometry→mesh→solve→audit→report) |
| 3 | [`docs/03_quality_gates.md`](docs/03_quality_gates.md) | The hard metrics for each stage's gate-check |
| 4 | [`docs/06_meshing_strategy.md`](docs/06_meshing_strategy.md) | Meshing strategy: wrap vs conforming (watertight) vs solving multi-region directly — why conforming comes first, why a headless wrap cannot be refined, and why a dirty geometry should just be solved as 10 regions + a single far-field box |
| 5 | [`docs/02_pyfluent_playbook.md`](docs/02_pyfluent_playbook.md) | ⭐ **Hands-on core**: the real PyFluent 0.17.1 API recipes |
| 6 | [`docs/04_failure_recovery.md`](docs/04_failure_recovery.md) | Known failures F1–F11 + general divergence/mesh-failure recovery |
| 7 | [`docs/07_postprocessing_and_imaging.md`](docs/07_postprocessing_and_imaging.md) | Headless post-processing and imaging: force/moment/coefficient extraction, y+ distribution, the F8 camera sequence, large-domain plane reconstruction and composite cropping |
| 8 | [`scripts/`](scripts/) | 5 verified reference scripts (solve / audit / imaging + the newly-added `conforming_farfield_solver_reference.py` conforming far-field solve, and `conforming_postproc_imaging_reference.py` conforming post-processing imaging) |
| 9 | [`templates/`](templates/) | Report template + case input template |
| 10 | [`examples/Javelin_V1_case_study.md`](examples/Javelin_V1_case_study.md) | Real case study: how the rules land in a single real-world run |

---

## 4. Quick start (the minimum actions)

1. **Read the environment** ([`docs/05_environment.md`](docs/05_environment.md)), confirm this machine's Python / PyFluent / Fluent / license paths match the docs; if they don't, probe and correct first.
2. **Before every Fluent launch** clear zombie processes for the **whole family** (must include mpiexec, or orphans hold the license and cause F11 `Connection refused`): `Get-Process fluent,mpiexec,cortex,python -EA SilentlyContinue | Stop-Process -Force` → `Start-Sleep 10` → read back that `fluent,mpiexec` is empty before launching; **do not kill+launch in the same command**.
3. **From the case template** ([`templates/case_input_template.yaml`](templates/case_input_template.yaml)) fill in a case, clearly marking which values are `[user]`-given and which are `[estimated]`.
4. **Follow the SOP** through geometry→mesh→solve; for the **solver script** refer directly to [`scripts/solver_reference.py`](scripts/solver_reference.py) (with F2/F3/F4/F7 fixes + anti-fabrication gates built in).
5. **Run long tasks in the background + poll `.out`**, don't block waiting; the transcript (`fluent-*.trn`) can be enormous, use `Select-String`/tail, **never read the whole file in**.
6. **For auditing** use [`scripts/postproc_audit_reference.py`](scripts/postproc_audit_reference.py) (y+ distribution, moment units, convergence statistics).
7. **For imaging** use [`scripts/postproc_images_reference.py`](scripts/postproc_images_reference.py) (headless rendering, with the camera-no-redraw pitfall already worked around).
8. **For the report** follow [`templates/report_template.md`](templates/report_template.md), **annotate every number with its credibility, and label coefficients derived from estimated values as process-validation values only**.

---

## 5. Each failure F1–F11 in one sentence (full detail in [`docs/04_failure_recovery.md`](docs/04_failure_recovery.md))

- **F1** SpaceClaim's headless STEP→FMD conversion crashes → use a cached FMD, don't let FTM import the .step.
- **F2** The inlet-components key is `momentum.velocity_components[i].value` (a list, 3 × {option,value}) → get_state to see the structure first, then set.
- **F3** The interactive TUI force report (wall-forces) with a mismatched prompt order loops forever and blows up the transcript → **disable all interactive TUI reports**, use report_files written to disk; save case/data **immediately** after iterate.
- **F4** Fluent's default convergence criterion 1e-3 cuts off early (force far from settled) → before solving, **explicitly disable** check_convergence on each equation of `solution.monitor.residual`, and verify with a short probe iteration.
- **F5** `session.fields` does not exist, `get_scalar_field_data` returns empty → use `field_data.new_transaction()` + `add_scalar_fields_request(...surface_ids=...)`.
- **F6** The FTM boundary-layer sub-task has no effect (the compound parent task's update_dict is ignored) → verify BL with **the wedge count in the cell-type breakdown**; hex is the hexcore core, not prisms.
- **F7** A moment report definition outputs **coefficients** by default, not N·m (`report_output_type` defaults to "Drag Coefficient") → for the raw moment you must explicitly set "Drag Force"; after creating any report definition, read back **all** state to check the hidden default keys.
- **F8** Headless imaging: `display()` resets the camera to the default view and `camera/*` settings don't trigger a redraw → use `display → restore-view → auto-scale → pan-camera → zoom-camera → save-picture`.
- **F9** In a headless environment **an FTM wrap mesh cannot be refined**: the size field locks up the first time 'Default' executes, and all three methods — changing GlobalMin, turning off UseSizeFieldForPrimeWrap — fail (output bytes identical or moving in the wrong direction) → switch to a conforming watertight approach, or fall back to the interactive GUI to do the wrap refinement.
- **F10** The real reason the surface is "coarse" is that **the wrap is not the CAD**: the STEP itself is a single closed solid (0.5mm tessellation, very fine), and it's the 5mm envelope skin of the wrap that lost the CAD faces. Conforming watertight **reads STEP directly without crashing** (F1 only applies to the FTM path), `MinSize` is controllable, and the surface is smooth; a dirty `fluid_domain` produces 10 regions and headlessly a single region cannot be extracted (NumberOfFlowVolumes/region=dead are all ignored) → **just solve the multi-region mesh + a single pressure-far-field box**; the 9 sealed-body inner cavities are harmless dead air pockets.
- **F11** Killing only `fluent,python` leaves **~20 mpiexec orphans + an orphan solver** holding the single license seat → the next launch gives `Connection refused`; you must kill the whole family (including mpiexec,cortex) → `Start-Sleep 10` → **read back to verify `fluent,mpiexec` is empty**, and **do not kill+launch in the same command**.

---

## 6. Operational discipline (where it's easiest to go off the rails)

- **No advancing to the next stage if a gate-check fails**; if a gate-check fails, stop and fix.
- **Run long tasks in the background + poll**, don't block.
- **Use Select-String/tail on the transcript**, never read the whole file in (once blew up to 9.8 million lines).
- **After both a crash and a normal exit, clear the whole process family** (including `mpiexec,cortex`; measured: a normal exit still leaves ~2 fluent, a crash leaves ~20 mpiexec orphans holding the license): `Get-Process fluent,mpiexec,cortex,python | Stop-Process -Force` → `Start-Sleep 10` → read back to verify empty (F9/F11).
- **Append every failure and fix to the execution log** (in this project it's `Javelin_V1_agent_session_log.md`) — the next agent relies on it to avoid the pitfalls.
- **After creating a report definition, read back all state**; hidden default keys will change the numeric meaning (the F7 lesson).

---

## Running on another machine (Claude Code + Opus 4.8)

This is a **portable teaching package for an AI coding agent** (for example, Claude Code running Claude Opus 4.8). To use it, point the agent at [`SYSTEM_PROMPT.md`](SYSTEM_PROMPT.md) and have it read `docs/` in the learning order above (Section 3). The system prompt establishes the role and discipline; the docs encode the SOP, quality gates, the real PyFluent API recipes, the F1–F11 failures and fixes, and the post-processing playbook.

**The concrete paths in this package are from the authoring machine and are EXAMPLES — they will differ on another computer.** Specifically, the Ansys install at `D:\ansys2024\ANSYS Inc\v241`, the bundled CPython interpreter under `commonfiles\CPython`, the PyFluent site-packages under `optiSLang\lib`, and the license `1055@localhost` all came from the machine where this material was authored. Do not assume they are correct on a new computer.

**How to find the equivalents on a new machine:**

- **Ansys install root** — read the `AWP_ROOT<version>` environment variable (e.g. `AWP_ROOT241` for 2024 R1) or locate the install directory directly (commonly under `...\ANSYS Inc\v241`). Call this `<root>`.
- **Bundled CPython interpreter** — `<root>\commonfiles\CPython\3_10\winx64\Release\python\python.exe`. This is the interpreter the package uses; the system PATH usually has no `python`/`py`.
- **PyFluent install** — either a pip-installed `ansys-fluent-core==0.17.1`, or the bundled site-packages (on the authoring machine these were injected via `sys.path.insert(0, ...)` pointing at the `optiSLang\lib\python3.10\Lib\site-packages` directory under `<root>`).
- **Fluent executable** — `<root>\fluent\ntbin\win64\fluent.exe`.
- **License server** — find your own license server (host/port); `1055@localhost` is only the authoring machine's value.

Then **edit the CONFIG block at the top of each reference script** in [`scripts/`](scripts/) accordingly: point the interpreter, the PyFluent path injection, the Fluent exe, and the license at your machine's equivalents. The logic below the CONFIG block encodes the F1–F11 fixes and should not be broken.

**Version note:** this package targets **Ansys 2024 R1 + PyFluent 0.17.1 (an OLD API)**. Other versions may use different keys — **always `get_state()` before `set_state()`** to see the real structure before writing, exactly as the F2 lesson prescribes.

---

*This package is organized from a real run. The constants in the scripts (paths, reference values, angle of attack, etc.) are the specific values of the Javelin_V1 case;
when switching cases, replace the constant block at the top; the logic below the constant block encodes the F1–F11 fixes — don't break it.*
