# Reference image-generation script — headless rendering of cross-section / surface contour plots
# ============================================================================
# Corresponds to docs/02_pyfluent_playbook.md §10; fixes F8 (camera does not redraw).
# Key point: display() resets the camera back to the default view, and camera/* settings do not trigger a redraw ->
#   reliable sequence display -> restore-view -> auto-scale -> pan-camera -> zoom-camera -> save.
# When a named graphics-object container is empty, get_state() returns None; do not use `name in get_state()` to test existence.
# After producing images, always read the PNG and visually inspect the viewpoint (a non-empty file is only a necessary condition).
# ============================================================================

import json
import os
import sys
import traceback

sys.path.insert(0, r"D:\ansys2024\ANSYS Inc\v241\optiSLang\lib\python3.10\Lib\site-packages")
from ansys.fluent.core import launch_fluent
from ansys.fluent.core.launcher.launcher import FluentMode

# ===== Modify per case =====
WORKDIR   = r"C:\Users\oc\Desktop\Codex_Ansys"
CASE_DATA = os.path.join(WORKDIR, "your_case_alpha3.cas.h5")
OUT       = os.path.join(WORKDIR, "postproc_images_reference.out")
IMG_DIR   = os.path.join(WORKDIR, "your_case_images")
WALL      = "javelin_v1_aero_core_fused_validation.1"
BODY_CENTER = (-1.011984, 0.6, 1.12)     # Body geometric center (the cross-section passes through this point, the camera aims at this point)
DX_OFFSET   = 2.461                       # |x| offset of the body center relative to the air-domain center (used by pan when the domain is not centered)
SIDE_FIELD  = (1.6, 0.9)                  # Cross-section field of view (width m, height m): body + wake
ZOOM        = 6.0
# ===== End of constants block =====


def log(m):
    with open(OUT, "a", encoding="utf-8") as f:
        f.write(str(m) + "\n")


def safe(label, fn):
    try:
        fn(); log(f"{label}=OK")
    except Exception as e:
        log(f"{label}=ERROR {repr(e)}"); log(traceback.format_exc())


def main():
    if os.path.exists(OUT):
        os.remove(OUT)
    os.makedirs(IMG_DIR, exist_ok=True)
    os.environ["AWP_ROOT241"] = r"D:\ansys2024\ANSYS Inc\v241"
    session = None
    try:
        session = launch_fluent(
            product_version="24.1.0", mode=FluentMode.SOLVER, precision="double",
            processor_count=4, show_gui=False, cleanup_on_exit=False,
            cwd=WORKDIR, start_timeout=120, start_watchdog=False,
        )
        session.tui.file.read_case_data(CASE_DATA)
        log("READ_CASE_DATA=OK")
        tui, gr = session.tui, session.results.graphics
        cx, cy, cz = BODY_CENTER

        # Global image-generation settings
        tui.display.set.picture.driver.png()
        tui.display.set.picture.use_window_resolution("no")
        tui.display.set.picture.x_resolution(1920)
        tui.display.set.picture.y_resolution(1080)
        # Vertical cross-section (passes through the body center, normal +Y)
        tui.surface.plane_point_n_normal("plane-y", cx, cy, cz, 0, 1, 0)

        def make_contour(name, field, surfaces):
            try:
                gr.contour.create(name)
            except Exception:
                gr.contour[name] = {}          # When the container is empty, create may throw; fall back to assigning an empty dict
            obj = gr.contour[name]; st = obj.get_state()
            payload = {"field": field, "surfaces_list": surfaces}
            if isinstance(st, dict) and "node_values" in st:
                payload["node_values"] = True
            obj.set_state(payload)
            return name

        def show(name, kind="contour"):
            try:
                getattr(gr, kind)[name].display()
            except Exception:
                tui.display.objects.display(name)

        def save(fname):
            path = os.path.join(IMG_DIR, fname)
            if os.path.exists(path):
                os.remove(path)                # Delete first to avoid the overwrite prompt
            tui.display.save_picture(path)
            log(f"SAVE_{fname}={'OK' if os.path.exists(path) else 'MISSING'} "
                f"size={os.path.getsize(path) if os.path.exists(path) else 0}")

        # Cross-section side view: display -> restore-view top (looks at XZ) -> auto-scale -> pan (brings body into frame) -> zoom -> save
        def side_shot(name, fname, kind="contour"):
            show(name, kind)
            tui.display.views.restore_view("top")
            tui.display.views.auto_scale()
            tui.display.views.camera.pan_camera(-DX_OFFSET, 0)   # Sign follows the domain-offset direction; negate it if wrong
            tui.display.views.camera.zoom_camera(ZOOM)
            save(fname)

        # Body-surface isometric: display -> restore-view isometric -> auto-scale -> save (the body is framed automatically, no pan needed)
        def wall_shot(name, fname):
            show(name)
            tui.display.views.restore_view("isometric")
            tui.display.views.auto_scale()
            show(name)                          # Display once more to ensure a redraw with the new camera
            tui.display.views.restore_view("isometric")
            tui.display.views.auto_scale()
            save(fname)

        # 1) velocity cross-section  2) pressure cross-section  3-5) surface pressure/Cp/y+  6) cross-section vectors
        safe("VEL_SIDE", lambda: side_shot(make_contour("c_vel", "velocity-magnitude", ["plane-y", WALL]),
                                           "img1_velocity_side.png"))
        safe("P_SIDE", lambda: side_shot(make_contour("c_p", "pressure", ["plane-y", WALL]),
                                         "img2_pressure_side.png"))
        safe("P_WALL", lambda: wall_shot(make_contour("c_pw", "pressure", [WALL]),
                                         "img3_wall_pressure_iso.png"))
        safe("CP_WALL", lambda: wall_shot(make_contour("c_cpw", "pressure-coefficient", [WALL]),
                                          "img4_wall_cp_iso.png"))      # Cp is based on reference values; for display only when those are estimates
        safe("YPLUS_WALL", lambda: wall_shot(make_contour("c_yw", "y-plus", [WALL]),
                                             "img5_wall_yplus.png"))    # Displayed as a node average; the audit goes by facet
        def vec():
            try:
                gr.vector.create("v_y")
            except Exception:
                gr.vector["v_y"] = {}
            obj = gr.vector["v_y"]; st = obj.get_state()
            payload = {"surfaces_list": ["plane-y"], "field": "velocity-magnitude"}
            if "skip" in st:
                payload["skip"] = 3
            obj.set_state(payload)
            side_shot("v_y", "img6_vectors_side.png", kind="vector")
        safe("VEC_SIDE", vec)
        log("DONE: please read out each PNG and visually inspect whether the viewpoint/range is correct")
    except Exception as e:
        log(f"FATAL={repr(e)}"); log(traceback.format_exc())
    finally:
        if session is not None:
            try:
                session.exit()
            except Exception:
                pass


if __name__ == "__main__":
    main()
