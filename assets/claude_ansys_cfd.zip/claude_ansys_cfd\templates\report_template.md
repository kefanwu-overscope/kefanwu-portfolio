# Drone CFD Simulation Report Template

> Usage rules: every quantity carries a unit; every number is labeled with a confidence level; **coefficients produced from estimated reference values are flagged as "process-validation values" only**;
> never write in results that were not actually run. Lead with a "conclusion grade" section so the reader can see the confidence level at a glance.

---

> **Conclusion grade (read this first)**: this round is a [process-validation level / design-grade] result.
> [State the main downgrade reason in one sentence, e.g.: boundary layer not generated, y+ mismatch / reference values are estimates / geometry is a simplified subset / propellers ignored].
> Forces/moments are [usable as an order-of-magnitude reference / trustworthy]; coefficients are [process-validation only, not for design decisions / trustworthy]. See §11–12 for details.

## 1. Project information
- Project name / Ansys version / CAD file / drone type / simulation target / flight case / propeller treatment / date / archived case-data

## 2. Inputs and assumptions

| Item | Value | Unit | Source([user]/[estimated]) |
|---|---:|---|---|
| Wind speed |  | m/s |  |
| Air density |  | kg/m³ |  |
| Air viscosity |  | kg/(m·s) |  |
| Angle of attack α |  | deg |  |
| Sideslip angle β |  | deg |  |
| Mach / Re |  | - |  |
| Reference area |  | m² |  |
| Reference length |  | m |  |
| Moment center |  | m |  |
| Turbulence intensity / viscosity ratio |  | - |  |

## 3. Coordinate definitions
- Flow direction / vertical / lift direction / drag direction / side-force direction / moment reference point (note whether read back and confirmed in effect)

## 4. Geometry and air domain
- Geometry cleanup / air-domain upstream-downstream-side distances / actual domain extent / whether the Boolean subtraction is complete / remaining fluid domain

## 5. Mesh

| Metric | Value | Pass/Fail |
|---|---:|---|
| Cell count (with type breakdown) |  |  |
| Negative volumes |  |  |
| Max skewness |  |  |
| Min orthogonal quality |  |  |
| Boundary layer (wedge count / whether generated) |  |  |
| First layer height |  |  |
| y+ range |  |  |

## 6. Fluent setup
- Solver / Time / turbulence model / Energy / material / inlet (with component read-back verification) / outlet / far-field / wall_body / rotor model / initialization and iteration count / monitors

## 7. Reference values
- density / velocity / area / length / moment center (note read-back confirmation); dynamic pressure q / q·A / q·A·L

## 8. Convergence (against quality gates)

| Check | Result | Pass/Fail |
|---|---|---|
| Residual trend |  |  |
| Drag stability (last 200 steps) |  |  |
| Lift stability |  |  |
| Side stability |  |  |
| Moment stability |  |  |
| Mass imbalance |  |  |
| Outlet backflow |  |  |
| y+ vs. wall strategy |  |  |

## 9. Aerodynamic results

| Quantity | Value | Unit | Notes |
|---|---:|---|---|
| Drag |  | N |  |
| Lift |  | N |  |
| Side force |  | N |  |
| Pitching moment |  | N·m | about [center] |
| Rolling moment |  | N·m |  |
| Yawing moment |  | N·m |  |

**The following coefficients are [process-validation values / trustworthy] (do not use for design if the reference values are estimates):**

| Coefficient | Value | Notes |
|---|---:|---|
| Cd / Cl / Cy |  |  |
| Cm_pitch |  |  |
| L/D |  |  |

## 10. Flow-field visualization
- Velocity contour / pressure contour / Cp / streamlines / wall y+ / vortex structures —— filename + one-sentence description (note whether y+ is node-averaged or facet)

## 11. Confidence rating

| Area | Rating | Reason |
|---|---|---|
| Geometry |  |  |
| Mesh |  |  |
| Solver setup |  |  |
| Convergence |  |  |
| y+ |  |  |
| Rotor modeling |  |  |
| **Overall** |  |  |

## 12. Limitations
- List: propellers / geometry simplification / wall strategy / estimated reference values / no mesh independence / no case sweep / coordinate assumptions / incompressible approximation, etc.

## 13. Next steps
- List improvement items in order (fix boundary layer and recompute / wall-resolved + mesh independence / angle-of-attack sweep / full-model CAD / recompute once the user provides the real reference area and CG).

---
### Appendix: audit evidence chain (reproducible)
| Item | File |
|---|---|
| Flow case / mesh / solver script / force history / post-processing verification / archived converged solution / failure log |  |
